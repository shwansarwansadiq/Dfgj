package com.potan.psoola

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
