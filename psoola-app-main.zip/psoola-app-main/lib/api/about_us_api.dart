import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

import '../models/about_model.dart';
import '../states/about_us_state.dart';

Future saveAboutUsApi(data) async {
  AboutUsState aboutUsState = Get.find<AboutUsState>();
  await FirebaseFirestore.instance.doc('about').set(data);
  final userSnap = await FirebaseFirestore.instance.doc('about').get();
  AboutUsModel aboutUs = AboutUsModel.fromJson({
    'id': userSnap.id,
    ...data,
  });
  aboutUsState.setAboutUs = aboutUs;
}

Future<void> logout() async {
  await FirebaseAuth.instance.signOut();
}

Future<AboutUsModel> fetchAboutUsApi() async {
  AboutUsState aboutUsState = Get.find<AboutUsState>();
  final userSnap =
      await FirebaseFirestore.instance.doc('about/TqNbPUPhM9AE5cXNRDV9').get();
  AboutUsModel aboutUs = AboutUsModel.fromJson({
    'id': userSnap.id,
    ...userSnap.data() as Map,
  });
  aboutUsState.setAboutUs = aboutUs;
  return aboutUs;
}

Future fetchStaffApi() async {
  AboutUsState aboutUsState = Get.find<AboutUsState>();
  final userSnap = await FirebaseFirestore.instance
      .collection('about/TqNbPUPhM9AE5cXNRDV9/staff')
      .get();
  List<StaffModel> staff = userSnap.docs.map((doc) {
    return StaffModel.fromJson({'id': doc.id, ...doc.data()});
  }).toList();
  aboutUsState.setStaff = staff;
  return staff;
}

Future addStaffApi(data, XFile staffImage) async {
  String imageUrl = await uploadStaffImageApi(staffImage);
  data['imageUrl'] = imageUrl;
  await FirebaseFirestore.instance
      .collection('about/TqNbPUPhM9AE5cXNRDV9/staff')
      .add(data);
  fetchStaffApi();
}

Future deleteStaffApi(id) async {
  await FirebaseFirestore.instance
      .collection('about/TqNbPUPhM9AE5cXNRDV9/staff')
      .doc(id)
      .delete();
  fetchStaffApi();
}

Future updateStaffApi(staffId, data, [XFile? staffImage]) async {
  if (staffImage != null) {
    String imageUrl = await uploadStaffImageApi(staffImage);
    data['imageUrl'] = imageUrl;
  }
  await FirebaseFirestore.instance
      .collection('about/TqNbPUPhM9AE5cXNRDV9/staff')
      .doc(staffId)
      .update(data);
  fetchStaffApi();
}

uploadStaffImageApi(
  XFile file,
) async {
  firebase_storage.Reference ref =
      firebase_storage.FirebaseStorage.instance.ref('/staff/${file.name}');

  if (kIsWeb) {
    await ref.putData(await file.readAsBytes());
  } else {
    await ref.putFile(File(file.path));
  }

  String url = await ref.getDownloadURL();
  return url;
}

Future updateAboutUsApi(data) async {
  AboutUsState aboutUsState = Get.find<AboutUsState>();
  await FirebaseFirestore.instance
      .doc('about/TqNbPUPhM9AE5cXNRDV9')
      .update(data);
  final userSnap =
      await FirebaseFirestore.instance.doc('about/TqNbPUPhM9AE5cXNRDV9').get();
  AboutUsModel aboutUs = AboutUsModel.fromJson({
    'id': userSnap.id,
    ...data,
  });
  aboutUsState.setAboutUs = aboutUs;
}
