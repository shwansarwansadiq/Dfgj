import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/states/event_events_state.dart';

import '../main.dart';

class EventApi {
  Future<List<EventModel>> fetchEventEventsApi() async {
    EventEventsState eventsState = Get.find<EventEventsState>();
    QuerySnapshot<Map<String, dynamic>> liveMusicsSnap = await firebaseInstance
        .collection('events')
        .where(
          'show.type',
          isEqualTo: eventTypeToString(EventType.EVENT),
        )
        .where(
          'is_active',
          isEqualTo: true,
        )
        .where('end_time', isGreaterThanOrEqualTo: DateTime.now())
        .limit(10)
        .get();

    List<EventModel> liveMusics = liveMusicsSnap.docs.map((doc) => EventModel.fromJson({'id': doc.id, ...doc.data()})).toList();

    eventsState.setEvents = liveMusics;
    return liveMusics;
  }

  Future<List<DateTime>> fetchEventDateTime(String eventId) async {
    QuerySnapshot<Map<String, dynamic>> eventSnap = await firebaseInstance.collection('events').doc(eventId).collection('times').get();

    List<DateTime> eventTimes = eventSnap.docs.map((doc) => (doc.data()['time'] as Timestamp).toDate()).toList();
    return eventTimes;
  }
}
