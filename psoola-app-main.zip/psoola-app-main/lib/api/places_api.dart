//fetch movies from firebase
// ignore_for_file: non_constant_identifier_names

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

import '../main.dart';
import '../models/event_model.dart';
import '../models/place_model.dart';
import '../states/places_state.dart';

Future<List<PlaceModel>> fetchPlacesApi() async {
  PlacesState placeState = Get.find<PlacesState>();

  QuerySnapshot<Map<String, dynamic>> placesSnap =
      await firebaseInstance.collection('places').get();

  List<PlaceModel> places = placesSnap.docs
      .map((doc) => PlaceModel.fromJson({'id': doc.id, ...doc.data()}))
      .toList();

  placeState.setPlaces = places;
  return places;
}

Future<List<EventModel>> fetchPlaceEventsApi(String? placeId) async {
  QuerySnapshot<Map<String, dynamic>>? eventsSnap;
  DocumentSnapshot<Map<String, dynamic>>? userDocument;

  String uid = FirebaseAuth.instance.currentUser!.uid;

  if (placeId == null || placeId.isEmpty || placeId == '') {
    userDocument =
        await firebaseInstance.collection('ticket_providers').doc(uid).get();

    if (userDocument.exists) {
      String place_id = userDocument.data()!['place']['id'];
      eventsSnap = await firebaseInstance
          .collection('events')
          .where('placesId', arrayContains: place_id)
          .orderBy('startDate', descending: true)
          .get();

      List<EventModel> events = eventsSnap.docs
          .map((doc) => EventModel.fromJson({'id': doc.id, ...doc.data()}))
          .toList();

      return events;
    }
  } else {
    eventsSnap = await firebaseInstance
        .collection('events')
        .where('placesId', arrayContains: placeId)
        .where('endDate', isGreaterThan: DateTime.now())
        .get();

    List<EventModel> events = eventsSnap.docs
        .map((doc) => EventModel.fromJson({'id': doc.id, ...doc.data()}))
        .toList();

    return events;
  }

  return [];
}

getTicketPrroviderPlaceId() async {
  DocumentSnapshot<Map<String, dynamic>>? userDocument;

  String uid = FirebaseAuth.instance.currentUser!.uid;

  userDocument =
      await firebaseInstance.collection('ticket_providers').doc(uid).get();

  if (userDocument.exists) {
    String place_id = userDocument.data()!['place']['id'];
    return place_id;
  }
}

Future<PlaceModel> fetchPlaceByPlaceIdApi({required String placeId}) async {
  var placeDocument =
      await firebaseInstance.collection('places').doc(placeId).get();
  var place =
      PlaceModel.fromJson({...placeDocument.data()!, 'id': placeDocument.id});
  return place;
}
