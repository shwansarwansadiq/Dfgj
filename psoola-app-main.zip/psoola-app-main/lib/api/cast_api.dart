import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

import '../models/show_model.dart';
import '../states/cast_state.dart';

fetchCastApi({required String showId}) async {
  CastsState castState = Get.find<CastsState>();
  QuerySnapshot castSnap =
      await FirebaseFirestore.instance.collection('shows/$showId/casts').get();
  List<CastModel> casts = castSnap.docs
      .map((doc) => CastModel.fromJson({'id': doc.id, ...doc.data() as Map}))
      .toList();
  castState.setCasts = casts;
  return casts;
}
