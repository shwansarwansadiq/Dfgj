//fetch movies from firebase
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:psoola/models/show_model.dart';
import 'package:psoola/states/shows_state.dart';

import '../main.dart';

Future<List<ShowModel>> fetchShowsApi() async {
  ShowsState showsState = Get.find<ShowsState>();
  QuerySnapshot<Map<String, dynamic>> showsSnap =
      await firebaseInstance.collection('shows').get();

  List<ShowModel> shows = showsSnap.docs
      .map((doc) => ShowModel.fromJson({'id': doc.id, ...doc.data()}))
      .toList();

  showsState.setShows = shows;
  return shows;
}
