import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

import '../../models/location/district_model.dart';
import '../../states/location/district_state.dart';

Future<List<DistrictModel>> fetchDistrictApi([String? cityId]) async {
  DistrictState districtsState = Get.find<DistrictState>();

  QuerySnapshot? districtsSnap;

  if (cityId == null) {
    districtsSnap =
        await FirebaseFirestore.instance.collection('districts').get();
    List<DistrictModel> districts = districtsSnap.docs
        .map((doc) =>
            DistrictModel.fromJson({'id': doc.id, ...doc.data() as Map}))
        .toList();
    districtsState.setDistricts = districts;
    return districts;
  } else {
    districtsSnap = await FirebaseFirestore.instance
        .collection('provinces/$cityId/districts')
        .get();
    List<DistrictModel> districts = districtsSnap.docs
        .map((doc) =>
            DistrictModel.fromJson({'id': doc.id, ...doc.data() as Map}))
        .toList();
    districtsState.setDistricts = districts;
    return districts;
  }
}

Future<void> addDistrcitApi(cityId, Map<String, dynamic> data) async {
  await FirebaseFirestore.instance
      .collection('provinces/$cityId/districts')
      .add(data);
  fetchDistrictApi(cityId);
}

Future<List<DistrictModel>> searchDistrictApi(cityId, String name) async {
  DistrictState districtsState = Get.find<DistrictState>();
  districtsState.setIsSearching = true;

  QuerySnapshot districtsSnap = await FirebaseFirestore.instance
      .collection('provinces/$cityId/districts')
      .get();
  List<DistrictModel> districts = districtsSnap.docs
      .map(
          (doc) => DistrictModel.fromJson({'id': doc.id, ...doc.data() as Map}))
      .toList();

  List<DistrictModel> filteredDistricts = districts
      .where((DistrictModel element) =>
          element.name.textEn.contains(name) ||
          element.name.textAr.contains(name) ||
          element.name.textKr.toLowerCase().contains(name))
      .toList();
  districtsState.setDistricts = filteredDistricts;
  districtsState.setIsSearching = false;

  return filteredDistricts;
}

// fetch all district
Future<List<DistrictModel>> fetchAllDistrictApi() async {
  DistrictState districtsState = Get.find<DistrictState>();
  QuerySnapshot districtsSnap =
      await FirebaseFirestore.instance.collection('districts').get();
  List<DistrictModel> districts = districtsSnap.docs
      .map(
          (doc) => DistrictModel.fromJson({'id': doc.id, ...doc.data() as Map}))
      .toList();

  districtsState.setDistricts = districts;
  return districts;
}

updateDistrictApi(districtId, cityId, data) async {
  await FirebaseFirestore.instance
      .collection('provinces/$cityId/districts')
      .doc(districtId)
      .update(data);
  fetchDistrictApi(cityId);
}

Future<void> deleteDistrictApi(
    {required String cityId, required String districtId}) async {
  DistrictState districtState = Get.find<DistrictState>();
  await FirebaseFirestore.instance
      .collection('provinces/$cityId/districts')
      .doc(districtId)
      .delete();
  List<DistrictModel> districts = districtState.getDistricts;
  districts.removeWhere((element) => element.id == districtId);

  districtState.setDistricts = List.from(districts);
}
