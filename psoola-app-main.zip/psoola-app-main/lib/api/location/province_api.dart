import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import '../../models/location/province_model.dart';
import '../../states/location/province_state.dart';

Future<List<ProvinceModel>> fetchProvincesApi() async {
  ProvinceState provinceState = Get.find<ProvinceState>();
  QuerySnapshot citiesSnap =
      await FirebaseFirestore.instance.collection('provinces').get();

  List<ProvinceModel> provinces = citiesSnap.docs
      .map(
          (doc) => ProvinceModel.fromJson({'id': doc.id, ...doc.data() as Map}))
      .toList();

  provinceState.setProvinces = provinces;
  return provinces;
}

Future<bool> addProvinceApi(Map<String, dynamic> data) async {
  try {
    await FirebaseFirestore.instance.collection('provinces').add(data);
    fetchProvincesApi();
    return true;
  } catch (e) {
    return false;
  }
}

Future<void> deleteProvinceApi(String id) async {
  ProvinceState provinceState = Get.find<ProvinceState>();
  await FirebaseFirestore.instance.collection('provinces').doc(id).delete();
  List<ProvinceModel> provinces = provinceState.getProvinces;
  provinces.removeWhere((element) => element.id == id);

  provinceState.setProvinces = List.from(provinces);
}

Future<List<ProvinceModel>> searchProvinceApi(search) async {
  ProvinceState provinceState = Get.find<ProvinceState>();
  provinceState.setIsSearching = true;
  QuerySnapshot citiesSnap =
      await FirebaseFirestore.instance.collection('provinces').get();

  List<ProvinceModel> provinces = citiesSnap.docs
      .map(
          (doc) => ProvinceModel.fromJson({'id': doc.id, ...doc.data() as Map}))
      .toList();

  List<ProvinceModel> searchCities = List.from(provinces);
  if (search.isNotEmpty) {
    searchCities = provinces
        .where((ProvinceModel city) =>
            city.name.textEn.toLowerCase().contains(search.toLowerCase()) ||
            city.name.textAr.contains(search) ||
            city.name.textKr.contains(search))
        .toList();
  }
  provinceState.setProvinces = searchCities;
  provinceState.setIsSearching = false;
  return searchCities;
}

updateProvinceApi(id, data) async {
  await FirebaseFirestore.instance.collection('provinces').doc(id).update(data);
  fetchProvincesApi();
}
