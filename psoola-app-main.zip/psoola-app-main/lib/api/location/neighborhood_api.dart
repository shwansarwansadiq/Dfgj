import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

import '../../models/location/neighborhood_model.dart';
import '../../states/location/neighborhood_state.dart';

Future<List<NeighborhoodModel>> fetchNeighborhoodApi(
    {required String provinceId, required String districtId}) async {
  NeighborhoodState neighborhoodState = Get.find<NeighborhoodState>();

  QuerySnapshot neighborhoodSnap = await FirebaseFirestore.instance
      .collection('provinces/$provinceId/districts/$districtId/neighborhoods')
      .get();
  List<NeighborhoodModel> neighborhoods = neighborhoodSnap.docs
      .map((doc) =>
          NeighborhoodModel.fromJson({'id': doc.id, ...doc.data() as Map}))
      .toList();
  neighborhoodState.setNeighborhood = neighborhoods;
  return neighborhoods;
}

Future<void> addNeighborhoodApi(
    {required String cityId,
    required String districtId,
    required Map<String, dynamic> data}) async {
  await FirebaseFirestore.instance
      .collection('provinces/$cityId/districts/$districtId/neighborhoods')
      .add(data);
  fetchNeighborhoodApi(provinceId: cityId, districtId: districtId);
}

// Future<List<DistrictModel>> searchDistrictApi(cityId, String name) async {
//   DistrictState districtsState = Get.find<DistrictState>();
//   districtsState.setIsSearching = true;

//   QuerySnapshot districtsSnap = await FirebaseFirestore.instance
//       .collection('city/$cityId/districts')
//       .get();
//   List<DistrictModel> districts = districtsSnap.docs
//       .map(
//           (doc) => DistrictModel.fromJson({'id': doc.id, ...doc.data() as Map}))
//       .toList();

//   List<DistrictModel> filteredDistricts = districts
//       .where((element) =>
//           element.nameKrd.contains(name) ||
//           element.nameAr.contains(name) ||
//           element.nameEn.toLowerCase().contains(name))
//       .toList();
//   districtsState.setDistricts = filteredDistricts;
//   districtsState.setIsSearching = false;

//   return filteredDistricts;
// }

updateNeighborhoodApi(
    {required String districtId,
    required String cityId,
    required String neighborhoodId,
    required data}) async {
  await FirebaseFirestore.instance
      .collection('provinces/$cityId/districts/$districtId/neighborhoods')
      .doc(neighborhoodId)
      .update(data);
  fetchNeighborhoodApi(provinceId: cityId, districtId: districtId);
}

Future<void> deleteNeighborhoodApi(
    {required String cityId,
    required String districtId,
    required String neighborhoodId}) async {
  NeighborhoodState neighborhoodState = Get.find<NeighborhoodState>();
  await FirebaseFirestore.instance
      .collection('provinces/$cityId/districts/$districtId/neighborhoods')
      .doc(neighborhoodId)
      .delete();
  List<NeighborhoodModel> neighborhoods = neighborhoodState.getNeighborhoods;
  neighborhoods.removeWhere((element) => element.id == districtId);

  neighborhoodState.setNeighborhood = List.from(neighborhoods);
}
