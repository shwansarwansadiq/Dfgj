import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

import '../controllers/auth_controller.dart';
import '../main.dart';
import '../models/review_model.dart';
import '../models/user_model.dart';

Future<SingleReviewModel?> fetchMyReviewApi(
    {required String eventId, required UserType userType}) async {
  if (FirebaseAuth.instance.currentUser == null) {
    return null;
  }
  String userId = FirebaseAuth.instance.currentUser!.uid;

  DocumentSnapshot<Map<String, dynamic>> myReviewDoc = await firebaseInstance
      .doc('events/$eventId/reviews/$userId')
      .get();
  if (myReviewDoc.exists) {
    SingleReviewModel reviewModel = SingleReviewModel.fromJson(
        {...myReviewDoc.data() as Map, 'id': myReviewDoc.id});
    return reviewModel;
  } else {
    return null;
  }
}

fetchPeopleReviewsApi(
    {required String eventId,
    required UserType userType,
    required int limit}) async {
  QuerySnapshot<Map<String, dynamic>> reviewSnap = await FirebaseFirestore
      .instance
      .collection('events/$eventId/reviews')
      .orderBy('created', descending: true)
      .limit(limit)
      .get();

  List<SingleReviewModel> reviews = reviewSnap.docs
      .map((e) => SingleReviewModel.fromJson({...e.data(), 'id': e.id}))
      .toList();
  return reviews;
}

Future<bool> addReviewApi(
    {required int rating,
    required String comment,
    required String eventId,
    required UserType userType}) async {
  if (FirebaseAuth.instance.currentUser == null) {
    return false;
  }
  AuthState authState = Get.find<AuthState>();
  String userId = FirebaseAuth.instance.currentUser!.uid;

  Map<String, dynamic> data = {
    'comment': comment,
    'star': rating,
    'userId': userId,
    'created': DateTime.now(),
    'name': authState.user.value.name!
  };
  try {
    await FirebaseFirestore.instance
        .collection('events/$eventId/reviews')
        .doc(userId)
        .set(data);
    return true;
  } catch (e) {
    return false;
  }
}
