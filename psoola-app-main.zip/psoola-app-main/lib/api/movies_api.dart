import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/states/movies_state.dart';

import '../main.dart';

Future<List<EventModel>> fetchMoviesApi() async {
  MoviesState moviesState = Get.find<MoviesState>();
  QuerySnapshot<Map<String, dynamic>> moviesSnap = await firebaseInstance
      .collection('events')
      .where(
        'show.type',
        isEqualTo: eventTypeToString(EventType.MOVIE),
      )
      .where(
        'is_active',
        isEqualTo: true,
      )
      .where('end_time', isGreaterThanOrEqualTo: DateTime.now())
      .limit(10)
      .get();

  List<EventModel> movies = moviesSnap.docs.map((doc) => EventModel.fromJson({'id': doc.id, ...doc.data()})).toList();

  moviesState.setMovies = movies;
  return movies;
}
