import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:psoola/checker%20app/home.dart';
import 'package:psoola/ticket%20provider%20app/ticket_provider_nav.dart';

import '../models/user_model.dart';
import '../utils/app_function.dart';

Future<UserCredential?> ticketProviderLoginApi(
    {required String email,
    required String password,
    required UserType userType}) async {
  try {
    // check if user available in ticket_checker collection
    bool isUserAvailable = await isUserAvailableInCollection(
        collectionName: 'ticket_checker', email: email);
    if (isUserAvailable == false) {
      Get.snackbar('error'.tr, 'no_user_found_for_that_email'.tr);
      return null;
    }
    UserCredential userCredential = await FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email, password: password);

    if (userType == UserType.CHECKER) {
      setUserRoleLocal = UserType.CHECKER;
      Get.offAll(() => CheckerHomePage());
    } else if (userType == UserType.TICKETPROVIDER) {
      setUserRoleLocal = UserType.TICKETPROVIDER;
      Get.offAll(() => const TicketProviderNav());
    }

    return userCredential;
  } on FirebaseAuthException catch (e) {
    if (e.code == 'user-not-found') {
      Get.snackbar('error'.tr, 'no_user_found_for_that_email'.tr);
    } else if (e.code == 'wrong-password') {
      Get.snackbar('error'.tr, 'wrong_password_provided_for_that_user'.tr);
    }
  }
  return null;
}

isUserAvailableInCollection(
    {required String collectionName, required String email}) async {
  var user = await FirebaseFirestore.instance
      .collection(collectionName)
      .where('email', isEqualTo: email)
      .get();
  return user.docs.isNotEmpty;
}
