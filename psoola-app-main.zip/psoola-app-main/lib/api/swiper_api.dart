import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/states/swiper_state.dart';

import '../main.dart';

Future<List<EventModel>> fetchSwipersApi() async {
  SwiperEventsState swiperEventsState = Get.find<SwiperEventsState>();
  QuerySnapshot<Map<String, dynamic>> eventsSnap = await firebaseInstance
      .collection('events')
      .where(
        'is_in_swiper',
        isEqualTo: true,
      )
      .where('end_time', isGreaterThanOrEqualTo: DateTime.now())
      .limit(10)
      .get();

  List<EventModel> events = eventsSnap.docs
      .map((doc) => EventModel.fromJson({'id': doc.id, ...doc.data()}))
      .toList();
  swiperEventsState.setSwiperEvents = events;
  return events;
}
