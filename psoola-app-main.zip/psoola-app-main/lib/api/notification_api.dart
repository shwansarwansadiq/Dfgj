import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

saveNoticationTokenApi({required String token}) async {
  if (FirebaseAuth.instance.currentUser == null) {
    return null;
  }

  String userId = FirebaseAuth.instance.currentUser!.uid;

  FirebaseFirestore.instance.collection('customers/$userId/tokens').add({
    'notificationToken': token,
  });
}
