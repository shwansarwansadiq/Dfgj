import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

import '../models/genre_model.dart';
import '../states/genres_state.dart';

Future<List<GenreModel>> fetchGenresApi() async {
  GenresState genresState = Get.find<GenresState>();
  QuerySnapshot showsCategorySnap =
      await FirebaseFirestore.instance.collection('genres').get();
  List<GenreModel> genres = showsCategorySnap.docs.map((doc) {
    return GenreModel.fromJson({'id': doc.id, ...doc.data() as Map});
  }).toList();

  genresState.setGenres = genres;
  return genres;
}
