// ignore_for_file: avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:psoola/components/seat/model/seat_model.dart';
import 'package:psoola/states/ticket_state.dart';

import '../components/seat/controller/seat_item_controller copy.dart';
import '../components/seat/controller/seat_widget_controller.dart';
import '../main.dart';
import '../models/elements_model.dart';
import '../models/seat_design_model.dart';

class HallApi {
  fetchSeatPriceApi({required String eventId, required String seatDesignId}) async {
    try {
      TicketState ticketState = Get.find<TicketState>();
      DocumentSnapshot<Map<String, dynamic>> snap = await firebaseInstance.collection('events/$eventId/seats').doc(seatDesignId).get();
      if (false == snap.exists) {
        return null;
      }
      SeatPriceModel seatPriceModel = SeatPriceModel.fromJson({...snap.data()!, 'id': snap.id, 'seatDesignId': seatDesignId});
      ticketState.setSeatPrice = seatPriceModel;
      return seatPriceModel;
    } catch (e) {
      return null;
    }
  }

  fetchEventHallsBySelectedPlaceIdEventIdTimeId() async {
    TicketState ticketState = Get.find<TicketState>();
    SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();
    var selectedPlace = ticketState.getSelectedPlace;
    var selectedEvent = ticketState.getSelectedEvent;
    var selectedEventTime = ticketState.getSelectedEventTime;
    var selectedHall = ticketState.getSelectedHall;

    if (selectedPlace == null || selectedEvent == null || selectedEventTime == null || selectedHall == null) {
      return;
    }
    // fetch halls by selected place id
    var hallSeats = await firebaseInstance.collection('places/${selectedPlace.id}/halls/${selectedHall.id}/seats').get();

    var hallItems = await firebaseInstance.collection('places/${selectedPlace.id}/halls/${selectedHall.id}/elements').get();

    List<ElementModel> hallItemsModel = [];

    if (hallItems.docs.isNotEmpty) {
      SeatItemController seatItemController = Get.find<SeatItemController>();
      hallItemsModel = hallItems.docs.map((e) => ElementModel.fromJson({...e.data(), "id": e.id})).toList();
      seatItemController.setSeatItems = hallItemsModel;
    }
    // fetch hall price
    var hallDoc = await firebaseInstance
        .collection('events/${selectedEvent.id}/times/${selectedEventTime.id}/places/${selectedPlace.id}/halls')
        .doc(selectedHall.id)
        .get();
    var hallModel = HallModel.fromJson({...hallDoc.data()!, "id": hallDoc.id, 'place_id': selectedPlace.id});

    var hallDefaultPrice = hallModel.defaultPrice;
    var hallSeatsPrice = hallModel.seatsPrice;
    Map<String, bool>? reservedSeats = hallModel.reservedSeats;

    // put price insdie hallSeats
    var seatsWithPrice = [];
    for (var element in hallSeats.docs) {
      var seatId = element.id;
      var seatPrice = hallSeatsPrice![seatId] ?? hallDefaultPrice;
      var elementData = element.data();
      if (reservedSeats != null) {
        if (reservedSeats.containsKey(seatId) && reservedSeats[seatId]!) {
          elementData['seat_state'] = 'sold';
        }
      }
      elementData['price'] = seatPrice;
      seatsWithPrice.add({...elementData, "id": element.id});
    }

    var seatWithPriceModel = seatsWithPrice.map((e) => SeatModel.fromJson(e)).toList();
    seatWidgetController.setSeats = seatWithPriceModel;
    return seatWithPriceModel;
  }

// fetch reserved seat from ticket collection
}
