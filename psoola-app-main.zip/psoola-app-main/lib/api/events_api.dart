//fetch movies from firebase
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/models/seat_design_model.dart';
import 'package:psoola/states/event_selection_controller.dart';
import 'package:psoola/states/event_state.dart';
import 'package:psoola/states/ticket_state.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

import '../models/place_model.dart';

class EventApi {
  // Future<List<EventModel>> fetchEventsApi() async {
  //   EventsState eventState = Get.find<EventsState>();
  //   QuerySnapshot<Map<String, dynamic>> eventsSnap = await FirebaseFirestore.instance
  //       .collection('events')
  //       .where(
  //         'is_active',
  //         isEqualTo: false,
  //       )
  //       // .where('end_time', isGreaterThanOrEqualTo: DateTime.now())
  //       .get();
  //   List<EventModel> events = eventsSnap.docs.map((doc) => EventModel.fromJson({'id': doc.id, ...doc.data()})).toList();

  //   eventState.setEvents = events;
  //   return events;
  // }

  fetchEventFilterApi({PickerDateRange? currentselectedDateRange, EventType? eventType, String? search, String? cityId}) async {
    EventsState eventstate = Get.find<EventsState>();
    try {
      CollectionReference ref = FirebaseFirestore.instance.collection('events');
      Query query;
      query = ref.where('is_active', isEqualTo: true);
      query = query.where('end_time', isGreaterThanOrEqualTo: DateTime.now());
      if (eventType != null) {
        query = query.where('show.type', isEqualTo: eventTypeToString(eventType));
      }

      if (cityId != null) {
        query = query.where('cityIds', arrayContains: cityId);
      }

      if (currentselectedDateRange != null) {
        query = query.where('start_time', isGreaterThanOrEqualTo: currentselectedDateRange.startDate);
        query = query.where('start_time', isLessThanOrEqualTo: currentselectedDateRange.endDate);
      }

      DocumentSnapshot? lastDocument = eventstate.getLastDocument;

      if (lastDocument != null && search == null) {
        query = query.startAfterDocument(lastDocument);
      }
      query = query.limit(10);
      // query = query.orderBy('created', descending: true);
      QuerySnapshot eventsSnap = await query.get();

      List<EventModel> events = eventsSnap.docs.map((doc) => EventModel.fromJson({...doc.data() as Map<String, dynamic>, 'id': doc.id})).toList();
      if (lastDocument == null || (search != null && search != '')) {
        eventstate.setEvents = events;
      } else {
        eventstate.addEvents = events;
      }
      eventstate.setLastDocument = eventsSnap.docs.last;
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<List<EventTimeModel>> fetchEventTimes({required String eventId}) async {
    EventSelectionController eventSelectionController = Get.find<EventSelectionController>();
    var result = await FirebaseFirestore.instance.collection('events').doc(eventId).collection('times').orderBy('time', descending: false).get();
    List<EventTimeModel> eventTimes = result.docs //
        .map((doc) => EventTimeModel.fromJson(
              {...doc.data(), 'id': doc.id},
            ))
        .toList();
    eventSelectionController.setEventTimes = eventTimes;
    return eventTimes;
  }

  Future<List<HallModel>> fetchHallByPlaceId({required String placeId}) async {
    EventSelectionController eventSelectionController = Get.find<EventSelectionController>();
    var result = await FirebaseFirestore.instance.collection('places').doc(placeId).collection('halls').get();
    List<HallModel> halls = result.docs //
        .map((doc) => HallModel.fromJson(
              {...doc.data(), 'id': doc.id},
            ))
        .toList();
    eventSelectionController.setEventHalls = halls;
    return halls;
  }

  Future<List<HallModel>> fetchEventHallsBySelectedPlaceIdEventId() async {
    EventSelectionController eventSelectionController = Get.find<EventSelectionController>();
    TicketState ticketState = Get.find<TicketState>();
    var result = await FirebaseFirestore.instance
        .collection('events')
        .doc(ticketState.getSelectedEvent!.id)
        .collection('times')
        .doc(ticketState.getSelectedEventTime!.id)
        .collection('places')
        .doc(ticketState.getSelectedPlace!.id)
        .collection('halls')
        .get();
    List<HallModel> halls = result.docs //
        .map((doc) => HallModel.fromJson(
              {...doc.data(), 'id': doc.id, 'place_id': ticketState.getSelectedPlace!.id},
            ))
        .toList();
    eventSelectionController.setEventHalls = halls;
    return halls;
  }

  Future<List<PlaceModel>> fetchEventPlacesBySelectedTime() async {
    EventSelectionController eventSelectionController = Get.find<EventSelectionController>();
    TicketState ticketState = Get.find<TicketState>();
    var result = await FirebaseFirestore.instance
        .collection('events')
        .doc(ticketState.getSelectedEvent!.id)
        .collection('times')
        .doc(ticketState.getSelectedEventTime!.id)
        .collection('places')
        .get();

    // fetch places by place id
    List<PlaceModel> places = [];
    for (var i = 0; i < result.docs.length; i++) {
      var placeId = result.docs[i].id;
      var place = await FirebaseFirestore.instance.collection('places').doc(placeId).get();
      places.add(PlaceModel.fromJson({...place.data() as Map<String, dynamic>, 'id': place.id}));
    }

    eventSelectionController.setEventPlaces = places;
    return places;
  }
}
