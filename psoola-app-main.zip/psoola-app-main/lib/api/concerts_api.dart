import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/states/concert_state.dart';

Future<List<EventModel>> fetchConcertsApi() async {
  ConcertsState concertsState = Get.find<ConcertsState>();
  QuerySnapshot<Map<String, dynamic>> concertsSnap = await FirebaseFirestore.instance
      .collection('events')
      .where(
        'show.type',
        isEqualTo: eventTypeToString(EventType.CONCERT),
      )
      .where(
        'is_active',
        isEqualTo: true,
      )
      .where('end_time', isGreaterThanOrEqualTo: DateTime.now())
      .limit(10)
      .get();

  List<EventModel> concerts = concertsSnap.docs.map((doc) => EventModel.fromJson({'id': doc.id, ...doc.data()})).toList();

  concertsState.setConcerts = concerts;
  return concerts;
}
