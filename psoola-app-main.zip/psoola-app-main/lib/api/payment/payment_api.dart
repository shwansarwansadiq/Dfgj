// ignore_for_file: avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:psoola/auth/checker_signin.dart';
import 'package:psoola/components/seat/controller/seat_widget_controller.dart';
import 'package:psoola/components/seat/model/seat_model.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/models/seat_design_model.dart';
import 'package:psoola/models/ticket_model.dart';
import 'package:psoola/states/ticket_state.dart';

import '../../models/payment_method.dart';
import '../../models/place_model.dart';

Future paymentUrl({required PaymentType paymentMethod}) {
  TicketState ticketState = Get.find<TicketState>();

  return getPaymentUrlApi(paymentMethod: paymentMethod);
}

Future getPaymentUrlApi({required PaymentType paymentMethod}) async {
  String userId = FirebaseAuth.instance.currentUser!.uid;
  final TicketState ticketState = Get.find<TicketState>();
  final SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();
  EventModel selectedEvent = ticketState.getSelectedEvent!;
  PlaceModel selectedPlace = ticketState.selectedPlace!;
  EventTimeModel selectedEventTime = ticketState.getSelectedEventTime!;
  String hallId = ticketState.getSelectedHall!.id!;
  List<SeatModel> selectedSeats = seatWidgetController.getSelectedSeats;

// get total price from seats

  Map<String, dynamic> data = {
    'userId': userId,
    'selectedEventId': selectedEvent.id,
    'selectedPlaceId': selectedPlace.id,
    'selectedEventTimeId': selectedEventTime.id,
    'hallId': hallId,
    'selectedSeats': selectedEvent.showsType == EventType.EVENT ? [] : selectedSeats.map((e) => e.toJson()).toList(),
    'paymentMethod': paymentTypeToString(paymentMethod),
  };
  HttpsCallable fun = FirebaseFunctions.instanceFor(
    region: 'europe-west3',
  ).httpsCallable('getPaymentUrl');

  try {
    HttpsCallableResult result = await fun.call(data);
    Map<String, dynamic> resultData = result.data as Map<String, dynamic>;
    if (resultData['status'] == 200) {
      if (paymentMethod == PaymentType.FASTPAY) {
        dynamic report = resultData['data'];
        String redirectUrl = report['redirect_uri'];
        print(redirectUrl);
        return {"data": redirectUrl, "status": 200};
      }
      if (paymentMethod == PaymentType.FIB) {
        var statusCode = resultData['status'];
        if (statusCode == 200) {
          dynamic report = resultData['data'];
          var personalAppLink = report['personal_app_link'];
          String qrCode = report['qr_code'];
          return {"qrCode": qrCode, "appLink": personalAppLink, "status": 200};
        }
      }
    } else {
      return {"data": 'error ', "status": 400};
    }
  } catch (e) {
    print(e);
  }
}

Future<bool> buyTicketWithBalanceApi() async {
  final TicketState ticketState = Get.find<TicketState>();
  AuthState auth = Get.find<AuthState>();
  final SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();

  // get selected seats
  List<SeatModel> selectedSeats = seatWidgetController.getSelectedSeats;

  EventModel selectedEvent = ticketState.getSelectedEvent!;
  PlaceModel selectedPlace = ticketState.selectedPlace!;
  EventTimeModel selectedEventTime = ticketState.getSelectedEventTime!;
  HallModel selectedHall = ticketState.getSelectedHall!;

  String uid = FirebaseAuth.instance.currentUser!.uid;

  Map<String, dynamic> data = {
    'userId': uid,
    'selectedEventId': selectedEvent.id,
    'selectedSeats': selectedEvent.showsType == EventType.EVENT ? [] : selectedSeats.map((e) => e.toJson()).toList(),
    'selectedPlaceId': selectedPlace.id,
    'selectedEventTimeId': selectedEventTime.id,
    'hallId': selectedHall.id,
    'eventType': selectedEvent.show.type.name,
    'userType': authState.user.value.userType
  };

  HttpsCallable fun = FirebaseFunctions.instanceFor(
    region: 'europe-west3',
  ).httpsCallable('buyTicketWithBalance');

  try {
    HttpsCallableResult result = await fun.call(data);
    Map<String, dynamic> resultData = result.data as Map<String, dynamic>;
    if (resultData['success'] == true) {
      return true;
    } else {
      return false;
    }
  } catch (e) {
    print(e);
  }
  return false;
}

Future<List<TicketModel>?> getLatestTicketApi() async {
  // get selected seats

  String uid = FirebaseAuth.instance.currentUser!.uid;
  TicketState ticketState = Get.find<TicketState>();
  final SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();

  QuerySnapshot<Map<String, dynamic>> snap;

  if (ticketState.getSelectedEvent!.show.type == EventType.EVENT) {
    snap = await FirebaseFirestore.instance.collection('tickets').where('userId', isEqualTo: uid).orderBy('createdAt', descending: true).limit(1).get();
  } else {
    snap = await FirebaseFirestore.instance
        .collection('tickets')
        .where('userId', isEqualTo: uid)
        .orderBy('createdAt', descending: true)
        .limit(seatWidgetController.getSelectedSeats.length)
        .get();
  }

  List<TicketModel> tickets = snap.docs
      .map((e) => TicketModel.fromJson({
            ...e.data(),
            'id': e.id,
          }))
      .toList();

  if (snap.docs.isNotEmpty) {
    return tickets;
  } else {
    return null;
  }
}
