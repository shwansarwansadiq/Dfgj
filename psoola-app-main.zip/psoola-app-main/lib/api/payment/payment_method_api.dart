// ignore_for_file: avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';

import '../../models/payment_method.dart';

Future<List<PaymentMethodModel>> fetchPaymentMethodsApi() async {
  try {
    QuerySnapshot snapshot = await FirebaseFirestore.instance.collection('paymentMethods').orderBy('sqNo').where('isActive', isEqualTo: true).get();
    List<PaymentMethodModel> pyamentMethods =
        snapshot.docs.map<PaymentMethodModel>((e) => PaymentMethodModel.fromJson({"id": e.id, ...e.data() as Map})).toList();
    // List<PaymentMethodModel> pyamentMethodsLocal = [
    //   PaymentMethodModel(
    //       id: '1',
    //       title: TextLangModel(textAr: "FastpayAr", textEn: "fastpay", textKr: "fastpay"),
    //       imageUrl:
    //           'https://firebasestorage.googleapis.com/v0/b/wane-3e7a9.appspot.com/o/payment_methods%2Ffastpay.png?alt=media&token=58dbf5ff-b3c4-45e2-8a2a-decfbdf6a023',
    //       type: PaymentType.FASTPAY),
    //   PaymentMethodModel(
    //       id: '2',
    //       title: TextLangModel(textAr: "fib", textEn: "fib", textKr: "fib"),
    //       imageUrl: 'https://firebasestorage.googleapis.com/v0/b/psoola-4c2cb.appspot.com/o/download.png?alt=media&token=47054655-9728-4b3d-8a8d-2c3de0ef9200',
    //       type: PaymentType.FIB),
    // ];
    // return pyamentMethodsLocal;
    return pyamentMethods;
  } catch (e) {
    print(e);
    return [];
  }
}
