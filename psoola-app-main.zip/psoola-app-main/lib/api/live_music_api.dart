import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/states/live_music_state.dart';

import '../main.dart';

Future<List<EventModel>> fetchLiveMusicsApi() async {
  LiveMusicState liveMusicsState = Get.find<LiveMusicState>();
  QuerySnapshot<Map<String, dynamic>> liveMusicsSnap = await firebaseInstance
      .collection('events')
      .where(
        'show.type',
        isEqualTo: eventTypeToString(EventType.LIVEMUSIC),
      )
      .where(
        'is_active',
        isEqualTo: true,
      )
      .where('end_time', isGreaterThanOrEqualTo: DateTime.now())
      .limit(10)
      .get();

  List<EventModel> liveMusics = liveMusicsSnap.docs.map((doc) => EventModel.fromJson({'id': doc.id, ...doc.data()})).toList();

  liveMusicsState.setLiveMusics = liveMusics;
  return liveMusics;
}
