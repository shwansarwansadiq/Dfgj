import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/utils/app_texts.dart';

import '../controllers/auth_controller.dart';
import '../main.dart';
import '../models/user_model.dart';
import '../utils/app_function.dart';

class UserService {
  Future saveUserData(
    String id,
    String username,
    String email,
  ) async {
    AuthState authState = Get.find<AuthState>();
    String currentLang = Get.locale!.languageCode;

    if (id == "") {
      Get.snackbar(AppTexts.error.tr, AppTexts.user_does_not_exist.tr);
      return false;
    }
    String userType = userTypeToString(authState.getUserType!);

    await FirebaseFirestore.instance.collection('customers').doc(id).set({
      'id': id,
      'email': email,
      'fullName': username,
      'created_at': DateTime.now(),
      'language': currentLang,
      'userType': userType,
    });
    setUserRoleLocal = UserType.CUSTOMER;
    getUserApi();
  }

  Future updateUserData(
    String username,
    String phone,
  ) async {
    String id = FirebaseAuth.instance.currentUser!.uid;

    await FirebaseFirestore.instance.collection('customers').doc(id).update({
      'id': id,
      'fullName': username,
      'phone': phone,
    });
    setUserRoleLocal = UserType.CUSTOMER;
    getUserApi();
  }

  Future<UserModel?> getUserApi() async {
    if (FirebaseAuth.instance.currentUser == null) return null;
    String? userId = FirebaseAuth.instance.currentUser?.uid;
    if (userId == null) return null;
    UserType? userType = await getUserTypeFromLocal;
    if (userType == null) return null;
    AuthState authState = Get.find<AuthState>();
    String userTypeString = userTypeToCollectionName(userType);
    if (userTypeString == "CUSTOMER") {
      await updateUserLangApi();
    }

    firebaseInstance.doc('$userTypeString/$userId').snapshots().listen((event) {
      if (event.exists) {
        UserModel user = UserModel.fromJson({
          ...event.data() as Map<String, dynamic>,
          'id': event.id,
          'state': UserState.LOGEDIN
        });
        authState.user.value = user;
      } else {
        return;
      }
    });
    return null;
  }

  Future<bool> checkUserExists(String userId) async {
    DocumentSnapshot snap = await FirebaseFirestore.instance
        .collection('customers')
        .doc(userId)
        .get();
    if (snap.exists) {
      debugPrint('User Exists');
      return true;
    } else {
      debugPrint('new user');
      return false;
    }
  }

  Future<UserModel> getUserData() async {
    final String userId = FirebaseAuth.instance.currentUser!.uid;
    final DocumentSnapshot snap = await FirebaseFirestore.instance
        .collection('customers')
        .doc(userId)
        .get();
    UserModel user = UserModel.fromJson(
        {'id': snap.id, ...snap.data() as Map<String, dynamic>});
    return user;
  }

  Future<bool> updateUserLangApi() async {
    if (FirebaseAuth.instance.currentUser == null) {
      return false;
    }
    try {
      String currentLang = Get.locale!.languageCode;
      String? userId = FirebaseAuth.instance.currentUser!.uid;

      await firebaseInstance
          .collection('customers')
          .doc(userId)
          .update({'language': currentLang});
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> deleteAccountApi() async {
    if (FirebaseAuth.instance.currentUser == null) {
      return false;
    }
    try {
      String? userId = FirebaseAuth.instance.currentUser!.uid;
      await firebaseInstance.collection('customers').doc(userId).delete();
      return true;
    } catch (e) {
      return false;
    }
  }
}

class UserServiceProvider extends GetxController {
  final UserService _userService = UserService();
  Future<UserModel?> getUser() async {
    return await _userService.getUserApi();
  }

  saveUser() async {
    // return await _userService.saveUserData();
  }

  Future<bool> checkIfUserExists({required String id}) async {
    return await _userService.checkUserExists(id);
  }

  Future<bool> updateUserLang() async {
    return await _userService.updateUserLangApi();
  }

  Future<bool> deleteAccount() async {
    return await _userService.deleteAccountApi();
  }
}
