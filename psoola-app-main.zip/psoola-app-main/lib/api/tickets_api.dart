import 'dart:core';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/ticket_model.dart';
import 'package:psoola/states/tickets_state.dart';

import '../main.dart';
import '../models/seat_design_model.dart';
import '../states/ticket_state.dart';

fetchTicketsApi() async {
  TicketsState ticketsState = Get.find<TicketsState>();
  if (FirebaseAuth.instance.currentUser == null) {
    return;
  }
  String uid = FirebaseAuth.instance.currentUser!.uid;
  QuerySnapshot querySnapshot = await firebaseInstance
      .collection('tickets')
      .where('userId', isEqualTo: uid)
      .where('event.end_time', isGreaterThan: DateTime.now())
      .orderBy('event.end_time')
      .orderBy('createdAt', descending: true)
      .get();

  if (querySnapshot.docs.isEmpty) {
    ticketsState.setCustomerTickets = [];
    return [];
  }

  List<TicketModel> tickets = querySnapshot.docs
      .map((doc) => TicketModel.fromJson(
          {'id': doc.id, ...doc.data() as Map<String, dynamic>}))
      .toList();

  ticketsState.setCustomerTickets = tickets;
  return tickets;
}

fetchExpiredTicketsApi() async {
  TicketsState ticketsState = Get.find<TicketsState>();
  if (FirebaseAuth.instance.currentUser == null) {
    return;
  }
  String uid = FirebaseAuth.instance.currentUser!.uid;
  QuerySnapshot querySnapshot = await firebaseInstance
      .collection('tickets')
      .where('userId', isEqualTo: uid)
      .where('event.end_time', isLessThan: DateTime.now())
      .get();

  if (querySnapshot.docs.isEmpty) {
    ticketsState.setExpiredTickets = [];
    return [];
  }
  List<TicketModel> tickets = querySnapshot.docs
      .map((doc) => TicketModel.fromJson(
          {'id': doc.id, ...doc.data() as Map<String, dynamic>}))
      .toList();

  ticketsState.setExpiredTickets = tickets;
  return tickets;
}

Stream<QuerySnapshot<Map<String, dynamic>>> checkTicketPurchaseApi() {
  final TicketState ticketState = Get.find<TicketState>();
  EventModel event = ticketState.getSelectedEvent!;
  TicketsState ticketsState = Get.find<TicketsState>();
  if (FirebaseAuth.instance.currentUser == null) {
    ticketsState.isNewTicket.value = null;
  }
  String uid = FirebaseAuth.instance.currentUser!.uid;
  return firebaseInstance
      .collection('tickets')
      .where('userId', isEqualTo: uid)
      .where('eventId', isEqualTo: event.id)
      .snapshots();
}

Future<bool> checkTicketApi(ticketId, [isRecheck = false]) async {
  DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
      await firebaseInstance.collection('tickets').doc(ticketId).get();
  if (isRecheck) {
    if (documentSnapshot.exists) {
      if (documentSnapshot.data()!['isUsed'] == true ||
          documentSnapshot.data()!['isUsed'] == null) {
        await firebaseInstance
            .collection('tickets')
            .doc(ticketId)
            .update({'isUsed': false});

        return true;
      } else {
        return false;
      }
    }
  } else {
    if (documentSnapshot.exists) {
      if (documentSnapshot.data()!['isUsed'] == false ||
          documentSnapshot.data()!['isUsed'] == null) {
        await firebaseInstance
            .collection('tickets')
            .doc(ticketId)
            .update({'isUsed': true});

        await fetchSingleTicketApi(ticketId: ticketId);

        return true;
      } else {
        return false;
      }
    }
  }
  return false;
}

//fetch single ticket
Future<TicketModel?> fetchSingleTicketApi({required String ticketId}) async {
  TicketsState ticketsState = Get.find<TicketsState>();
  DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
      await firebaseInstance.collection('tickets').doc(ticketId).get();
  if (documentSnapshot.exists) {
    TicketModel ticket = TicketModel.fromJson(
        {'id': documentSnapshot.id, ...documentSnapshot.data()!});
    ticketsState.setSingleTicket = ticket;
    return ticket;
  }
  return null;
}

Future<SingleSeatModel?> fetchEventSeatApi(
    {required String placeId, required String hallId, required seatId}) async {
  DocumentSnapshot documentSnapshot = await firebaseInstance
      .collection('places')
      .doc(placeId)
      .collection('halls')
      .doc(hallId)
      .collection('seats')
      .doc(seatId)
      .get();

  if (documentSnapshot.exists) {
    SingleSeatModel seat = SingleSeatModel.fromJson(
        {'id': documentSnapshot.id, ...documentSnapshot.data()! as Map});
    return seat;
  } else {
    return null;
  }
  return null;
}
