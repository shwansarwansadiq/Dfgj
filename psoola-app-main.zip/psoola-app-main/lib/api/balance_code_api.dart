import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/utils/app_texts.dart';

import '../utils/toast.dart';

Future<bool> addBalanceCodeApi(
    {required String code, required BuildContext context}) async {
  try {
    if (FirebaseAuth.instance.currentUser == null) return false;

    var addBalanceCloudFunction = FirebaseFunctions.instanceFor(
      region: 'europe-west3',
    ).httpsCallable('insertBalanceCard');
    var result = await addBalanceCloudFunction.call({
      'pinCode': code,
    });

    if (result.data['error'] != null) {
      openToast(context, result.data['error']);
    } else {
      AuthState authState = Get.find<AuthState>();
      var balance = result.data['balance'];

      openToast(context, '${AppTexts.balance_added_successfully.tr}: $balance');
      // update user model
      authState.user.value.balance = balance;
    }

    return true;
  } catch (e) {
    return false;
  }
}

// check if balance is added to user
Stream<int> checkIfBalanceAddedToUser() {
  try {
    if (FirebaseAuth.instance.currentUser == null) return Stream.value(0);
    String userId = FirebaseAuth.instance.currentUser!.uid;
    var balance = FirebaseFirestore.instance
        .collection('customers')
        .doc(userId)
        .snapshots()
        .asyncMap((event) => event.data()!['balance'] ?? 0);
    return balance as Stream<int>;
  } catch (e) {
    return Stream.value(0);
  }
}
