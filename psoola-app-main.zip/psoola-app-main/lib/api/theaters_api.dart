import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/states/theater_state.dart';

import '../main.dart';

class TheaterApi {
  Future<List<EventModel>> fetchTheatersApi() async {
    TheatersState theatersState = Get.find<TheatersState>();
    QuerySnapshot<Map<String, dynamic>> theatersSnap = await firebaseInstance
        .collection('events')
        .where(
          'show.type',
          isEqualTo: eventTypeToString(EventType.THEATER),
        )
        .where(
          'is_active',
          // TODO change to true
          isEqualTo: true,
        )
        .where('end_time', isGreaterThanOrEqualTo: DateTime.now())
        .limit(10)
        .get();

    List<EventModel> theaters = theatersSnap.docs.map((doc) => EventModel.fromJson({'id': doc.id, ...doc.data()})).toList();

    theatersState.setTheaters = theaters;
    return theaters;
  }
}
