import 'dart:developer';
import 'dart:io';

import 'package:bluelab_dialog/panara_dialogs.dart';
import 'package:flutter/material.dart';
import 'package:flutter_beep/flutter_beep.dart';
import 'package:get/get.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:sunmi_scanner/sunmi_scanner.dart';

import '../api/tickets_api.dart';
import '../components/cards/ticket_card.dart';
import '../states/tickets_state.dart';
import '../utils/app_animations.dart';
import '../utils/app_defaults.dart';
import '../utils/app_texts.dart';

class QrLaserScanner extends StatefulWidget {
  const QrLaserScanner({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _QrLaserScannerState();
}

class _QrLaserScannerState extends State<QrLaserScanner> {
  String currentLang = Get.locale!.languageCode;
  Barcode? result;
  bool functionResult = false;
  Color backgroundColor = Colors.lightBlue;
  QRViewController? controller;
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  TicketsState ticketsState = Get.find<TicketsState>();

  @override
  void reassemble() {
    super.reassemble();
    if (Platform.isAndroid) {
      controller!.pauseCamera();
    }
    controller!.resumeCamera();
  }

  void _setScannedValue(String value) {
    checkQrCode(value);
  }

  @override
  void initState() {
    super.initState();
    SunmiScanner.onBarcodeScanned().listen((event) {
      _setScannedValue(event);
      print("******************");
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TicketsState>(
      builder: (state) => Scaffold(
        backgroundColor: backgroundColor,
        body: Column(
          children: <Widget>[
            // Expanded(flex: 3, child: _buildQrView(context)),
            Expanded(
              flex: 1,
              child: ClipRRect(
                child: FittedBox(
                  fit: BoxFit.none,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      if (result != null)
                        Column(
                          children: [
                            Text('the scanned code is ${result!.code!}'),
                            Text(
                              'Status: Ticket is  ${functionResult ? 'valid' : 'invalid'}',
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Row(
                              children: [
                                ElevatedButton(
                                    onPressed: () {
                                      controller!.resumeCamera();
                                      state.setSingleTicket = null;

                                      setState(() {
                                        result = null;
                                        backgroundColor = Colors.lightBlue;
                                      });
                                    },
                                    child: const Text('Resume Camera')),
                                const SizedBox(
                                  width: 20,
                                ),
                              ],
                            )
                          ],
                        )
                      else
                        const Text('Please scan a code',
                            style: TextStyle(fontSize: 20)),
                    ],
                  ),
                ),
              ),
            ),
            state.getSingleTicket != null
                ? Container(
                    padding: const EdgeInsets.all(15),
                    color: Theme.of(context).colorScheme.background,
                    child: TicketCard(
                      currentLang: currentLang,
                      ticket: state.getSingleTicket!,
                    ),
                  )
                : const SizedBox()
          ],
        ),
      ),
    );
  }

  Widget _buildQrView(BuildContext context) {
    double scanArea = (Get.width < 400 || Get.height < 400) ? 200.0 : 300.0;

    return QRView(
      key: qrKey,
      formatsAllowed: const [BarcodeFormat.qrcode],
      onQRViewCreated: _onQRViewCreated,
      overlay: QrScannerOverlayShape(
          borderColor: Theme.of(context).primaryColor,
          borderRadius: AppDefaults.radius,
          borderLength: 30,
          borderWidth: 10,
          cutOutSize: scanArea),
      onPermissionSet: (ctrl, p) => _onPermissionSet(context, ctrl, p),
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    setState(() {
      this.controller = controller;
    });
    controller.scannedDataStream.listen((scanData) async {
      controller.pauseCamera();

      setState(() {
        result = scanData;
      });
      checkQrCode(result!.code!);
    });
  }

  checkQrCode(String code) async {
    functionResult = await checkTicketApi(code, false);
    if (functionResult) {
      FlutterBeep.beep();
      setState(() {
        backgroundColor = Colors.lightGreen;
      });
    } else {
      FlutterBeep.beep(false);
      showAlert(context);
      setState(() {
        backgroundColor = Colors.redAccent;
      });
    }
  }

  void _onPermissionSet(BuildContext context, QRViewController ctrl, bool p) {
    log('${DateTime.now().toIso8601String()}_onPermissionSet $p');
    if (!p) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('no Permission')),
      );
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  showAlert(BuildContext contex) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: "Reset ticket",
      message: "This ticket is already used, do you want to reset it?",
      confirmButtonText: AppTexts.reset.tr,
      textColor: Theme.of(context).textTheme.bodyLarge!.color,
      cancelButtonText: AppTexts.cancel.tr,
      onTapCancel: () {
        Get.back();
      },
      onTapConfirm: () async {
        ticketsState.setSingleTicket = null;
        await checkTicketApi(result!.code!, true);
        await controller!.resumeCamera();
        setState(() {
          result = null;
          backgroundColor = Colors.lightBlue;
          Get.back();
        });
      },
      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true,
    );
  }
}
