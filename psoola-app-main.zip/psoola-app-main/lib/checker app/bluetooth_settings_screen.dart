// import 'package:flutter/material.dart';
// import 'dart:async';
// import 'package:blue_thermal_printer/blue_thermal_printer.dart';
// import 'package:flutter/services.dart';

// import '../utils/app_printer.dart';

// class BluethoothSettingsScreens extends StatefulWidget {
//   @override
//   _BluethoothSettingsScreensState createState() =>
//       _BluethoothSettingsScreensState();
// }

// class _BluethoothSettingsScreensState extends State<BluethoothSettingsScreens> {
//   BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

//   List<BluetoothDevice> _devices = [];
//   BluetoothDevice? _device;
//   TestPrint testPrint = TestPrint();

 

//     if (!mounted) return;
//     setState(() {
//       _devices = devices;
//     });

//     if (isConnected == true) {
//       setState(() {});
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
        
//         body: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: ListView(
//             children: <Widget>[
//               const SizedBox(height: 10),
//               Padding(
//                 padding:
//                     const EdgeInsets.only(left: 10.0, right: 10.0, top: 50),
//                 child: ElevatedButton(
//                   style:
//                       ElevatedButton.styleFrom(backgroundColor: Colors.brown),
//                   onPressed: () {},
//                   child: const Text('PRINT TEST',
//                       style: TextStyle(color: Colors.white)),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }

//   List<DropdownMenuItem<BluetoothDevice>> _getDeviceItems() {
//     List<DropdownMenuItem<BluetoothDevice>> items = [];
//     if (_devices.isEmpty) {
//       items.add(const DropdownMenuItem(
//         child: Text('NONE'),
//       ));
//     } else {
//       for (var device in _devices) {
//         items.add(DropdownMenuItem(
//           value: device,
//           child: Text(device.name ?? ""),
//         ));
//       }
//     }
//     return items;
//   }

//   void _connect() {
//     if (_device != null) {
//       bluetooth.isConnected.then((isConnected) {
//         if (isConnected == false) {
//           bluetooth.connect(_device!).catchError((error) {});
//         }
//       });
//     } else {
//       show('No device selected.');
//     }
//   }

//   void _disconnect() {
//     bluetooth.disconnect();
//   }

//   Future show(
//     String message, {
//     Duration duration = const Duration(seconds: 3),
//   }) async {
//     await Future.delayed(Duration(milliseconds: 100));
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(
//           message,
//           style: const TextStyle(color: Colors.white),
//         ),
//         duration: duration,
//       ),
//     );
//   }
// }
