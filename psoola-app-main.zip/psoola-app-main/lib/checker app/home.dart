import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:psoola/auth/checker_signin.dart';
import 'package:psoola/check_user.dart';
import 'package:psoola/checker%20app/LaserScanner.dart';
import 'package:psoola/checker%20app/bluetooth_settings_screen.dart';
import 'package:psoola/screens/all%20events/all_events.dart';
import 'package:psoola/screens/tabs/tickets/tickets_tabs.dart';
import 'package:psoola/utils/app_icons.dart';

import '../utils/app_animations.dart';
import 'CameraScanner.dart';

class CheckerHomePage extends StatefulWidget {
  CheckerHomePage({Key? key}) : super(key: key);

  @override
  State<CheckerHomePage> createState() => _CheckerHomePageState();
}

class _CheckerHomePageState extends State<CheckerHomePage> {
  bool? isConnected = false;
  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

  @override
  void setState(VoidCallback fn) {
    // TODO: implement setState
    super.setState(fn);
    initBluetooth();
  }

  initBluetooth() async {
    isConnected = await bluetooth.isConnected;
    List<BluetoothDevice> devices = [];
    try {
      devices = await bluetooth.getBondedDevices();
    } on PlatformException {}

    bluetooth.onStateChanged().listen((state) {
      switch (state) {
        case BlueThermalPrinter.CONNECTED:
          setState(() {
            isConnected = true;
            print("bluetooth device state: connected");
          });
          break;
        case BlueThermalPrinter.DISCONNECTED:
          setState(() {
            isConnected = false;
            print("bluetooth device state: disconnected");
          });
          break;

        default:
          print("bluetooth device state: $state");
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: TextButton(
            onPressed: () {
              authState.logout().then((value) {
                Get.offAll(() => CheckUser());
              });
            },
            child: const Text(
              'Logout',
              style: TextStyle(),
            ),
          ),
          actions: [],
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                const Spacer(),
                Lottie.asset(
                  AppAnimations.scanning,
                  width: Get.width * 0.6,
                  height: Get.width * 0.6,
                ),
                customButton(AppIcons.ticket_outline, 'Buy Ticket',
                    () => Get.to(() => const AllEvents())),
                const SizedBox(
                  height: 30,
                ),
                customButton(AppIcons.camera, 'Scan with Camera',
                    () => Get.to(() => const QrCammeraScanner())),
                const SizedBox(
                  height: 30,
                ),
                customButton(AppIcons.scanner, 'Scan with Laser',
                    () => Get.to(() => const QrLaserScanner())),
                const Spacer(),
              ],
            ),
          ),
        ));
  }

  Widget customButton(String icon, String text, Function() onPressed) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
          ),
          onPressed: () {
            onPressed();
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(text),
              const SizedBox(
                width: 10,
              ),
              SvgPicture.asset(
                icon,
                width: 30,
                height: 30,
                fit: BoxFit.cover,
              )
            ],
          )),
    );
  }
}
