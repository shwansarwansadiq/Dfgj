import 'package:awesome_bottom_bar/awesome_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_vibrate/flutter_vibrate.dart';
import 'package:get/get.dart';
import 'package:psoola/screens/tabs/tickets/tickets_tabs.dart';
import 'package:psoola/utils/app_icons.dart';
import 'package:psoola/utils/app_texts.dart';

import '../screens/tabs/home/home_tab.dart';
import '../screens/tabs/profile/profile_tab.dart';
import '../states/tickets_state.dart';

class CustomerNav extends StatefulWidget {
  const CustomerNav({Key? key}) : super(key: key);

  @override
  State<CustomerNav> createState() => CustomerNavState();
}

class CustomerNavState extends State<CustomerNav> {
  int currentWidget = 0;

  List<Widget> widgets = [
    const HomeTab(),
    // const SearchTab(),
    const TicketsTab(),
    ProfileTab(),
  ];

  @override
  void initState() {
    TicketsState ticketsState = Get.find<TicketsState>();
    currentWidget = ticketsState.getSelectedTab;
    ticketsState.setSelectedTab = 0;
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  CountStyle countStyle = const CountStyle(
    background: Colors.white,
    color: Colors.purple,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: false,
      backgroundColor: Theme.of(context).colorScheme.background,
      body: widgets[currentWidget],
      bottomNavigationBar: Container(
        height: GetPlatform.isIOS ? 80 : 60,
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black12.withOpacity(0.1),
              spreadRadius: 5,
              blurRadius: 10,
              offset: const Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: BottomNavigationBar(
          iconSize: 25,
          elevation: 10,
          selectedLabelStyle: TextStyle(
            color: Theme.of(context).primaryColor,
            fontSize: 12,
          ),
          currentIndex: currentWidget,
          onTap: (index) {
            setState(() {
              currentWidget = index;
            });
            GetPlatform.isIOS
                ? Vibrate.feedback(FeedbackType.medium)
                : Vibrate.feedback(FeedbackType.medium);
          },
          items: [
            BottomNavigationBarItem(
              icon: SvgPicture.asset(
                AppIcons.home_outline,
                color: Colors.grey,
              ),
              activeIcon: SvgPicture.asset(
                AppIcons.home_filled,
                color: Theme.of(context).primaryColor,
              ),
              label: AppTexts.home.tr,
            ),
            // BottomNavigationBarItem(
            //   icon: const Icon(Icons.search),
            //   label: AppTexts.search.tr,
            // ),
            BottomNavigationBarItem(
              icon: SvgPicture.asset(
                AppIcons.ticket_outline,
                color: Colors.grey,
              ),
              activeIcon: SvgPicture.asset(
                AppIcons.ticket_filled,
                color: Theme.of(context).primaryColor,
              ),
              label: AppTexts.tickets.tr,
            ),
            BottomNavigationBarItem(
              icon: SvgPicture.asset(
                AppIcons.profile_outline,
                color: Colors.grey,
              ),
              activeIcon: SvgPicture.asset(
                AppIcons.profile_filled,
                color: Theme.of(context).primaryColor,
              ),
              label: AppTexts.profile.tr,
            ),
          ],
        ),
      ),
    );
  }
}
