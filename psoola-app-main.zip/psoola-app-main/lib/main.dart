import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:psoola/api/user_api.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/controllers/event_view_controller.dart';
import 'package:psoola/notification_handler.dart';
import 'package:psoola/states/about_us_state.dart';
import 'package:psoola/states/cast_state.dart';
import 'package:psoola/states/concert_state.dart';
import 'package:psoola/states/event_events_state.dart';
import 'package:psoola/states/event_state.dart';
import 'package:psoola/states/genres_state.dart';
import 'package:psoola/states/live_music_state.dart';
import 'package:psoola/states/location/district_state.dart';
import 'package:psoola/states/location/neighborhood_state.dart';
import 'package:psoola/states/location/province_state.dart';
import 'package:psoola/states/movies_state.dart';
import 'package:psoola/states/places_state.dart';
import 'package:psoola/states/shows_state.dart';
import 'package:psoola/states/swiper_state.dart';
import 'package:psoola/states/theater_state.dart';
import 'package:psoola/states/ticket_state.dart';
import 'package:psoola/states/tickets_state.dart';

import 'checker app/bluetooth_settings_screen.dart';
import 'components/seat/controller/seat_item_controller copy.dart';
import 'components/seat/controller/seat_widget_controller.dart';
import 'firebase_options.dart';
import 'services/dark_theme.dart';
import 'services/language_service.dart';
import 'services/light_theme.dart';
import 'services/theme_service.dart';
import 'states/event_selection_controller.dart';
import 'translation.dart';

final navigatorConextKey = GlobalKey<NavigatorState>();
final firebaseInstance = FirebaseFirestore.instance;

void main() async {
      GetStorage.init();
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  initState() {
    super.initState();
    firebaseInstance.settings = const Settings(
      persistenceEnabled: true,
      cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
    );
    EasyLoading.instance
      ..indicatorType = EasyLoadingIndicatorType.fadingCircle
      ..loadingStyle = EasyLoadingStyle.dark
      ..userInteractions = false
      ..dismissOnTap = false;
  }

  @override
  Widget build(BuildContext context) {
    Get.put(ShowsState());
    Get.put(PlacesState());
    Get.put(GenresState());
    Get.put(ProvinceState());
    Get.put(DistrictState());
    Get.put(NeighborhoodState());
    Get.put(AboutUsState());
    Get.put(AuthState());
    Get.put(MoviesState());
    Get.put(LiveMusicState());
    Get.put(TheatersState());
    Get.put(ConcertsState());
    Get.put(EventsState());
    Get.put(UpdateView());
    Get.put(SwiperEventsState());
    Get.put(TicketState());
    Get.put(TicketsState());
    Get.put(CastsState());
    Get.put(EventEventsState());
    Get.put(UserServiceProvider());
    Get.put(EventSelectionController());
    Get.put(SeatWidgetController());
    Get.put(SeatItemController());
    // deleteAllNotifications();
    // authState.logout();

    return GetMaterialApp(
        navigatorKey: navigatorConextKey,
        locale: Locale(LanguageService().language),
        translations: OnlinePsoolaTranslation(),
        defaultTransition: Transition.cupertino,
        debugShowCheckedModeBanner: false,
        theme: theme(),
        darkTheme: darkTheme(),
        builder: EasyLoading.init(),
        themeMode: ThemeService().theme,
        home: const NotificationHandler());
  }
}
