// ignore_for_file: non_constant_identifier_names, constant_identifier_names

class AppTexts {
  static const String invalidNumber = 'invalid_number';
  static const String name = 'name';
  static const String complete_profile = 'complete_profile';
  static const String please_below_select_category =
      'please_below_select_category';
  static const String select_category = 'select_category';
  static const String about = 'about';
  static const String reset = 'reset';
  static const String loginAsChecker = 'login_as_checker';
  static const String inHour = 'in_hour';
  static const String successfully_purchased = 'successfully_purchased';
  static const String pleaseEnterTwelveDigits = 'please_enter_twelve_digits';
  static const String availableEvents = 'available_events';
  static const String showMore = 'show_more';
  static const String showLess = 'show_less';
  static const String or = 'or';
  static const String success = 'success';
  static const String your_review_successfully_added =
      'your_review_successfully_added';
  static const String edit_your_review = 'edit_your_review';
  static const String add_your_review = 'add_your_review';
  static const String you_are_not_logged_in = 'you_are_not_logged_in';
  static const String create_account = 'create_account';
  static const String please_create_account_to_comment =
      'please_create_account_to_comment';
  static const String see_all_review = 'see_all_review';
  static const String no_comment_added = 'no_comment_added';
  static const String people = 'people';
  static const String what_people_say = 'what_people_say';
  static const String from_sum_of = 'from_sum_of';
  static const String yourReview = 'your_review';
  static const String setStarHere = 'set_star_here';
  static const String writeYourCommentHere = 'write_your_comment_here';
  static const String developedBy = 'developed_by';
  static const String PleaseFirstLoginOrCreateAnAccount =
      'please_first_login_or_create_an_account';
  static const String fullName = 'full_name';
  static const String fillTheFormBelowToContinue =
      'fill_the_form_below_to_continue';
  static const String noCastInformationHasBeenFound =
      'no_cast_information_has_been_found';
  static const String selectCity = 'select_city';
  static const String pleaseSelectCity = 'please_select_city';
  static const String welcomeToPsoola = 'welcome_to_psoola';
  static const String pleaseLoginOrRegister = 'please_login_or_register';
  static const String youDonthaveAccount = 'you_dont_have_account';
  static const String noNotifications = 'no_notifications';
  static const String deleteAll = 'delete_all';
  static const String noExpiredTickets = 'no_expired_tickets';
  static const String noExpiredTicketsHaveBeenFound =
      'no_expired_tickets_have_been_found';
  static const String loginToSeeYourTickets = 'login_to_see_your_tickets';
  static const String noTickets = 'no_tickets';
  static const String youDontHaveAnyTicketsYet =
      'you_dont_have_any_tickets_yet';
  static const String reachUs = 'reach_us';
  static const String pleaseFeelFreeToContactUsAtAnyTime =
      'please_feel_free_to_contact_us_at_any_time';
  static const String ourLocation = 'our_location';
  static const String ourSocialMedia = 'our_social_media';
  static const String welcome_to_psoola_customer_service =
      'welcome_to_psoola_customer_service';

  static const String we_are_here_to_help_you_desc =
      'we_are_here_to_help_you_with_any_questions_you_may_have_about_psoola';

  static const String endDate = 'end_date';
  static const String startDate = 'start_date';
  static const String pleaseTryAgain = 'please_try_again';
  static const String fileDownloadedTo = "file_downloaded_to";
  static const String fileDownloaded = 'file_downloaded';
  static const String seat = 'seat';
  static const String time = 'time';
  static const String date = 'date';
  static const String thanksForYourPurchase = 'thanks_for_your_purchase';
  static const String download = 'download';
  static const String purchaseCode = 'purchase_code';
  static const String map = 'map';
  static const String director = 'director';
  static const String geners = 'geners';
  static const String cast = 'cast';
  static const String review = 'review';
  static const String actors = 'actors';
  static const String year = 'year';
  static const String country = 'country';
  static const String rating = 'rating';
  static const String duration = 'duration';
  static const String description = 'description';

  static const String buy_ticket = 'buy_ticket';
  static const String select_cinema = 'select_cinema';
  static const String select_date = 'select_date';
  static const String please_below_select_date_and_time =
      'please_below_select_date_and_time';
  static const String please_below_select_cinema = 'please_below_select_cinema';
  static const String see_all = 'see_all';
  static const String payment = 'payment';
  static const String number = 'number';
  static const String discount = 'discount';
  static const String byPurchasingYouAgreeToOurTermsAndConditions =
      'by_purchasing_you_agree_to_our_terms_and_conditions';
  static const String paymentMethod = 'payment_method';
  static const String total = 'total';
  static const String skip = 'skip';
  static const String callUs = 'call_us';
  static const String emailUs = 'email_us';
  static const String loginAsTicketProvider = 'login_as_ticket_provider';
  static const String email = 'email';
  static const String password = 'password';
  static const String getStarted = 'get_started';
  static const String areYouSureYouWantToLogout =
      "are_you_sure_you_want_to_logout?";

  static const String sendOTP = "send_otp";
  static const String dontHaveAnAccount = "dont_have_an_account";
  static const String selectProvince = "select_province";

  static const String font = 'font';
  static const String help = 'help';
  static const String pleaseWait = 'please_wait';
  static const String phoneNumber = 'phone_number';
  static const String pleaseLogin = 'please_login';
  static const String youHaveAnAccount = 'you_have_an_account?';
  static const String pleaseEnterValidNumber = 'please_enter_valid_number';
  static const String pleaseEnterYourNumber = 'please_enter_you_number';
  static const String pleaseEnterYourName = 'please_enter_your_name';
  static const String enterYourPhoneNumber = 'enter_your_phone_number';
  static const String error = 'error';
  static const String ok = 'ok';
  static const String cancel = 'cancel';
  static const String userDoesNotExists = 'user_does_not_exists';
  static const String myTickets = 'my_tickets';
  static const String availableTickets = 'available_tickets';
  static const String expiredTickets = 'expired_tickets';
  static const String ticketDetails = 'ticket_details';
  static const String appName = 'psoola';
  static const String home = 'home';
  static const String tickets = 'tickets';
  static const String search = 'search';
  static const String profile = 'profile';
  static const String login = 'login';
  static const String register = 'register';
  static const String movies = 'movies';
  static const String theaters = 'theaters';
  static const String event = 'event';
  static const String events = 'events';
  static const String liveMusic = 'live_music';
  static const String liveMusics = 'live_musics';
  static const String concerts = 'concerts';
  static const String settings = 'settings';
  static const String logout = 'logout';
  static const String aboutUs = 'about_us';
  static const String customerService = 'customer_service';
  static const String sharePsoola = 'share_psoola';
  static const String language = 'language';
  static const String darkMode = 'dark_mode';
  static const String notifications = 'notifications';
  static const String termsAndConditions = 'terms_and_conditions';
  static const String continue_text = 'continue';
  static const String categories = 'categories';
  static const String slideOne = 'slide_one';
  static const String slideTwo = 'slide_two';
  static const String slideThree = 'slide_three';
  static const String slideThreeSubtitle = 'slide_three_subtitle';
  static const String slideTwoSubtitle = 'slide_two_subtitle';
  static const String slideOneSubtitle = 'slide_one_subtitle';
  static const String select_your_language = 'select_your_language';
  static const String termsAndConditionsTitle = 'terms_and_conditions';

  static const String reserved_seat = 'reserved_seat';

  static const String seat_available = 'seat_available';

  static const String your_seat = 'your_seat';

  static const String seat_reserved = 'seat_reserved';

  static const String your_wallet = 'your_wallet';

  static const String you_dont_have_enough_credit =
      'you_dont_have_enough_credit';

  static const String your_balance = 'your_balance';

  static const String recharge = 'recharge';

  static const String please_choose_one_of_the_following_payment_methods =
      'please_choose_one_of_the_following_payment_methods';

  static const String confirm = 'confirm';

  static const String send_balance = 'send_balance';

  static const String send_card = 'send_card';

  static const String card_number = 'card_number';

  static const String PleaseBelowWriteSecretCardNumber =
      'PleaseBelowWriteSecretCardNumber';

  static const String seats = 'seats';

  static const String user_does_not_exist = 'user_does_not_exist';

  static const String main = 'main';

  static const String reviews = 'reviews';

  static const String please_select_cinema = 'please_select_cinema';

  static const String please_select_date = 'please_select_date';

  static const String please_select_time = 'please_select_time';

  static const String first_you_need_to_register = 'first_you_need_to_register';

  static const String first_you_need_to_create_an_account =
      'first_you_need_to_create_an_account';

  static const String trailer = 'trailer';

  static const String please_select_datetime = 'please_select_datetime';

  static const String please_select_event_datetime =
      'please_select_event_datetime';

  static const String price = 'price';

  static const String add_balance = 'add_balance';

  static const String add_balance_to_your_wallet = 'add_balance_to_your_wallet';

  static const String enter_code = 'enter_code';

  static const String submit = 'submit';

  static const String please_enter_balance_code = 'please_enter_balance_code';

  static const String balance_added_successfully = 'balance_added_successfully';

  static const String code_uploaded_successfully = 'code_uploaded_successfully';

  static const String checking_code = 'checking_code';

  static const String checking_balance_code = 'checking_balance_code';

  static const currency = 'currency';

  static const String balance = 'balance';

  static const buy_with_your_balance = 'buy_with_your_balance';

  static const are_you_sure = 'are_you_sure';

  static const sorry = 'sorry';

  static const you_do_not_have_enough_balance =
      'you_do_not_have_enough_balance';

  static var select_a_section = 'select_a_section';

  static var select_seat = 'select_seat';

  static var please_select_at_least_one_seat =
      'please_select_at_least_one_seat';

  static var add_seats_for_your_selected_table =
      'add_seats_for_your_selected_table';

  static var minimum_seats_per_table_are_two =
      'minimum_seats_per_table_are_two';

  static var add_seats = 'add_seats';

  static var number_of_chairs = 'number_of_chairs';

  static var table = 'table';

  static var chairs = 'chairs';

  static var user_does_not_exists = 'user_does_not_exists';

  static var filter = 'filter';

  static var delete = "delete";

  static var are_you_sure_you_want_to_delete_your_account =
      "are_you_sure_you_want_to_delete_your_account";

  static var just_english_numbers = "just_english_numbers";

  static var hall = "hall";

  static var please_select_date_time_place = "please_select_date_time_place";

  static var please_select_hall = "please_select_hall";

  static var added_seats = "added_seats";

  static var please_select_category = "please_select_category";

  static var your_event_time = "your_event_time";
}
