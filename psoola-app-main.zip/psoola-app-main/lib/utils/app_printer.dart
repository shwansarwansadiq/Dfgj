import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';
import 'package:psoola/api/payment/payment_api.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/utils/app_texts.dart';
import 'package:psoola/utils/printer_enum.dart';

import '../models/ticket_model.dart';

///Test printing
class TestPrint {
  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

  sample() async {
    EasyLoading.show(status: AppTexts.pleaseWait.tr, dismissOnTap: false, maskType: EasyLoadingMaskType.black);

    List<TicketModel>? tickets = await getLatestTicketApi();

    EasyLoading.dismiss();

    if (tickets != null) {
      bluetooth.isConnected.then((isConnected) {
        if (isConnected == true) {
          for (TicketModel ticket in tickets) {
            bluetooth.printCustom("Psoola", Size.boldLarge.val, Align.center.val);

            // bluetooth.printImageBytes(imageBytesFromAsset); //image from Asset
            bluetooth.printNewLine();
            bluetooth.printCustom(ticket.event.show.title.textEn, Size.bold.val, Align.center.val);

            bluetooth.printNewLine();

            // your event time
            bluetooth.printLeftRight(
                "Event Date", "${ticket.eventDate.day}/${ticket.eventDate.month} - ${ticket.eventDate.hour}:${ticket.eventDate.minute} ", Size.bold.val,
                format: "%-15s %15s %n");

            bluetooth.printNewLine();

            ticket.selectedEventTime != null
                ? bluetooth.printLeftRight(
                    "Seleted Date",
                    "${ticket.selectedEventTime!.day}/${ticket.selectedEventTime!.month} - ${ticket.selectedEventTime!.hour}:${ticket.selectedEventTime!.minute} ",
                    Size.bold.val,
                    format: "%-15s %15s %n")
                : bluetooth.printCustom("", Size.bold.val, Align.center.val);

            bluetooth.printNewLine();

            // if there is added seats print it
            if (ticket.addedSeats != null && ticket.addedSeats != 0 && ticket.addedSeats! > 0) {
              bluetooth.printLeftRight("Added Seats", ticket.addedSeats.toString(), Size.bold.val, format: "%-15s %15s %n");
              bluetooth.printNewLine();
            }
            bluetooth.printNewLine();

            bluetooth.printLeftRight("Price", ticket.price.toString(), Size.bold.val, format: "%-15s %15s %n");
            bluetooth.printNewLine();
            if (ticket.event.show.type != EventType.EVENT) {
              bluetooth.printLeftRight(
                  "Selected Seat",
                  ticket.seatName != null
                      ? ticket.seatName!
                      : ticket.seatId != null
                          ? ticket.seatId!
                          : '',
                  Size.bold.val,
                  format: "%-15s %15s %n");
            } else {
              bluetooth.printLeftRight(
                  "place id",
                  ticket.seatName != null
                      ? ticket.seatName!
                      : ticket.seatId != null
                          ? ticket.seatId!
                          : '',
                  Size.bold.val,
                  format: "%-15s %15s %n");
            }

            bluetooth.printNewLine();
            bluetooth.printCustom("Thank You", Size.bold.val, Align.center.val);
            bluetooth.printNewLine();
            bluetooth.printQRcode(ticket.id.toString(), 200, 200, Align.center.val);
            bluetooth.printNewLine();
            bluetooth.printCustom(
                "${DateTime.now().day}/${DateTime.now().month} - ${DateTime.now().hour}:${DateTime.now().minute}", Size.bold.val, Align.center.val);

            bluetooth.printNewLine();
            bluetooth.paperCut();
          }
        } else {
          Get.snackbar("Error", "Please connect to bluetooth printer");
        }
      });
    } else {
      Get.snackbar("Error", "rrrr");
    }
  }
}
