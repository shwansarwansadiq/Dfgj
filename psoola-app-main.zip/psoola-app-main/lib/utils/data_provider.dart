// ignore_for_file: non_constant_identifier_names

import 'package:psoola/utils/app_texts.dart';

import '../models/onboarding_model.dart';

List<WalkThroughData> WalkThroughDataList() {
  List<WalkThroughData> list = [];
  list.add(WalkThroughData(
      imagePath: "assets/slide_one.svg",
      title: AppTexts.slideOne,
      subtitle: AppTexts.slideOneSubtitle));
  list.add(WalkThroughData(
      imagePath: "assets/slide_two.svg",
      title: AppTexts.slideTwo,
      subtitle: AppTexts.slideTwoSubtitle));
  list.add(WalkThroughData(
      imagePath: "assets/slide_three.svg",
      title: AppTexts.slideThree,
      subtitle: AppTexts.slideThreeSubtitle));

  // list.add(WalkThroughData(imagePath: slide_four, title: Slide_four, subtitle: Slide_four_subtitle));
  return list;
}
