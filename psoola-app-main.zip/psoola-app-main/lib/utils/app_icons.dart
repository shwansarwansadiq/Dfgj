// ignore_for_file: constant_identifier_names

class AppIcons {
  static const String wallet = 'assets/icons/wallet.svg';
  static const String logout = 'assets/icons/logout.svg';
  static const String home_outline = 'assets/icons/home_outline.svg';
  static const String home_filled = 'assets/icons/home_filled.svg';
  static const String ticket_outline = 'assets/icons/ticket_outline.svg';
  static const String ticket_filled = 'assets/icons/ticket_filled.svg';
  static const String search_outline = 'assets/icons/search_outline.svg';
  static const String search_filled = 'assets/icons/search_filled.svg';
  static const String profile_outline = 'assets/icons/profile_outline.svg';
  static const String profile_filled = 'assets/icons/profile_filled.svg';
  static const String popcorn = 'assets/icons/popcorn.svg';
  static const String angleLeft = "assets/icons/fi-rr-angle-left.svg";
  static const String share = "assets/icons/share.svg";
  static const String info = "assets/icons/info.svg";
  static const String lifeRing = "assets/icons/life-ring.svg";
  static const String settings = "assets/icons/settings.svg";
  static const String document = "assets/icons/document.svg";
  static const String bell = "assets/icons/bell.svg";
  static const String world = "assets/icons/world.svg";
  static const String moon = "assets/icons/moon.svg";
  static const String text = "assets/icons/text.svg";
  static const String theatre = "assets/icons/theatre.svg";
  static const String liveMusic = "assets/icons/live-music.svg";
  static const String concert = "assets/icons/concert.svg";

  static const String dollar = 'assets/icons/dollar.svg';

  // seat
  static const String svg_seat_selected = "assets/seats/seat_selected.svg";
  static const String svg_seat_empty = 'assets/seats/seat_empty.svg';
  static const String svg_seat_reserved = 'assets/seats/seat_reserved.svg';

  static const String svg_box_selected = 'assets/seats/box_selected.svg';
  static const String svg_box_reserved = 'assets/seats/box_reserved.svg';
  static const String svg_box_empty = 'assets/seats/box_empty.svg';

  static const String svg_table_selected = 'assets/seats/table_selected.svg';
  static const String svg_table_reserved = 'assets/seats/table_reserved.svg';
  static const String svg_table_empty = 'assets/seats/table_empty.svg';

  static const String svg_ticket_light = 'assets/images/ticket_details.svg';
  static const String svg_ticket_dark = 'assets/images/ticket_dark.svg';

  static var delete = 'assets/icons/delete.svg';

  static const String scanner = 'assets/icons/scanner.svg';
  static const String camera = 'assets/icons/camera.svg';

  static const String unselected_seat =
      'assets/seats/svg_unselected_bus_seat.svg';
  static const String unselected_bus_seat =
      'assets/seats/svg_unselected_bus_seat.svg';
  static const String selected_seat = 'assets/seats/svg_selected_bus_seat.svg';
  static const String disabled_seat = 'assets/seats/svg_disabled_bus_seat.svg';
  static const String sold_seat = 'assets/seats/svg_sold_bus_seat.svg';

  // cinema seats
  static const String cinema_seat_sold = 'assets/seats/cinema_seat/sold.svg';
  static const String cinema_seat_selected =
      'assets/seats/cinema_seat/selected.svg';
  static const String cinema_seat_unselected =
      'assets/seats/cinema_seat/unselected.svg';
}
