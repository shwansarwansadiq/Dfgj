class AppImage {
  static const String smallTicketSvg = 'assets/images/small_ticket.svg';
  static const String smallTicketDark = 'assets/images/small_ticket_dark.svg';
  static const String logo = 'assets/images/logo.png';
  static const String pngBritishFlag = 'assets/images/british_flag.png';
  static const String pngKurdishFlag = 'assets/images/kurdish_flag.png';
  static const String pngIraqFlag = 'assets/images/iraq_flag.jpg';
  static const String ticketSvg = 'assets/images/ticket (1).svg';
  static const String ticketDetailsSvg = 'assets/images/ticket_details.svg';
  static const String fastpayPng = 'assets/images/fastpay.png';
  static const String zaincashPng = 'assets/images/zaincash.png';
  static const String screenPng = 'assets/images/screen.png';
  static const String ticketDarkSvg = 'assets/images/ticket_dark.svg';
  static const String armanLogo = 'assets/images/Group 60.svg';
}
