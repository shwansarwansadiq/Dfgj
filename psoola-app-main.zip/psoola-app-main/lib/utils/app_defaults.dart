class AppDefaults {
  static const double radius = 15.0;

  static const double padding = 16.0;
}
