import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:psoola/utils/app_texts.dart';

class AppCommons {
  static pssolaLoading() {
    return Column(
      children: [
        Lottie.asset(
          'assets/animations/loading.json',
          width: Get.width * 0.5,
          height: Get.height * 0.1,
        ),
        Text(
          AppTexts.pleaseWait.tr,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.normal,
          ),
        ),
      ],
    );
  }
}
