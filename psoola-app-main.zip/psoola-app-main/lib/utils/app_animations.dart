class AppAnimations {
  // static String lottieEditor = 'assets/lottie/editor.json';
  static const String loading = 'assets/animations/loading.json';
  static const String error = 'assets/animations/error.json';
  static const String wallet = 'assets/animations/wallet.json';
  static const String downloaded = 'assets/animations/downloaded.json';
  static const String ticketLottie = 'assets/animations/Cinema tickets.json';
  static const String otpLottie = 'assets/animations/otp.json';
  static const String noTickets = 'assets/animations/tickets.json';
  static const String cinemaFront = 'assets/animations/cinema-front.json';
  static const String oldTv = 'assets/animations/old-tv.json';
  static const String popcorn = 'assets/animations/popcorn.json';
  static const String megaphone = 'assets/animations/megaphone.json';
  static const String language = 'assets/animations/language.json';
  static const String loginDialog = 'assets/animations/login-dialog.json';
  static const String alert = 'assets/animations/alert (1).json';
  static const String comment = 'assets/animations/comment.json';
  static const String scanning = 'assets/animations/scanning.json';
  static const String creditCard = 'assets/animations/credit-card.json';
  static const String login = 'assets/animations/login.json';
}
