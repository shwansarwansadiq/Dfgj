import 'package:bluelab_dialog/panara_dialogs.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:psoola/utils/app_animations.dart';
import 'package:psoola/utils/app_texts.dart';

import '../api/user_api.dart';
import '../auth/auth.dart';
import '../models/user_model.dart';
import '../services/font_service.dart';
import '../services/language_service.dart';

class AppFunction {
  static getColorBasedOnText(String text) {
    int weight = 0;
    for (int i = 0; i < text.length; i++) {
      for (var element in text.runes) {
        weight += element;
      }
    }
    final colorIndex = weight % Colors.primaries.length;
    return Colors.primaries[colorIndex];
  }

  static changeLanguage(Locale locale) {
    Get.updateLocale(locale);
    LanguageService().switchLanguage(locale.languageCode);
    Get.find<UserServiceProvider>().updateUserLang();
    notificationBasedOnLang();
  }

  static String convertTimestampToDateTime(Timestamp timestamp) {
    DateTime dateTime = timestamp.toDate();
    String date = dateTime.day.toString().padLeft(2, '0');
    String month = dateTime.month.toString().padLeft(2, '0');
    String year = dateTime.year.toString();
    String hour = dateTime.hour.toString().padLeft(2, '0');
    String minute = dateTime.minute.toString().padLeft(2, '0');
    return '$date/$month/$year ${AppTexts.inHour.tr} $hour:$minute';
  }

  static convertTimestampToTimeWithAmPm(Timestamp timestamp) {
    DateTime dateTime = timestamp.toDate();
    String hour = dateTime.hour.toString().padLeft(2, '0');
    String minute = dateTime.minute.toString().padLeft(2, '0');
    String amPm = dateTime.hour > 12 ? 'pm'.tr : 'am'.tr;
    return '$hour:$minute $amPm';
  }

  static durationToHour(Duration duration) {
    String time =
        duration.toString().split('.').first.substring(0, 4).padLeft(5, "0");
    return time;
  }

  String convertIntToTime(int time) {
    String timeString = time.toString();
    String hour = timeString.substring(0, 2);
    String minute = timeString.substring(2, 4);
    return '$hour:$minute';
  }

  static changeFontFamily(String fontFamily) {
    FontFamilyService().switchFontFamily(fontFamily);

    Get.forceAppUpdate();
  }

  static notificationBasedOnLang() {
    FirebaseMessaging instance = FirebaseMessaging.instance;
    String currentLang = Get.locale!.languageCode;
    if (currentLang == 'en') {
      instance.subscribeToTopic('all_en');
      instance.unsubscribeFromTopic('all_ar');
      instance.unsubscribeFromTopic('all_kr');
    }
    if (currentLang == 'ar') {
      instance.subscribeToTopic('all_ar');
      instance.unsubscribeFromTopic('all_en');
      instance.unsubscribeFromTopic('all_kr');
    }
    if (currentLang == 'kr') {
      instance.subscribeToTopic('all_kr');
      instance.unsubscribeFromTopic('all_en');
      instance.unsubscribeFromTopic('all_ar');
    }
  }

  static showRegisterDialog(context, String imagePath) {
    PanaraConfirmDialog.show(
      context,
      imagePath: imagePath,
      title: AppTexts.register.tr,
      message: AppTexts.PleaseFirstLoginOrCreateAnAccount.tr,
      confirmButtonText: AppTexts.register.tr,
      cancelButtonText: AppTexts.cancel.tr,

      onTapConfirm: () {
        Get.to(() => const AuthScreen());
      },
      onTapCancel: () {
        Navigator.pop(context);
      },

      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true, // optional parameter (default is true)
    );
  }

  static showPleaseSelectCategoryDialog(context) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: AppTexts.select_category.tr,
      message: AppTexts.please_below_select_category.tr,
      confirmButtonText: AppTexts.ok.tr,
      cancelButtonText: AppTexts.cancel.tr,
      onTapConfirm: () {
        Get.back();
      },
      onTapCancel: () {
        Get.back();
      },
      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true, // optional parameter (default is true)
    );
  }

  static showPleaseSelectDatetimeDialog(context) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: AppTexts.select_date.tr,
      message: AppTexts.please_select_datetime.tr,
      confirmButtonText: AppTexts.ok.tr,
      cancelButtonText: AppTexts.cancel.tr,
      onTapConfirm: () {
        Get.back();
      },
      onTapCancel: () {
        Get.back();
      },
      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true, // optional parameter (default is true)
    );
  }

  static showPleaseSelectSeatFirstDialog(context) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: AppTexts.select_seat.tr,
      message: AppTexts.please_select_at_least_one_seat.tr,
      confirmButtonText: AppTexts.ok.tr,
      cancelButtonText: AppTexts.cancel.tr,
      onTapConfirm: () {
        Get.back();
      },
      onTapCancel: () {
        Get.back();
      },
      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true, // optional parameter (default is true)
    );
  }

  static showPleaseSelectPlaceFirstDialog(context) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: AppTexts.select_category.tr,
      message: AppTexts.please_select_category.tr,
      confirmButtonText: AppTexts.ok.tr,
      cancelButtonText: AppTexts.cancel.tr,
      onTapConfirm: () {
        Get.back();
      },
      onTapCancel: () {
        Get.back();
      },
      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true, // optional parameter (default is true)
    );
  }
}

set setUserRoleLocal(UserType userType) {
  final box = GetStorage();
  box.write('userRole', userTypeToString(userType));
}

Future<UserType?> get getUserTypeFromLocal async {
  String? value = GetStorage().read('userRole');
  if (value != null) {
    return userTypeFromString(value);
  } else {
    return null;
  }
}
