import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppConstants {
  static const kPimaryColor = Color(0xffF7BB0E);

  static const kActionColor = Color(0xffF00000);

  static const kBackgroundColor = Color(0xff29282C);
  static const kMovieNameStyle = TextStyle(
    fontSize: 20.0,
    fontWeight: FontWeight.bold,
    color: Colors.white,
  );
  static final kMainTextStyle = GoogleFonts.barlow(
      textStyle: const TextStyle(
          color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.bold));
  static final kSmallMainTextStyle = kMainTextStyle.copyWith(fontSize: 16.0);

  static const kPromaryColorTextStyle = TextStyle(
      color: kPimaryColor, fontSize: 18.0, fontWeight: FontWeight.bold);

  static final BoxDecoration kRoundedFadedBorder = BoxDecoration(
      border: Border.all(color: Colors.white54, width: .5),
      borderRadius: BorderRadius.circular(15.0));

  static final ThemeData theme =
      ThemeData.dark().copyWith(textTheme: GoogleFonts.barlowTextTheme());

  static const kSecondaryColor = Color(0xFFFE6D8E);
  static const kTextColor = Color(0xFF12153D);
  static const kTextLightColor = Color(0xFF9A9BB2);
  static const kFillStarColor = Color(0xFFFCC419);

  static const kDefaultPadding = 20.0;

  static const kDefaultShadow = BoxShadow(
    offset: Offset(0, 4),
    blurRadius: 4,
    color: Colors.black26,
  );
}
