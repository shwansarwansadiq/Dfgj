import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/services/notification_services.dart';

import 'api/notification_api.dart';
import 'controllers/auth_controller.dart';
import 'main.dart';
import 'screens/onboarding/splash_screen.dart';
import 'utils/app_function.dart';

class NotificationHandler extends StatefulWidget {
  const NotificationHandler({Key? key}) : super(key: key);
  @override
  State<NotificationHandler> createState() => NotificationHandlerState();
}

class NotificationHandlerState extends State<NotificationHandler> {
  static final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  AuthState authState = Get.find<AuthState>();
  bool isChatOpened = false;
  @override
  void initState() {
    initialiseNotification();
    super.initState();
  }

  Future initialiseNotification() async {
    // final SharedPreferences prefs = await SharedPreferences.getInstance();
    // prefs.remove('bookmarks');
    NotificationSettings settings = await _fcm.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );
    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
    } else if (settings.authorizationStatus ==
        AuthorizationStatus.provisional) {
    } else {}
    AppFunction.notificationBasedOnLang();

    // If you want to test the push notification locally,
    // you need to get the token and input to the Firebase console
    // https://console.firebase.google.com/project/YOUR_PROJECT_ID/notification/compose
    String? token = await _fcm.getToken();
    if (token != null) {
      saveNoticationTokenApi(token: token);
    }
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      checkNotification(message, false);
      NotificationModel model = NotificationModel(
        description: message.notification!.body!,
        title: message.notification!.title!,
        image: message.data['image'],
      );
      saveNotification(model);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      checkNotification(message, true);
    });
  }

  checkNotification(message, bool isBackground) async {
    dynamic notification = message.notification;

    String title = notification.title;
    String content = notification.body;

    dynamic data = message?.data;
    String? image = data["image"];
    String type = data['type'];

    if (type == 'appointment') {
      // appointmentAlert(title: title, message: content, status: status);
    }

    if (type == 'all') {
      generalAlert(title: title, message: content, image: image!);
    }
  }

  // appointmentAlert(
  //     {required String title,
  //     required String message,
  //     required String status}) {
  //   return showDialog<void>(
  //     context: navigatorConextKey.currentContext!,
  //     barrierColor: Colors.black.withOpacity(0.5),
  //     barrierDismissible: true, // user must tap button!
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: Text(title),
  //         content: Wrap(
  //           direction: Axis.vertical,
  //           children: [
  //             16.height,
  //             Text(message),
  //           ],
  //         ),
  //       );
  //     },
  //   );
  // }

  alertText(text) {}

  generalAlert(
      {required String title, required String message, required String image}) {
    showDialog<void>(
      context: navigatorConextKey.currentContext!,
      barrierColor: Colors.black.withOpacity(0.5),
      barrierDismissible: true,
      builder: (BuildContext context) {
        return AlertDialog(
            content: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                height: 200,
                width: Get.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  image: DecorationImage(
                    image: NetworkImage(image),
                    fit: BoxFit.cover,
                  ),
                )),
            16.height,
            Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            16.height,
            Text(message),
          ],
        ));
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Splash();
  }
}
