import 'package:get/get.dart';

import '../models/about_model.dart';

class AboutUsState extends GetxController {
  AboutUsModel? _aboutUs;
  List<StaffModel> _staff = [];

  List<StaffModel> get getStaff => _staff;

  set setStaff(List<StaffModel> value) {
    _staff = value;
    update();
  }

  AboutUsModel? get getAboutUs => _aboutUs;

  set setAboutUs(AboutUsModel value) {
    _aboutUs = value;
    update();
  }
}
