import 'package:get/get.dart';

import '../models/show_model.dart';

class CastsState extends GetxController {
  List<CastModel> _casts = [];

  List<CastModel> get getCasts => _casts;

  set setCasts(List<CastModel> casts) {
    _casts = casts;
    update();
  }
}
