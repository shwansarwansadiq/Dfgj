import 'package:get/get.dart';
import 'package:psoola/models/place_model.dart';
import 'package:psoola/models/seat_design_model.dart';

import '../models/event_model.dart';

class EventSelectionController extends GetxController {
  final List<EventTimeModel> _eventTimes = [];
  final List<PlaceModel> _eventPlaces = [];
  final List<HallModel> _eventHalls = [];

  List<HallModel> get getEventHalls => _eventHalls;

  set setEventHalls(List<HallModel> halls) {
    _eventHalls.clear();
    _eventHalls.addAll(halls);
    update();
  }

  List<EventTimeModel> get getEventTimes => _eventTimes;
  set setEventTimes(List<EventTimeModel> eventTime) {
    _eventTimes.clear();
    _eventTimes.addAll(eventTime);
    update();
  }

  List<PlaceModel> get getEventPlaces => _eventPlaces;

  set setEventPlaces(List<PlaceModel> places) {
    _eventPlaces.clear();
    _eventPlaces.addAll(places);
    update();
  }

  void setPlacesByEventModel({required EventModel event}) {
    _eventPlaces.clear();
    _eventPlaces.addAll(event.places);
    update();
  }

  resetStateForNewOpenedEvent() {
    _eventPlaces.clear();
    _eventTimes.clear();
    _eventHalls.clear();
    update();
  }
}
