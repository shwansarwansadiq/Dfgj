import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../models/location/province_model.dart';

class ProvinceState extends GetxController {
  List<ProvinceModel> _provinces = [];

  List<ProvinceModel> get getProvinces => _provinces;

  ProvinceModel? selectedProvince;

  ProvinceModel? get getSelectedProvince => selectedProvince;

  void setSelectedProvince(ProvinceModel province) {
    selectedProvince = province;
    update();
  }

  ProvinceModel saveSelectedProvince() {
    GetStorage box = GetStorage();
    box.write('selectedProvince', selectedProvince);
    return selectedProvince!;
  }

  ProvinceModel fetchSelectedProvince() {
    GetStorage box = GetStorage();
    selectedProvince = box.read('selectedProvince');
    return selectedProvince!;
  }

  bool _isSearching = false;

  bool get isSearching => _isSearching;
  set setIsSearching(bool value) {
    _isSearching = value;
    update();
  }

  set setProvinces(List<ProvinceModel> value) {
    _provinces = value;
    update();
  }
}
