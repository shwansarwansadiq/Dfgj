import 'package:get/get.dart';

import '../../models/location/neighborhood_model.dart';

class NeighborhoodState extends GetxController {
  List<NeighborhoodModel> _neighborhoods = [];

  String _selectedCityId = '';
  String _selectedDistrictId = '';

  String get selectedCityId => _selectedCityId;
  String get selectedDistrictId => _selectedDistrictId;

  set setSelectedCityId(String value) {
    _selectedCityId = value;
    update();
  }

  set setSelectedDistrictId(String value) {
    _selectedDistrictId = value;
    update();
  }

  bool _isSearching = false;

  bool get isSearching => _isSearching;
  set setIsSearching(bool value) {
    _isSearching = value;
    update();
  }

  List<NeighborhoodModel> get getNeighborhoods => _neighborhoods;

  set setNeighborhood(List<NeighborhoodModel> value) {
    _neighborhoods = value;
    update();
  }
}
