import 'package:get/get.dart';

import '../../models/location/district_model.dart';

class DistrictState extends GetxController {
  List<DistrictModel> _districts = [];
  String _selectedCityId = '';

  String get selectedCityId => _selectedCityId;

  set setSelectedCityId(String value) {
    _selectedCityId = value;
    update();
  }

  bool _isSearching = false;

  bool get isSearching => _isSearching;
  set setIsSearching(bool value) {
    _isSearching = value;
    update();
  }

  List<DistrictModel> get getDistricts => _districts;

  set setDistricts(List<DistrictModel> value) {
    _districts = value;
    update();
  }
}
