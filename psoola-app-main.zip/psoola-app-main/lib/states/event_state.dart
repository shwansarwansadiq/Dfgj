import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

import '../models/event_model.dart';

class EventsState extends GetxController {
  List<EventModel> _events = [];

  DocumentSnapshot? _lastDocument;

  List<EventModel> get getEvents => _events;

  set setEvents(List<EventModel> events) {
    _events = events;
    update();
  }

  DocumentSnapshot? get getLastDocument => _lastDocument;
  set setLastDocument(DocumentSnapshot? value) {
    _lastDocument = value;
    
  }

  set addEvents(List<EventModel> eventList) {
    _events.addAll(eventList);
    update();
  }
}
