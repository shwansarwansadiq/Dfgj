import 'package:get/get.dart';

import '../models/event_model.dart';

class TheatersState extends GetxController {
  List<EventModel> _theaters = [];

  List<EventModel> get getTheaters => _theaters;

  set setTheaters(List<EventModel> theaters) {
    _theaters = theaters;
    update();
  }
}
