import 'package:get/get.dart';

import '../models/event_model.dart';

class EventEventsState extends GetxController {
  List<EventModel> _events = [];

  List<EventModel> get getEvents => _events;

  set setEvents(List<EventModel> events) {
    _events = events;
    update();
  }
}
