import 'package:get/get.dart';
import 'package:psoola/models/show_model.dart';

class ShowsState extends GetxController{

  List<ShowModel> _shows = [];

List<ShowModel> get getShows => _shows;

set setShows(List<ShowModel> shows) => _shows = shows;


}