import 'package:get/get.dart';

import '../models/event_model.dart';

class ConcertsState extends GetxController {
  List<EventModel> _concerts = [];

  List<EventModel> get getConcerts => _concerts;

  set setConcerts(List<EventModel> concerts) {
    _concerts = concerts;
    update();
  }
}
