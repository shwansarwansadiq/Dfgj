import 'package:get/get.dart';
import 'package:psoola/models/event_category_model.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/seat_design_model.dart';
import '../components/seat/model/seat_model.dart';
import 'package:psoola/models/place_model.dart';

import '../models/about_model.dart';

class TicketState extends GetxController {
  List<SeatNumber> _reservedSeatNumbers = [];

  get getReservedSeatNumbers => _reservedSeatNumbers;
  set setReservedSeatNumbers(List<SeatNumber> value) {
    _reservedSeatNumbers = value;
    update();
  }

  EventTimeModel? _selectedEventTime;

  EventTimeModel? get getSelectedEventTime => _selectedEventTime;

  set setSelectedEventTime(EventTimeModel? value) {
    _selectedEventTime = value;
  }

  PlaceModel? get getSelectedPlace => _selectedPlace;

  AboutUsModel? _aboutUs;
  List<StaffModel> _staff = [];

  EventCategoryModel? _selectedEventCategory;

  EventCategoryModel? get getSelectedEventCategory => _selectedEventCategory;

  set setSelectedEventCategory(EventCategoryModel? value) {
    _selectedEventCategory = value;
  }

  List<StaffModel> get getStaff => _staff;

  DateTime? _selectedDate;
  DateTime? get selectedDate => _selectedDate;

  PlaceModel? _selectedPlace;
  PlaceModel? get selectedPlace => _selectedPlace;

  set setSelectedPlace(PlaceModel? value) {
    _selectedPlace = value;
  }

  HallModel? _selectedHall;

  String? _sectionRowCol;

  String? get getSectionRowCol => _sectionRowCol;

  SeatPriceModel? _seatPrices;

  SeatPriceModel? get getSeatPrices => _seatPrices;

  set setSeatPrice(SeatPriceModel? value) {
    _seatPrices = value;
  }

  set setSectionRowCol(String name) {
    _sectionRowCol = name;
    update();
  }

  String? _sectionDesignId;

  get getSectionDeisgnId => _sectionDesignId;

  set setSectionDeisgnId(String? value) {
    _sectionDesignId = value;
  }

  set setSelectedHall(HallModel? value) {
    _selectedHall = value;
    update();
  }

  HallModel? get getSelectedHall => _selectedHall;

  set selectedDate(DateTime? value) {
    _selectedDate = value;
    update();
  }

  set setStaff(List<StaffModel> value) {
    _staff = value;
    update();
  }

  AboutUsModel? get getAboutUs => _aboutUs;

  set setAboutUs(AboutUsModel value) {
    _aboutUs = value;
    update();
  }

  EventModel? _selectedEvent;

  EventModel? get getSelectedEvent => _selectedEvent;

  set setSelectedEvent(EventModel? value) {
    _selectedEvent = value;
    update();
  }

  resetStateForNewOpenedEvent() {
    _selectedDate = null;
    _selectedHall = null;
    _sectionRowCol = null;
    _sectionDesignId = null;
    _seatPrices = null;
    _selectedEvent = null;
    _selectedEventCategory = null;
    _selectedEventTime = null;
    _selectedPlace = null;
    update();
  }
}
