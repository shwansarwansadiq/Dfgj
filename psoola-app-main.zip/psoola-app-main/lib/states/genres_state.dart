import 'package:get/get.dart';

import '../models/genre_model.dart';

class GenresState extends GetxController {
  List<GenreModel> _genres = [];

  List<GenreModel> get getGenres => _genres;

  set setGenres(List<GenreModel> genres) => _genres = genres;
}
