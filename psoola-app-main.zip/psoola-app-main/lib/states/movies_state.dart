import 'package:get/get.dart';

import '../models/event_model.dart';

class MoviesState extends GetxController {
  List<EventModel> _movies = [];

  List<EventModel> get getMovies => _movies;

  set setMovies(List<EventModel> movies) {
    _movies = movies;
    update();
  }
}
