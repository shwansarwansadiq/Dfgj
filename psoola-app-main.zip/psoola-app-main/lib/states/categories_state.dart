import 'package:get/get.dart';

import '../models/event_category_model.dart';

class CategoriesState extends GetxController {
  List<EventCategoryModel> _categories = [];

  List<EventCategoryModel> get getCategories => _categories;

  set setCategories(List<EventCategoryModel> categories) {
    _categories = categories;
    update();
  }
}
