import 'package:get/get.dart';
import 'package:psoola/models/ticket_model.dart';

class TicketsState extends GetxController {
  List<TicketModel> _availableTickets = [];
  final Rx<DateTime?> isNewTicket = null.obs;
  int? selectedTab = 0;

  get getSelectedTab => selectedTab;
  set setSelectedTab(int? tab) {
    selectedTab = tab;
  }

  TicketModel? _ticket;

  TicketModel? get getSingleTicket => _ticket;

  set setSingleTicket(TicketModel? ticket) {
    _ticket = ticket;
    update();
  }

  List<TicketModel> get getCustomerTickets => _availableTickets;

  set setCustomerTickets(List<TicketModel> customerTickets) {
    _availableTickets = customerTickets;
    update();
  }

  List<TicketModel> _expiredTickets = [];

  List<TicketModel> get getExpiredTickets => _expiredTickets;

  set setExpiredTickets(List<TicketModel> expiredTickets) {
    _expiredTickets = expiredTickets;
    update();
  }
}
