import 'package:get/get.dart';

import '../models/event_model.dart';

class SwiperEventsState extends GetxController {
  List<EventModel> _swiperEvents = [];

  List<EventModel> get getSwiperEvents => _swiperEvents;

  set setSwiperEvents(List<EventModel> swiperEvents) {
    _swiperEvents = swiperEvents;
    update();
  }
}
