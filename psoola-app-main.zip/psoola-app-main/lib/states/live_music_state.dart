import 'package:get/get.dart';

import '../models/event_model.dart';

class LiveMusicState extends GetxController {
  List<EventModel> _liveMusics = [];

  List<EventModel> get getLiveMusics => _liveMusics;

  set setLiveMusics(List<EventModel> liveMusics) {
    _liveMusics = liveMusics;
    update();
  }
}
