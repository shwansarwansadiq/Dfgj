import 'package:get/get.dart';
import 'package:psoola/models/place_model.dart';

class PlacesState extends GetxController {
  List<PlaceModel> _places = [];

  List<PlaceModel> get getPlaces => _places;

  set setPlaces(List<PlaceModel> places) => _places = places;
}
