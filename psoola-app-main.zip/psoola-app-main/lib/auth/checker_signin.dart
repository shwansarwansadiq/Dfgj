// ignore_for_file: avoid_print

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:psoola/api/ticket_provider_api.dart';
import 'package:psoola/utils/app_texts.dart';

import '../controllers/auth_controller.dart';
import '../models/user_model.dart';

class CheckerSignin extends StatefulWidget {
  const CheckerSignin({super.key});

  @override
  State<CheckerSignin> createState() => _CheckerSigninState();
}

final _formKey = GlobalKey<FormState>();
AuthState authState = Get.find<AuthState>();

late String _checkerEmail;
late String _checkerPassword;

class _CheckerSigninState extends State<CheckerSignin> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Scaffold(
            appBar: AppBar(title: const Text('Ticket checker Signin')),
            body: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      //image
                      SizedBox(
                          child: SvgPicture.asset(
                        "assets/icons/coupon-cutting.svg",
                        height: Get.height * 0.15,
                      )),
                      const SizedBox(
                        height: 20,
                      ),
                      const Text(
                        'Ticket checker Signin',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: TextFormField(
                          validator: (val) => val!.isEmpty || !val.contains("@")
                              ? "please_enter_a_valid_email".tr
                              : null,
                          onSaved: (String? value) {
                            _checkerEmail = value ?? '';
                          },
                          decoration: InputDecoration(
                            hintText: AppTexts.email.tr,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),

                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: TextFormField(
                          obscureText: true,
                          onSaved: (String? value) {
                            _checkerPassword = value ?? '';
                          },
                          validator: (String? value) {
                            if (value == null || value.isEmpty) {
                              return 'please_enter_your_password'.tr;
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            hintText: 'password'.tr,
                          ),
                        ),
                      ), // Forgot Password Button
                      const SizedBox(height: 30),

                      /// Login Button
                      SizedBox(
                        height: 60,
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            foregroundColor: Colors.blue,
                            backgroundColor: Theme.of(context).primaryColor,
                          ),
                          onPressed: () {
                            _formKey.currentState!.save();
                            if (_formKey.currentState!.validate()) {
                              print('$_checkerEmail, $_checkerPassword');
                              ticketProviderLoginApi(
                                  email: _checkerEmail,
                                  password: _checkerPassword,
                                  userType: UserType.CHECKER);
                            }
                          },
                          child: Text('login'.tr,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
            // This trailing comma makes auto-formatting nicer for build methods.
            ));
  }
}
