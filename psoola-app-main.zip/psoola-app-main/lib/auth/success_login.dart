import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import '../check_user.dart';
import '../controllers/auth_controller.dart';
import '../models/user_model.dart';
import '../utils/app_animations.dart';
import '../utils/app_texts.dart';

class SuccessLogin extends StatelessWidget {
  final UserType userType;
  SuccessLogin({Key? key, required this.userType}) : super(key: key);

  final AuthState authState = Get.find<AuthState>();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      top: false,
      child: Scaffold(
          body: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        width: size.width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Expanded(child: SizedBox()),
            Lottie.asset(AppAnimations.popcorn,
                width: size.width * .8, animate: true),
            const SizedBox(
              height: 20,
            ),
            Text(
              'login_successfully'.tr,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: SizedBox(
                height: 60,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).primaryColor),
                  onPressed: () {
                    // if (userType == UserType.PATIENT) {
                    //   if (authType == 'login') {
                    //     Get.offAll(() => const Navbar());
                    //   } else {
                    //     Get.offAll(() => const DoctorNavbar());
                    //   }
                    // }
                    Get.offAll(() => CheckUser());
                  },
                  child: Text(AppTexts.continue_text.tr,
                      style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: Colors.white)),
                ),
              ),
            ),
            const Expanded(child: SizedBox())
          ],
        ),
      )),
    );
  }
}
