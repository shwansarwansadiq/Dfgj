// ignore_for_file: avoid_print

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:psoola/api/ticket_provider_api.dart';
import 'package:psoola/utils/app_texts.dart';

import '../controllers/auth_controller.dart';
import '../models/user_model.dart';

class TicketProviderSignin extends StatefulWidget {
  const TicketProviderSignin({super.key});

  @override
  State<TicketProviderSignin> createState() => _TicketProviderSigninState();
}

final _formKey = GlobalKey<FormState>();
AuthState authState = Get.find<AuthState>();

late String _adminEmail;
late String _adminPassword;

class _TicketProviderSigninState extends State<TicketProviderSignin> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Scaffold(
            appBar: AppBar(
                title: const Text('Ticket Provider Signin'), actions: const []),
            body: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    //image

                    SizedBox(
                        child: SvgPicture.asset(
                      "assets/icons/food-counter.svg",
                      height: Get.height * 0.3,
                    )),
                    const SizedBox(
                      height: 20,
                    ),
                    const Text(
                      'Ticket Provider Signin',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Directionality(
                      textDirection: TextDirection.ltr,
                      child: TextFormField(
                        validator: (val) => val!.isEmpty || !val.contains("@")
                            ? "please_enter_a_valid_email".tr
                            : null,
                        onSaved: (String? value) {
                          _adminEmail = value ?? '';
                        },
                        decoration: InputDecoration(
                          hintText: AppTexts.email.tr,
                        ),
                      ),
                    ),
                    const SizedBox(height: 15),

                    Directionality(
                      textDirection: TextDirection.ltr,
                      child: TextFormField(
                        obscureText: true,
                        onSaved: (String? value) {
                          _adminPassword = value ?? '';
                        },
                        validator: (String? value) {
                          if (value == null || value.isEmpty) {
                            return 'please_enter_your_password'.tr;
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                          hintText: 'password'.tr,
                        ),
                      ),
                    ), // Forgot Password Button
                    const SizedBox(height: 30),

                    /// Login Button
                    SizedBox(
                      height: 60,
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Theme.of(context).primaryColor,
                        ),
                        onPressed: () {
                          _formKey.currentState!.save();
                          if (_formKey.currentState!.validate()) {
                            print('$_adminEmail, $_adminPassword');
                            ticketProviderLoginApi(
                                email: _adminEmail,
                                password: _adminPassword,
                                userType: UserType.TICKETPROVIDER);
                          }
                        },
                        child: Text('login'.tr,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            )
            // This trailing comma makes auto-formatting nicer for build methods.
            ));
  }
}
