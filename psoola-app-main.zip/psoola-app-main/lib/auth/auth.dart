import 'package:auto_size_text/auto_size_text.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/auth/social_logins.dart';
import 'package:psoola/auth/success_login.dart';
import 'package:psoola/auth/ticket_provider_signin.dart';
import 'package:psoola/models/user_model.dart';
import 'package:rounded_loading_button_plus/rounded_loading_button.dart';

import '../api/user_api.dart';
import '../controllers/auth_controller.dart';
import '../utils/app_defaults.dart';
import '../utils/app_function.dart';
import '../utils/app_image.dart';
import '../utils/app_texts.dart';
import 'checker_signin.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _googleController = RoundedLoadingButtonController();
  final _appleController = RoundedLoadingButtonController();

  final _formKey = GlobalKey<FormState>();

  final AuthState _authState = Get.find<AuthState>();

  gotoSuccessLogin() {
    Future.delayed(const Duration(seconds: 1)).then((value) => Get.to(() => SuccessLogin(
          userType: UserType.CUSTOMER,
        )));
  }

  _handleSignInWithGoogle() async {
    _googleController.start();
    await _authState.signInWithGoogle().then((UserCredential? userCredential) async {
      if (userCredential != null) {
        await UserService().checkUserExists(userCredential.user!.uid).then((bool userExist) async {
          if (!userExist) {
            _authState.setUserType = UserType.CUSTOMER;
            _authState.setUserName = userCredential.user!.displayName!;
            await UserService()
                .saveUserData(
                  userCredential.user!.uid,
                  userCredential.user!.displayName!,
                  userCredential.user!.email!,
                )
                .then((value) async => _googleController.success());
            gotoSuccessLogin();
          } else {
            _googleController.success();
            setUserRoleLocal = UserType.CUSTOMER;
            UserService().getUserApi();
            gotoSuccessLogin();
          }
        });
      }
    }).onError((error, stackTrace) {
      _googleController.reset();
      debugPrint('google login error: $error');
      Get.snackbar('Error', 'Error with google login. Please try again!');
    });
  }

  _handleSignInWithApple() async {
    _appleController.start();
    await _authState.signInWithApple().then((UserCredential? userCredential) async {
      if (userCredential != null) {
        await UserService().checkUserExists(userCredential.user!.uid).then((bool userExist) async {
          if (!userExist) {
            _authState.setUserType = UserType.CUSTOMER;
            String? displayName;
            if (userCredential.user!.displayName != null) {
              displayName = userCredential.user!.displayName;
            } else {
              var email = userCredential.user!.email!.split('@');
              displayName = email[0];
            }
            _authState.setUserName = displayName;
            await UserService()
                .saveUserData(
                  userCredential.user!.uid,
                  displayName!,
                  userCredential.user!.email ?? 'not given',
                )
                .then((value) async => _appleController.success());
            gotoSuccessLogin();
          } else {
            _googleController.success();
            setUserRoleLocal = UserType.CUSTOMER;
            UserService().getUserApi();
            gotoSuccessLogin();
          }
        });
      }
    }).onError((error, stackTrace) {
      _appleController.reset();
      debugPrint('apple login error: $error');
      Get.snackbar('Error', 'Error with apple login. Please try again!');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Padding(
        padding: EdgeInsets.symmetric(horizontal: Get.width * 0.15),
        child: Text('by_signing_in_you_agree_to_our_terms_and_conditions'.tr,
            textAlign: TextAlign.center,
            maxLines: 2,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontSize: 14,
                )),
      ),
      appBar: AppBar(
        actions: [
          IconButton(
            icon: Text(AppTexts.help.tr),
            onPressed: () {
              customBottomSheet(context);
            },
          )
        ],
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(25),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('login'.tr,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      )),
              SocialLogins(
                  onGooglePressed: _handleSignInWithGoogle,
                  onApplePressed: _handleSignInWithApple,
                  googleBtnCtlr: _googleController,
                  appleBtnCtlr: _appleController),
            ],
          ),
        ),
      ),
    );
  }

  void customBottomSheet(context) {
    showModalBottomSheet(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        context: context,
        isScrollControlled: true,
        isDismissible: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
        ),
        builder: (BuildContext context) {
          return DraggableScrollableSheet(
              initialChildSize: 0.7,
              minChildSize: 0.7,
              maxChildSize: 0.8,
              expand: false,
              builder: (context, scrollController) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ListView(
                    children: [
                      const SizedBox(
                        height: 5,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        height: 30,
                        width: Get.width,
                        decoration: const BoxDecoration(
                          image: DecorationImage(
                            image: AssetImage(AppImage.logo),
                            fit: BoxFit.contain,
                          ),
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(AppDefaults.radius),
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 50,
                      ),
                      Text(
                        AppTexts.welcome_to_psoola_customer_service.tr,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Text(
                        AppTexts.we_are_here_to_help_you_desc.tr,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      loginAsProvider(),
                      loginAsChecker(),
                      const SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                );
              });
        });
  }

  SizedBox loginAsProvider() {
    return SizedBox(
      height: 50,
      width: Get.width,
      child: TextButton(
        style: TextButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        ),
        onPressed: () {
          Get.to(() => const TicketProviderSignin());
        },
        child: Row(
          children: [
            const Icon(
              Icons.login,
              color: Colors.green,
            ),
            const SizedBox(
              width: 10,
            ),
            SizedBox(
              width: Get.width * 0.6,
              child: AutoSizeText(
                AppTexts.loginAsTicketProvider.tr,
                style: const TextStyle(
                  fontSize: 15,
                ),
              ),
            ),
            const Spacer(),
            const Icon(
              Icons.arrow_forward_ios,
            ),
          ],
        ),
      ),
    );
  }

  SizedBox loginAsChecker() {
    return SizedBox(
      height: 50,
      width: Get.width,
      child: TextButton(
        style: TextButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        ),
        onPressed: () {
          Get.to(() => const CheckerSignin());
        },
        child: Row(
          children: [
            const Icon(
              Icons.login,
              color: Colors.green,
            ),
            const SizedBox(
              width: 10,
            ),
            SizedBox(
              width: Get.width * 0.6,
              child: AutoSizeText(
                AppTexts.loginAsChecker.tr,
                style: const TextStyle(
                  fontSize: 15,
                ),
              ),
            ),
            const Spacer(),
            const Icon(
              Icons.arrow_forward_ios,
            ),
          ],
        ),
      ),
    );
  }
}
