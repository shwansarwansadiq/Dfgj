import 'package:bluelab_dialog/panara_dialogs.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/models/user_model.dart';
import 'package:psoola/utils/app_icons.dart';
import 'package:rounded_loading_button_plus/rounded_loading_button.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../api/user_api.dart';
import '../check_user.dart';
import '../controllers/auth_controller.dart';
import '../utils/app_animations.dart';
import '../utils/app_image.dart';
import '../utils/app_texts.dart';

class CompleteProfile extends StatefulWidget {
  const CompleteProfile({super.key});

  @override
  State<CompleteProfile> createState() => _CompleteProfileState();
}

class _CompleteProfileState extends State<CompleteProfile> {
  AuthState authState = Get.find<AuthState>();
  final TextEditingController mycontrollerPhone = TextEditingController();
  String initialCountry = 'IQ';
  final _formKey = GlobalKey<FormState>();
  String? phonenumberWithCode;

  final RoundedLoadingButtonController btnController = RoundedLoadingButtonController();
  final SmsAutoFill _autoFill = SmsAutoFill();
  final TextEditingController _nameController = TextEditingController();

  @override
  initState() {
    _nameController.text = authState.user.value.name!;
    if (authState.user.value.name != null) {
      _nameController.text = authState.user.value.name!;
    } else {
      _nameController.text = authState.getUserName;
    }
    // _autoFill.hint.then((value) => {
    //       if (value != null)
    //         {
    //           setState(() {
    //             String phoneWithoutContryCode = value.substring(4);
    //             mycontrollerPhone.text = phoneWithoutContryCode;
    //           })
    //         }
    //     });
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => hideKeyboard(context),
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Image.asset(
            AppImage.logo,
            height: 30,
          ),
          actions: [
            IconButton(
                onPressed: () {
                  showAlert(context);
                },
                icon: SvgPicture.asset(AppIcons.logout))
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const SizedBox(height: 80),
                  Text(AppTexts.complete_profile.tr, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                  Text(AppTexts.enterYourPhoneNumber.tr, style: secondaryTextStyle(size: 16)),
                  30.height,
                  TextFormField(
                    controller: _nameController,
                    decoration: InputDecoration(
                      labelText: AppTexts.fullName.tr,
                      hintText: AppTexts.fullName.tr,
                      border: const OutlineInputBorder(
                        borderSide: BorderSide(),
                      ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {}
                      return null;
                    },
                    onSaved: (value) {
                      authState.setFullName = value!;
                    },
                  ),
                  16.height,
                  SizedBox(
                    child: Directionality(
                        textDirection: TextDirection.ltr,
                        child: IntlPhoneField(
                          invalidNumberMessage: AppTexts.invalidNumber.tr,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(10),
                            FilteringTextInputFormatter.allow(RegExp(r'[1-9]\d*')),
                          ],
                          validator: (p0) => p0!.completeNumber.length < 10 ? AppTexts.invalidNumber.tr : null,
                          decoration: InputDecoration(
                            labelText: AppTexts.phoneNumber.tr,
                            hintText: AppTexts.just_english_numbers.tr,
                            border: const OutlineInputBorder(
                              borderSide: BorderSide(),
                            ),
                          ),
                          initialCountryCode: 'IQ',
                          onChanged: (phone) {
                            phonenumberWithCode = phone.completeNumber;
                          },
                        )),
                  ),
                  16.height,
                  RoundedLoadingButton(
                    height: 60,
                    borderRadius: 15,
                    color: Get.theme.primaryColor,
                    controller: btnController,
                    onPressed: () async {
                      _formKey.currentState!.save();
                      if (_formKey.currentState!.validate()) {
                        authState.setPhoneNumber = phonenumberWithCode!;

                        authState.setUserType = UserType.CUSTOMER;
                        if (!mounted) return;
                        UserService().updateUserData(
                          _nameController.text,
                          phonenumberWithCode!,
                        );
                      }
                    },
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(AppTexts.complete_profile.tr, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: Colors.white)),
                    ]),
                  ),
                  16.height,
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  showAlert(BuildContext context) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: AppTexts.logout.tr,
      message: AppTexts.areYouSureYouWantToLogout.tr,
      confirmButtonText: AppTexts.logout.tr,
      textColor: Theme.of(context).textTheme.bodyLarge!.color,
      cancelButtonText: AppTexts.cancel.tr,
      onTapCancel: () {
        Get.back();
      },
      onTapConfirm: () {
        authState.logout().then((value) {
          Get.offAll(() => CheckUser());
        });
      },
      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true,
    );
  }
}
