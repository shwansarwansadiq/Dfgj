import 'package:blue_thermal_printer/blue_thermal_printer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:lottie/lottie.dart';
import 'package:psoola/check_user.dart';
import 'package:psoola/models/ticket_model.dart';

import '../controllers/auth_controller.dart';
import '../utils/app_animations.dart';
import '../utils/app_texts.dart';
import 'states/tickets_state.dart';
import 'utils/app_printer.dart';

class SuccessPurchase extends StatefulWidget {
  const SuccessPurchase({
    TicketModel? ticket,
    Key? key,
  }) : super(key: key);

  @override
  State<SuccessPurchase> createState() => _SuccessPurchaseState();
}

class _SuccessPurchaseState extends State<SuccessPurchase> {
  final AuthState authState = Get.find<AuthState>();

  TicketsState ticketsState = Get.find<TicketsState>();

  @override
  void initState() {
    super.initState();
    ticketsState.setSelectedTab = 1;

    if (authState.user.value.userType == "CHECKER") {
      initPlatformState();
      testPrint.sample();
    }
  }

  BlueThermalPrinter bluetooth = BlueThermalPrinter.instance;

  TestPrint testPrint = TestPrint();

  Future<void> initPlatformState() async {
    bool? isConnected = await bluetooth.isConnected;
    List<BluetoothDevice> devices = [];
    try {
      devices = await bluetooth.getBondedDevices();
    } on PlatformException {}

    bool isInnerPrinterConnected = false;

    for (var device in devices) {
      if (device.name == "InnerPrinter" && isConnected == true) {
        isInnerPrinterConnected = true;
      }
    }

    if (!isInnerPrinterConnected) {
      BluetoothDevice? selectedDevice;
      for (var device in devices) {
        if (device.name == "InnerPrinter") {
          selectedDevice = device;
          break;
        }
      }

      if (selectedDevice != null) {
        try {
          await bluetooth.connect(selectedDevice);
          print("Connected to InnerPrinter");
        } catch (error) {
          print("Failed to connect to InnerPrinter: $error");
        }
      } else {
        print("InnerPrinter not found in the list of devices");
      }
    } else {
      print("Already connected to InnerPrinter");
    }

    bluetooth.onStateChanged().listen((state) {
      switch (state) {
        case BlueThermalPrinter.CONNECTED:
          setState(() {
            print("bluetooth device state: connected");
          });
          break;
        case BlueThermalPrinter.DISCONNECTED:
          setState(() {
            print("bluetooth device state: disconnected");
          });
          break;
        case BlueThermalPrinter.DISCONNECT_REQUESTED:
          setState(() {
            print("bluetooth device state: disconnect requested");
          });
          break;
        case BlueThermalPrinter.STATE_TURNING_OFF:
          setState(() {
            print("bluetooth device state: bluetooth turning off");
          });
          break;
        case BlueThermalPrinter.STATE_OFF:
          setState(() {
            print("bluetooth device state: bluetooth off");
          });
          break;
        case BlueThermalPrinter.STATE_ON:
          setState(() {
            print("bluetooth device state: bluetooth on");
          });
          break;
        case BlueThermalPrinter.STATE_TURNING_ON:
          setState(() {
            print("bluetooth device state: bluetooth turning on");
          });
          break;
        case BlueThermalPrinter.ERROR:
          setState(() {
            print("bluetooth device state: error");
          });
          break;
        default:
          print(state);
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SafeArea(
      top: false,
      child: Scaffold(
          body: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        width: size.width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Expanded(child: SizedBox()),
            Lottie.asset(AppAnimations.popcorn,
                width: size.width * .8, animate: true),
            const SizedBox(
              height: 20,
            ),
            Text(
              AppTexts.successfully_purchased.tr,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: SizedBox(
                height: 60,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).primaryColor),
                  onPressed: () {
                    ticketsState.setSelectedTab = 1;

                    if (authState.user.value.userType == "CHECKER") {
                      initPlatformState();

                      testPrint.sample();
                    }

                    Get.offAll(() => CheckUser());
                  },
                  child: Text(
                      authState.user.value.userType == "CHECKER"
                          ? "Print Ticket"
                          : AppTexts.continue_text.tr,
                      style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color: Colors.white)),
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            authState.user.value.userType == "CHECKER"
                ? SizedBox(
                    width: double.infinity,
                    child: SizedBox(
                      height: 60,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Theme.of(context).primaryColor),
                        onPressed: () {
                          ticketsState.setSelectedTab = 1;

                          Get.offAll(() => CheckUser());
                        },
                        child: const Text("Continue",
                            style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: Colors.white)),
                      ),
                    ),
                  )
                : const SizedBox(),
            const Expanded(child: SizedBox())
          ],
        ),
      )),
    );
  }
}
