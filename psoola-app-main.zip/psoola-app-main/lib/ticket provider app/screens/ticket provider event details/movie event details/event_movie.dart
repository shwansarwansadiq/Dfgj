import "dart:math" as math;

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/api/cast_api.dart';
import 'package:psoola/components/review/review_widget.dart';
import 'package:psoola/models/show_model.dart';
import 'package:psoola/screens/event_details/components/movie_theater_header.dart';
import 'package:psoola/states/cast_state.dart';
import 'package:psoola/states/event_state.dart';
import 'package:psoola/states/ticket_state.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../../../components/buttons/back_button.dart';
import '../../../../controllers/auth_controller.dart';
import '../../../../models/event_model.dart';
import '../../../../models/user_model.dart';
import '../../../../screens/event_details/components/datetime_section.dart';

class EventMovieTicketProviderDetails extends StatefulWidget {
  final EventModel eventModel;
  const EventMovieTicketProviderDetails({super.key, required this.eventModel});

  @override
  State<EventMovieTicketProviderDetails> createState() =>
      _EventMovieTicketProviderDetailsState();
}

class _EventMovieTicketProviderDetailsState
    extends State<EventMovieTicketProviderDetails>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  EventsState eventsState = Get.find<EventsState>();
  TicketState ticketState = Get.find<TicketState>();

  AuthState authState = Get.find<AuthState>();

  @override
  void initState() {
    fetchCastApi(showId: widget.eventModel.show.id);

    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    init();
  }

  Future<void> init() async {}

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        top: false,
        bottom: false,
        child: NestedScrollView(
          scrollBehavior: const ScrollBehavior(),
          scrollDirection: Axis.vertical,
          headerSliverBuilder: (BuildContext ctx, bool value) {
            return [
              SliverAppBar(

                  // automaticallyImplyLeading: false,
                  leading: Container(
                    padding: const EdgeInsets.all(4),
                    child: CustomBackButton(
                      onPressed: () {
                        Get.back();
                      },
                    ),
                  ),
                  scrolledUnderElevation: 4,
                  pinned: true,
                  snap: false,
                  floating: false,
                  expandedHeight: Get.height * 0.4,
                  flexibleSpace: FlexibleSpaceBar(
                    background: MovieTheaterHeader(event: widget.eventModel),
                  )),
              SliverPersistentHeader(
                pinned: true,
                delegate: _SliverAppBarDelegate(
                  maxHeight: 50,
                  minHeight: 30,
                  child: TabBar(
                    controller: _tabController,
                    unselectedLabelColor: Colors.grey,
                    labelColor: Get.theme.primaryColor,
                    indicatorColor: Get.theme.primaryColor,
                    tabs: [
                      Tab(
                        text: AppTexts.buy_ticket.tr,
                      ),
                      Tab(
                        text: AppTexts.reviews.tr,
                      ),
                      Tab(
                        text: AppTexts.cast.tr,
                      ),
                    ],
                  ),
                ),
              ),
            ];
          },
          body: TabBarView(
            controller: _tabController,
            children: [
              _buyTicketTab(),
              _reviewTab(),
              _castTab(),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  Center _reviewTab() {
    return Center(
      child: EventReview(
        eventId: widget.eventModel.id,
        totalReviewModel: widget.eventModel.totalReview,
        userType: UserType.CUSTOMER,
      ),
    );
  }

  Widget _castTab() {
    return GetBuilder<CastsState>(
      builder: (state) {
        List<CastModel> cast = state.getCasts;
        return cast.isNotEmpty
            ? Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    Text(AppTexts.cast.tr,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        )),
                    const SizedBox(height: 20),
                    ListView.separated(
                      separatorBuilder: (context, index) => const SizedBox(
                        height: 20,
                      ),
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: cast.length,
                      itemBuilder: (context, index) {
                        return Row(
                          children: [
                            Container(
                              height: 50,
                              width: 50,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(25),
                                image: DecorationImage(
                                  image: CachedNetworkImageProvider(
                                      cast[index].image),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  cast[index].name,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  cast[index].role,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        );
                      },
                    )
                  ],
                ),
              )
            : Center(
                child: Text(AppTexts.noCastInformationHasBeenFound.tr),
              );
      },
    );
  }

  Widget _buyTicketTab() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                10.height,
                Text(AppTexts.buy_ticket.tr,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    )),
                const SizedBox(height: 10),
                Text(AppTexts.please_below_select_date_and_time.tr,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.normal,
                      color: Colors.grey,
                    )),
                const SizedBox(height: 10),
              ],
            ),
          ),
          DatetimeSection(
            event: widget.eventModel,
          ),
        ],
      ),
    );
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  _SliverAppBarDelegate({
    required this.minHeight,
    required this.maxHeight,
    required this.child,
  });
  final double minHeight;
  final double maxHeight;
  final Widget child;

  @override
  double get minExtent => minHeight;

  @override
  double get maxExtent => math.max(maxHeight, minHeight);

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return SizedBox.expand(child: child);
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
    return maxHeight != oldDelegate.maxHeight ||
        minHeight != oldDelegate.minHeight ||
        child != oldDelegate.child;
  }
}
