import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/states/ticket_state.dart';
import 'package:psoola/utils/app_animations.dart';
import 'package:psoola/utils/app_function.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../../controllers/auth_controller.dart';
import '../../../models/user_model.dart';

class BuyTicketButton extends StatelessWidget {
  final Function() onPressed;

  BuyTicketButton({Key? key, required this.onPressed}) : super(key: key);
  final TicketState ticketState = Get.find<TicketState>();
  AuthState authState = Get.find<AuthState>();

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (authState.user.value.state != UserState.LOGEDIN) {
          AppFunction.showRegisterDialog(context, AppAnimations.loginDialog);
          return;
        }
        if (ticketState.selectedDate == null) {
          Get.snackbar(AppTexts.please_select_time.tr,
              AppTexts.please_select_event_datetime.tr);
          return;
        }

        onPressed();
      },
      child: Container(
        width: Get.width,
        height: 60,
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20), topRight: Radius.circular(20)),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).primaryColor,
              Theme.of(context).primaryColor
            ],
          ),
        ),
        child: Center(
            child: Text(
          AppTexts.buy_ticket.tr,
          style: const TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        )),
      ),
    );
  }
}
