import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/utils/app_function.dart';

import '../../../components/seat/model/seat_model.dart';
import '../../../components/wallet/wallet_sheet.dart';
import '../../../screens/buy_ticket.dart/components/seat_section/seat_section.dart';
import '../../../states/ticket_state.dart';

class SeatSelectionMovieTicket extends StatelessWidget {
  final EventModel event;
  TicketState ticketState = Get.find<TicketState>();
  AuthState authsState = Get.find<AuthState>();

  SeatSelectionMovieTicket({Key? key, required this.event}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    String uid = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      body: SafeArea(
          child: Stack(children: [
        Positioned(
          bottom: 0,
          child: GestureDetector(
            onTap: () {
              AppFunction.showPleaseSelectSeatFirstDialog(context);
              return;

              showModalBottomSheet(
                backgroundColor: Theme.of(context).scaffoldBackgroundColor,
                isScrollControlled: true,
                anchorPoint: const Offset(0, 0.5),
                context: context,
                builder: (BuildContext context) {
                  return Wrap(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: WalletSheet(),
                      )
                    ],
                  );
                },
              );
            },
          ),
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            const Expanded(flex: 1, child: SizedBox()),
            SeatSection(
              placeId: uid,
              event: event,
              onSeatSelected: ({required Set<SeatNumber> seats}) {},
            ),
            const Divider(
              thickness: 1,
            ),
          ],
        ),
      ])),
    );
  }
}
