import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/screens/event_details/movie%20event%20details/event_movie.dart';
import 'package:psoola/states/ticket_state.dart';
import 'package:psoola/ticket%20provider%20app/screens/ticket%20provider%20event%20details/event_concert.dart';

import '../../../models/event_model.dart';
import 'event_live_music.dart';
import 'event_theatre.dart';
import 'movie event details/event_movie.dart';

class TicketProviderEventDetails extends StatefulWidget {
  final EventModel eventModel;
  const TicketProviderEventDetails({super.key, required this.eventModel});

  @override
  State<TicketProviderEventDetails> createState() =>
      _TicketProviderEventDetailsState();
}

class _TicketProviderEventDetailsState extends State<TicketProviderEventDetails>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  TicketState ticketState = Get.find<TicketState>();

  @override
  void initState() {
    ticketState.resetStateForNewOpenedEvent();
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    init();
  }

  Future<void> init() async {}

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    switch (widget.eventModel.show.type) {
      case EventType.MOVIE:
        return EventMovieTicketProviderDetails(eventModel: widget.eventModel);
      case EventType.THEATER:
        return EventTheatreTicketProviderDetails(eventModel: widget.eventModel);
      case EventType.CONCERT:
        return EventConcertTicketProviderDetails(eventModel: widget.eventModel);
      case EventType.LIVEMUSIC:
        return EventLiveMusicTicketProviderDetails(
            eventModel: widget.eventModel);
      default:
        return EventMovieDetails(eventModel: widget.eventModel);
    }
  }
}
