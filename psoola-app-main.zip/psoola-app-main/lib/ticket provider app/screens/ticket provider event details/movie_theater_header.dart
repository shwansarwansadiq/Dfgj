import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/utils/app_function.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../../../utils/app_defaults.dart';
import '../../../utils/app_texts.dart';

class EventMovieTicketProviderDetailsHeader extends StatelessWidget {
  final EventModel event;
  EventMovieTicketProviderDetailsHeader({Key? key, required this.event})
      : super(key: key);

  String currentLang = Get.locale!.languageCode;
  @override
  Widget build(BuildContext context) {
    return Stack(alignment: AlignmentDirectional.bottomCenter, children: [
      Container(
        height: Get.height * 0.4,
        width: Get.width,
        decoration: BoxDecoration(
          color: Colors.black,
          image: DecorationImage(
              image: NetworkImage(event.show.cover), fit: BoxFit.cover),
        ),
      ),
      Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.black.withOpacity(0.1),
              Colors.black.withOpacity(0.95),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.all(15.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Hero(
              tag: event.id,
              child: Container(
                height: 210,
                width: 150,
                decoration: BoxDecoration(
                    color: Colors.black,
                    image: DecorationImage(
                        image: NetworkImage(event.show.poster),
                        fit: BoxFit.cover),
                    borderRadius: BorderRadius.circular(AppDefaults.radius)),
              ),
            ),
            const SizedBox(
              width: 20,
            ),
            SizedBox(
              height: 210,
              child: Column(
                mainAxisSize: MainAxisSize.max, // To make the card compact
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: Get.width * 0.4,
                    child: AutoSizeText(
                      currentLang == "en"
                          ? event.show.title.textEn
                          : currentLang == "ar"
                              ? event.show.title.textAr
                              : event.show.title.textKr,
                      overflow: TextOverflow.ellipsis,
                      maxFontSize: 20,
                      minFontSize: 18,
                      maxLines: 1,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 22),
                    ),
                  ),
                  5.height,
                  Row(
                    children: [
                      const Icon(
                        IconlyLight.timeCircle,
                        color: Colors.white,
                        size: 20,
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      Text(
                        AppFunction.durationToHour(
                            Duration(seconds: event.show.duration)),
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.normal,
                            fontSize: 12),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Row(
                    children: [
                      Text(
                        "${AppTexts.director.tr}:",
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.normal,
                            fontSize: 12),
                      ),
                      Text(
                        event.show.director!,
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.normal,
                            fontSize: 12),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  event.show.type == EventType.MOVIE
                      ? Row(
                          children: event.show.genres!
                              .map((e) => Container(
                                    margin: const EdgeInsets.only(right: 5),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 3, vertical: 1),
                                    decoration: BoxDecoration(
                                      color: Colors.black54,
                                      borderRadius: BorderRadius.circular(5),
                                    ),
                                    child: MultiLangText(
                                      style:
                                          const TextStyle(color: Colors.white),
                                      text: e.title,
                                    ),
                                  ))
                              .toList())
                      : Container(),
                  10.height,
                  event.show.type == EventType.MOVIE
                      ? Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              IconlyBold.star,
                              color: Colors.amber,
                              size: 20,
                            ),
                            4.width,
                            SizedBox(
                              child: AutoSizeText(
                                event.totalReview.averageRating
                                    .toDouble()
                                    .toString(),
                                maxFontSize: 12,
                                minFontSize: 10,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: Colors.white,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            SizedBox(
                              child: AutoSizeText(
                                ' (${event.totalReview.totalReview} ${"reviews".tr})',
                                maxFontSize: 12,
                                minFontSize: 10,
                                maxLines: 1,
                                style: const TextStyle(
                                  color: Colors.white,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        )
                      : const SizedBox(),
                  const Spacer(),
                  event.show.videoUrl != null
                      ? _trailerButton(context)
                      : Container(),
                ],
              ),
            )
          ],
        ),
      ),
    ]);
  }

  Container _trailerButton(BuildContext context) {
    return Container(
      width: Get.width * 0.4,
      height: 50,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Theme.of(context).secondaryHeaderColor.withOpacity(0.9),
          Theme.of(context).primaryColor
        ]),
        borderRadius: BorderRadius.circular(AppDefaults.radius),
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
        ),
        onPressed: () {
          //show dialog
          Get.dialog(
            AlertDialog(
              insetPadding: EdgeInsets.zero,
              contentPadding: EdgeInsets.zero,
              clipBehavior: Clip.antiAliasWithSaveLayer,
              backgroundColor: Colors.transparent,
              content: SizedBox(
                height: Get.height * 0.5,
                width: Get.width,
                child: YoutubePlayer(
                  controller: YoutubePlayerController(
                    initialVideoId: event.show.videoUrl!,
                    // params: const YoutubePlayerParams(
                    //   showControls: true,
                    //   showFullscreenButton: true,
                    // ),
                  ),
                  aspectRatio: 16 / 9,
                ),
              ),
            ),
          );
        },
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              IconlyBold.play,
              color: Colors.white,
              size: 20,
            ),
            4.width,
            Text(AppTexts.trailer.tr),
          ],
        ),
      ),
    );
  }
}
