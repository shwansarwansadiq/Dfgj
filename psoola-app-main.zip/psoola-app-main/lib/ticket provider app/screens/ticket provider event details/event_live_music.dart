// ignore_for_file: must_be_immutable

import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../../models/event_model.dart';
import '../../../screens/place details/place_details.dart';
import '../../../states/ticket_state.dart';
import '../../../utils/app_function.dart';
import '../../seats/live_music_seat_selection.dart';

class EventLiveMusicTicketProviderDetails extends StatelessWidget {
  final EventModel eventModel;
  EventLiveMusicTicketProviderDetails({super.key, required this.eventModel});

  final String currentLang = Get.locale!.languageCode;
  TicketState ticketState = Get.find<TicketState>();
  @override
  Widget build(BuildContext context) {
    ticketState.selectedDate = eventModel.startTime;

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        clipBehavior: Clip.none,
        children: [
          SingleChildScrollView(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                _buildHeader(),
                const SizedBox(height: 20),
                _buildBody(),
                const SizedBox(height: 100),
              ])),
        ],
      ),
    );
  }

  Padding _buildBody() {
    return Padding(
        padding: const EdgeInsets.only(left: 20, right: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [SeatSelectionLiveMusicTicketProvider(event: eventModel)],
        ));
  }

  Container _buildHeader() {
    return Container(
      height: Get.height * 0.5,
      width: double.infinity,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: CachedNetworkImageProvider(eventModel.show.poster),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(children: [
        Container(
          height: Get.height * 0.5,
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.transparent,
                Colors.black,
              ],
            ),
          ),
        ),
        Positioned(
          top: 30,
          left: currentLang == 'en' ? 10 : null,
          right: currentLang == 'ar' || currentLang == 'fa' ? 10 : null,
          child: Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: const BorderRadius.all(
                Radius.circular(25),
              ),
            ),
            child: IconButton(
              onPressed: () {
                Get.back();
              },
              icon: const Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 20,
          left: currentLang == 'en' ? 20 : null,
          right: currentLang == 'ar' || currentLang == 'fa' ? 20 : null,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                currentLang == 'en'
                    ? eventModel.show.title.textEn
                    : currentLang == 'ar'
                        ? eventModel.show.title.textAr
                        : eventModel.show.title.textKr,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Row(
                children: [
                  const Icon(
                    Icons.location_on,
                    color: Colors.white,
                    size: 15,
                  ),
                  const SizedBox(width: 5),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      AutoSizeText(
                        currentLang == 'en'
                            ? '${eventModel.places[0].location.province.name.textEn} - ${eventModel.places[0].location.district.name.textEn}'
                            : currentLang == 'ar'
                                ? '${eventModel.places[0].location.province.name.textAr} - ${eventModel.places[0].location.district.name.textAr}'
                                : '${eventModel.places[0].location.province.name.textKr} - ${eventModel.places[0].location.district.name.textKr}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(width: 5),
                      SizedBox(
                        height: 40,
                        child: TextButton(
                          onPressed: () {
                            Get.to(() => PlaceDetails(eventModel: eventModel));
                          },
                          child: Text(
                            currentLang == 'en'
                                ? eventModel.places[0].title.textEn
                                : currentLang == 'ar'
                                    ? eventModel.places[0].title.textAr
                                    : eventModel.places[0].title.textKr,
                            style: const TextStyle(
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  const Icon(
                    Icons.calendar_today,
                    color: Colors.white,
                    size: 15,
                  ),
                  const SizedBox(width: 5),
                  Row(
                    children: [
                      Text("${AppTexts.startDate.tr}: ",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                          )),
                      Text(
                        '${eventModel.startTime.day} /${eventModel.startTime.month}/ ${eventModel.startTime.year}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  const Icon(
                    Icons.access_time,
                    color: Colors.white,
                    size: 15,
                  ),
                  const SizedBox(width: 5),
                  Row(
                    children: [
                      Text("${AppTexts.endDate.tr}:",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                          )),
                      const SizedBox(width: 5),
                      Text(
                        '${eventModel.endTime.day} /${eventModel.endTime.month}/ ${eventModel.endTime.year}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  const Icon(
                    Icons.timer_outlined,
                    color: Colors.white,
                    size: 15,
                  ),
                  const SizedBox(width: 5),
                  Text("${AppTexts.time.tr}:",
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                      )),
                  const SizedBox(width: 5),
                  Text(
                    AppFunction.convertTimestampToTimeWithAmPm(
                            Timestamp.fromDate(eventModel.startTime))
                        .toString(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
