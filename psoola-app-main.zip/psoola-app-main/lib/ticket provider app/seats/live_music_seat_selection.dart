import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';

import '../../components/seat/model/seat_model.dart';
import '../../screens/buy_ticket.dart/components/seat_section/seat_section.dart';
import '../../states/ticket_state.dart';

class SeatSelectionLiveMusicTicketProvider extends StatelessWidget {
  final EventModel event;
  TicketState ticketState = Get.find<TicketState>();

  SeatSelectionLiveMusicTicketProvider({Key? key, required this.event})
      : super(key: key);
  @override
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          // Container(
          //   width: Get.width,
          //   padding: const EdgeInsets.symmetric(horizontal: 50),
          //   child: SvgPicture.asset(
          //     'assets/images/band.svg',
          //     height: 100,
          //   ),
          // ),
          SeatSection(
            event: event,
            placeId: ticketState.selectedPlace!.id,
            onSeatSelected: ({required Set<SeatNumber> seats}) {},
          ),
          const Divider(
            thickness: 1,
          ),
        ],
      ),
    );
  }
}
