import 'package:awesome_bottom_bar/awesome_bottom_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_vibrate/flutter_vibrate.dart';
import 'package:get/get.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/ticket%20provider%20app/tabs/home_tab.dart';
import 'package:psoola/ticket%20provider%20app/tabs/profile_tab.dart';

import '../utils/app_icons.dart';
import '../utils/app_texts.dart';

class TicketProviderNav extends StatefulWidget {
  const TicketProviderNav({Key? key}) : super(key: key);

  @override
  State<TicketProviderNav> createState() => TicketProviderNavState();
}

class TicketProviderNavState extends State<TicketProviderNav> {
  AuthState authState = Get.find<AuthState>();
  int currentWidget = 0;
  List<TabItem> tabs = [
    TabItem(
      icon: Icons.home,
      title: ''.tr,
    ),
    TabItem(
      icon: Icons.account_circle,
      title: ''.tr,
    ),
  ];

  List<Widget> widgets = [TicketProvideHomeTab(), TicketProviderProfileTab()];

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  CountStyle countStyle = const CountStyle(
    background: Colors.white,
    color: Colors.purple,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: false,
      backgroundColor: Theme.of(context).colorScheme.background,
      body: widgets[currentWidget],
      bottomNavigationBar: Container(
        height: 60,
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black12.withOpacity(0.1),
              spreadRadius: 5,
              blurRadius: 10,
              offset: const Offset(0, 3), // changes position of shadow
            ),
          ],
        ),
        child: BottomNavigationBar(
          iconSize: 25,
          elevation: 10,
          selectedLabelStyle: TextStyle(
            color: Theme.of(context).primaryColor,
            fontSize: 12,
          ),
          currentIndex: currentWidget,
          onTap: (index) {
            setState(() {
              currentWidget = index;
            });
            GetPlatform.isIOS
                ? Vibrate.feedback(FeedbackType.medium)
                : Vibrate.feedback(FeedbackType.medium);
          },
          items: [
            BottomNavigationBarItem(
              icon: SvgPicture.asset(
                AppIcons.home_outline,
                color: Colors.grey,
              ),
              activeIcon: SvgPicture.asset(
                AppIcons.home_filled,
                color: Theme.of(context).primaryColor,
              ),
              label: AppTexts.home.tr,
            ),
            BottomNavigationBarItem(
              icon: SvgPicture.asset(
                AppIcons.profile_outline,
                color: Colors.grey,
              ),
              activeIcon: SvgPicture.asset(
                AppIcons.profile_filled,
                color: Theme.of(context).primaryColor,
              ),
              label: AppTexts.profile.tr,
            ),
          ],
        ),
      ),
    );
  }
}
