// ignore_for_file: must_be_immutable

import 'package:bluelab_dialog/panara_dialogs.dart';
import 'package:flutter/material.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:get/get.dart';
import 'package:psoola/check_user.dart';
import 'package:psoola/components/developed_by.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/screens/notifications/notifications_screen.dart';
import 'package:psoola/utils/app_animations.dart';
import 'package:psoola/utils/app_icons.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../../components/profile_menu.dart';
import '../../../components/profile_pic.dart';
import '../../../models/user_model.dart';
import '../../auth/auth.dart';
import '../../screens/about/about_screen.dart';
import '../../screens/tabs/profile/components/customer_service.dart';
import '../../screens/tabs/profile/components/setting_screen.dart';

class TicketProviderProfileTab extends StatelessWidget {
  TicketProviderProfileTab({super.key});

  AuthState authState = Get.find<AuthState>();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            children: [
              Obx(() {
                UserModel user = authState.user.value;
                return GestureDetector(
                  onTap: () {
                    if (user.name == null) {
                      Get.to(() => const AuthScreen());
                    }
                  },
                  child: ProfilePic(
                    authState: authState,
                  ),
                );
              }),
              const SizedBox(height: 20),
              ProfileMenu(
                text: AppTexts.settings.tr,
                icon: AppIcons.settings,
                press: () {
                  Get.to(() => Settings());
                },
              ),
              ProfileMenu(
                text: AppTexts.notifications.tr,
                icon: AppIcons.bell,
                press: () {
                  // markAllNotificationsAsRead();
                  Get.to(() => const NotificationScreen());
                },
              ),
              ProfileMenu(
                text: AppTexts.customerService.tr,
                icon: AppIcons.lifeRing,
                press: () {
                  customBottomSheet(context);
                },
              ),
              ProfileMenu(
                text: AppTexts.aboutUs.tr,
                icon: AppIcons.info,
                press: () {
                  Get.to(() => const AboutScreen());
                },
              ),
              ProfileMenu(
                text: AppTexts.sharePsoola.tr,
                icon: AppIcons.share,
                press: () {
                  FlutterShare.share(
                      title: 'Psoola',
                      text: 'Psoola',
                      linkUrl: 'https://psoola.com',
                      chooserTitle: 'Psoola');
                },
              ),
              authState.user.value.name == null
                  ? const SizedBox()
                  : ProfileMenu(
                      text: AppTexts.logout.tr,
                      icon: AppIcons.logout,
                      press: () {
                        showAlert(context);
                      },
                    ),
              const SizedBox(
                height: 50,
              ),
              const DevelopedBy(),
              const SizedBox(
                height: 50,
              ),
            ],
          ),
        ),
      ),
    );
  }

  showAlert(BuildContext context) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: AppTexts.logout.tr,
      message: AppTexts.areYouSureYouWantToLogout.tr,
      confirmButtonText: AppTexts.logout.tr,
      textColor: Theme.of(context).textTheme.bodyLarge!.color,
      cancelButtonText: AppTexts.cancel.tr,
      onTapCancel: () {
        Get.back();
      },
      onTapConfirm: () {
        authState.logout().then((value) {
          Get.offAll(() => CheckUser());
        });
      },
      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true,
    );
  }

  void customBottomSheet(context) {
    showModalBottomSheet(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        context: context,
        isScrollControlled: false,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
        ),
        builder: (BuildContext context) {
          return const CustomerServiceBootmSheet();
        });
  }
}
