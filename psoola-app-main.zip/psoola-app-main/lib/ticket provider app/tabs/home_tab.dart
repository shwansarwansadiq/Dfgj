import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

import '../../api/places_api.dart';
import '../../utils/app_animations.dart';
import '../../utils/app_defaults.dart';
import '../../utils/app_texts.dart';
import '../screens/ticket provider event details/event_details.dart';

class TicketProvideHomeTab extends StatelessWidget {
  TicketProvideHomeTab({super.key});

  String currentLang = Get.locale!.languageCode;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),
                  _eventsSection(),
                  const SizedBox(height: 20),
                  // _mapWidget(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Column _eventsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        FutureBuilder(
          future: fetchPlaceEventsApi(null),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(
                child: Lottie.asset(
                  AppAnimations.loading,
                  height: 100,
                  width: 100,
                ),
              );
            } else if (snapshot.hasData) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                      '${AppTexts.availableEvents.tr} (${snapshot.data!.length})',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      )),
                  ListView.builder(
                      shrinkWrap: true,
                      itemCount: snapshot.data!.length,
                      clipBehavior: Clip.none,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            Get.to(() => TicketProviderEventDetails(
                                  eventModel: snapshot.data![index],
                                ));
                          },
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                height: 150,
                                width: Get.height,
                                decoration: BoxDecoration(
                                    color: Colors.black,
                                    image: DecorationImage(
                                        image: NetworkImage(
                                          snapshot.data![index].show.poster,
                                        ),
                                        fit: BoxFit.cover),
                                    borderRadius: BorderRadius.circular(
                                        AppDefaults.radius)),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                currentLang == 'en'
                                    ? snapshot.data![index].show.title.textEn
                                    : currentLang == 'ar'
                                        ? snapshot
                                            .data![index].show.title.textAr
                                        : snapshot
                                            .data![index].show.title.textKr,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 25),
                            ],
                          ),
                        );
                      }),
                ],
              );
            }
            return const SizedBox();
          },
        ),
      ],
    );
  }
}
