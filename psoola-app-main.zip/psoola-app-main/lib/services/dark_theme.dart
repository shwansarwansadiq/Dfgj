// ignore_for_file: prefer_const_constructors

import 'package:flex_color_scheme/flex_color_scheme.dart';
import 'package:flutter/material.dart';

import 'font_service.dart';

ThemeData darkTheme() {
  return FlexThemeData.dark(
    colorScheme: ColorScheme.dark(
      primary: Color(0xffFFAA17),
      secondary: Color(0xffa1e9df),
      error: Color(0xffcf6679),
    ),
    surfaceMode: FlexSurfaceMode.highScaffoldLevelSurface,
    blendLevel: 0,
    appBarElevation: 0,
    useMaterial3: true,
    transparentStatusBar: true,
    fontFamily: FontFamilyService().fontFamily,
    tabBarStyle: FlexTabBarStyle.forBackground,
    appBarStyle: FlexAppBarStyle.surface,
    tooltipsMatchBackground: true,
    swapColors: false,
    darkIsTrueBlack: false,
    visualDensity: FlexColorScheme.comfortablePlatformDensity,
    subThemesData: FlexSubThemesData(
        useTextTheme: false,
        fabUseShape: false,
        interactionEffects: true,
        bottomNavigationBarElevation: 0,
        bottomNavigationBarOpacity: 0.95,
        navigationBarOpacity: 0.95,
        navigationBarMutedUnselectedIcon: true,
        inputDecoratorIsFilled: true,
        inputDecoratorBorderType: FlexInputBorderType.outline,
        inputDecoratorUnfocusedHasBorder: true,
        blendOnColors: true,
        inputDecoratorRadius: 15,
        elevatedButtonRadius: 15,
        blendTextTheme: false,
        outlinedButtonRadius: 15,
        bottomSheetRadius: 30),
  );
}
