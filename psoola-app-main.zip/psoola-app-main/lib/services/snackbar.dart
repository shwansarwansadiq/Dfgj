import 'package:flutter/material.dart';

void openSnackbar(context, snackMessage, {snackDuration = 5}) {
  final snackbar = SnackBar(
    duration: Duration(seconds: snackDuration),
    content: Container(
      alignment: Alignment.centerLeft,
      height: 40,
      child: Text(
        snackMessage,
        style: const TextStyle(
          fontSize: 16,
        ),
      ),
    ),
    action: SnackBarAction(
      label: 'Ok',
      textColor: Colors.white,
      onPressed: () {},
    ),
  );
  ScaffoldMessenger.of(context).showSnackBar(snackbar);
}
