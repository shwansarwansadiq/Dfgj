import 'package:get_storage/get_storage.dart';

class FontFamilyService {
  final _box = GetStorage();
  final _key = 'fontFamily';

  String get fontFamily => _loadFontFamilyFromBox() ?? 'shabnam';

  _saveFontFamilyToBox(String fontFamily) => _box.write(_key, fontFamily);

  _loadFontFamilyFromBox() => _box.read(_key);

  void switchFontFamily(String fontFamily) {
    _saveFontFamilyToBox(fontFamily);
  }
}
