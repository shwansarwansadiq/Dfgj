import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class LanguageService {
  final _box = GetStorage();
  final _key = 'language';

  String get language => _loadLanguageFromBox() ?? 'en';

  _saveLanguageToBox(String language) => _box.write(_key, language);

  _loadLanguageFromBox() => _box.read(_key);

  void switchLanguage(String language) {
    _saveLanguageToBox(language);
    Get.updateLocale(Locale(language));
  }
}
