import 'package:get_storage/get_storage.dart';

saveNotification(NotificationModel notification) async {
  final box = GetStorage();
  const key = 'notifications';
  List<NotificationModel> notifications = box.read(key) ?? [];
  notifications.add(notification);
  box.write(key, notifications);
}

getSavedNotifications() {
  final box = GetStorage();
  const key = 'notifications';
  List<NotificationModel> notifications = box.read(key) ?? [];
  return notifications;
}

deleteSingleNotification(int index) async {
  final box = GetStorage();
  const key = 'notifications';
  List<NotificationModel> notifications = box.read(key) ?? [];
  notifications.removeAt(index);

  box.write(key, notifications);
  await getSavedNotifications();
}

deleteAllNotifications() {
  final box = GetStorage();
  const key = 'notifications';
  box.remove(key);
}

//clear all notifications

// int getUnreadNotifications() {
//   final box = GetStorage();
//   const key = 'notifications';
//   List<NotificationModel> notifications = box.read(key) ?? [];
//   int unread = 0;
//   for (var element in notifications) {
//     if (element.isRead == false) {
//       unread++;
//     }
//   }
//   return unread;
// }

// markAllNotificationsAsRead() {
//   final box = GetStorage();
//   const key = 'notifications';
//   List<NotificationModel> notifications = box.read(key) ?? [];
//   for (var element in notifications) {
//     element.isRead = true;
//   }
//   box.write(key, notifications);
// }

class NotificationModel {
  final String title;
  final String description;
  final String? image;
  final String? data;

  NotificationModel({
    required this.title,
    required this.description,
    this.image,
    this.data,
  });
}
