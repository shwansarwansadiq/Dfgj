import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/states/event_events_state.dart';

import '../../../../api/event_event_api.dart';
import '../../../../components/cards/event_home_card.dart';
import '../../../../components/section_title.dart';
import '../../../../models/category_model.dart';
import '../../../../models/event_model.dart';
import '../../../../utils/app_constants.dart';
import '../../../../utils/app_texts.dart';

class EventEventsSection extends StatefulWidget {
  const EventEventsSection({super.key});

  @override
  State<EventEventsSection> createState() => _EventEventsSectionState();
}

class _EventEventsSectionState extends State<EventEventsSection> {
  EventEventsState eventEventsState = Get.find<EventEventsState>();
  late PageController _pageController;
  int initialPage = 0;

  @override
  void initState() {
    EventApi().fetchEventEventsApi();
    super.initState();
    _pageController = PageController(
      // so that we can have small portion shown on left and right side
      viewportFraction: 0.8,
      // by default our movie poster
      initialPage: initialPage,
    );
  }

  List<CategoryModel> categories = categoriesList();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<EventEventsState>(builder: (state) {
      List<EventModel> events = state.getEvents;
      return events.isEmpty
          ? const SizedBox()
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                    right: 20,
                    bottom: 10,
                  ),
                  child: SectionTitle(
                    title: AppTexts.events.tr,
                    category: categories[4],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: AppConstants.kDefaultPadding),
                  child: AspectRatio(
                    aspectRatio: 0.85,
                    child: PageView.builder(
                      onPageChanged: (value) {
                        initialPage = value;
                      },
                      controller: _pageController,
                      physics: const BouncingScrollPhysics(),
                      itemCount: events.length, // we have 3 demo movies
                      itemBuilder: (context, index) => AnimatedBuilder(
                        animation: _pageController,
                        builder: (context, child) {
                          double value = 0;
                          if (_pageController.position.haveDimensions) {
                            value = index - _pageController.page!;

                            value = (value * 0.038).clamp(-1, 1);
                          }
                          return AnimatedOpacity(
                            duration: const Duration(milliseconds: 350),
                            opacity: initialPage == index ? 1 : 0.4,
                            child: Transform.rotate(
                              angle: math.pi * value,
                              child: EventHomeCard(event: events[index]),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            );
    });
  }
}
