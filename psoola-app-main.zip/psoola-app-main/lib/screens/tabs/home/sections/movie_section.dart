// ignore_for_file: library_private_types_in_public_api

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/api/movies_api.dart';

import 'package:psoola/states/movies_state.dart';
import 'package:psoola/utils/app_constants.dart';

import '../../../../components/cards/event_home_card.dart';
import '../../../../components/section_title.dart';
import '../../../../models/category_model.dart';
import '../../../../utils/app_texts.dart';

class MoviesSection extends StatefulWidget {
  const MoviesSection({super.key});

  @override
  _MoviesSectionState createState() => _MoviesSectionState();
}

class _MoviesSectionState extends State<MoviesSection> {
  late PageController _pageController;
  int initialPage = 0;

  @override
  void initState() {
    fetchMoviesApi();
    super.initState();
    _pageController = PageController(
      // so that we can have small portion shown on left and right side
      viewportFraction: 0.8,
      // by default our movie poster
      initialPage: initialPage,
    );
  }

  @override
  void dispose() {
    super.dispose();
    _pageController.dispose();
  }

  List<CategoryModel> categories = categoriesList();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<MoviesState>(builder: (state) {
      List moviesState = state.getMovies;
      return moviesState.isEmpty
          ? Container()
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                    right: 20,
                    bottom: 10,
                    top: 30,
                  ),
                  child: SectionTitle(
                    title: AppTexts.movies,
                    category: categories[0],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: AppConstants.kDefaultPadding),
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: PageView.builder(
                      onPageChanged: (value) {
                          initialPage = value;
                      },
                      controller: _pageController,
                      physics: const BouncingScrollPhysics(),
                      itemCount: moviesState.length, // we have 3 demo movies
                      itemBuilder: (context, index) => AnimatedBuilder(
                        animation: _pageController,
                        builder: (context, child) {
                          double value = 0;
                          if (_pageController.position.haveDimensions) {
                            value = index - _pageController.page!;

                            value = (value * 0.038).clamp(-1, 1);
                          }
                          return AnimatedOpacity(
                            duration: const Duration(milliseconds: 350),
                            opacity: initialPage == index ? 1 : 0.4,
                            child: Transform.rotate(
                              angle: math.pi * value,
                              child: EventHomeCard(event: moviesState[index]),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            );
    });
  }
}
