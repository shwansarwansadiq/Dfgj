import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/api/live_music_api.dart';
import 'package:psoola/states/concert_state.dart';
import 'package:psoola/states/live_music_state.dart';
import 'dart:math' as math;

import '../../../../components/cards/event_home_card.dart';
import '../../../../components/section_title.dart';
import '../../../../models/category_model.dart';
import '../../../../models/event_model.dart';
import '../../../../utils/app_constants.dart';
import '../../../../utils/app_texts.dart';

class LiveMusicsSection extends StatefulWidget {
  const LiveMusicsSection({super.key});

  @override
  State<LiveMusicsSection> createState() => _LiveMusicsSectionState();
}

class _LiveMusicsSectionState extends State<LiveMusicsSection> {
  ConcertsState liveMusicsState = Get.find<ConcertsState>();
  late PageController _pageController;
  int initialPage = 0;

  @override
  void initState() {
    fetchLiveMusicsApi();
    super.initState();
    _pageController = PageController(
      // so that we can have small portion shown on left and right side
      viewportFraction: 0.8,
      // by default our movie poster
      initialPage: initialPage,
    );
  }

  List<CategoryModel> categories = categoriesList();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<LiveMusicState>(builder: (state) {
      List<EventModel> liveMusics = state.getLiveMusics;
      return liveMusics.isEmpty
          ? const SizedBox()
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                    right: 20,
                    bottom: 10,
                    top: 30,
                  ),
                  child: SectionTitle(
                    title: AppTexts.liveMusics,
                    category: categories[1],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: AppConstants.kDefaultPadding),
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: PageView.builder(
                      onPageChanged: (value) {
                          initialPage = value;
                      },
                      controller: _pageController,
                      physics: const BouncingScrollPhysics(),
                      itemCount: liveMusics.length,
                      itemBuilder: (context, index) => AnimatedBuilder(
                        animation: _pageController,
                        builder: (context, child) {
                          double value = 0;
                          if (_pageController.position.haveDimensions) {
                            value = index - _pageController.page!;
                            value = (value * 0.038).clamp(-1, 1);
                          }
                          return AnimatedOpacity(
                            duration: const Duration(milliseconds: 350),
                            opacity: initialPage == index ? 1 : 0.4,
                            child: Transform.rotate(
                              angle: math.pi * value,
                              child: EventHomeCard(event: liveMusics[index]),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            );
    });
  }
}
