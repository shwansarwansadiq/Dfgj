import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/api/concerts_api.dart';
import 'package:psoola/states/concert_state.dart';
import 'dart:math' as math;

import '../../../../components/cards/event_home_card.dart';
import '../../../../components/section_title.dart';
import '../../../../models/category_model.dart';
import '../../../../models/event_model.dart';
import '../../../../utils/app_constants.dart';
import '../../../../utils/app_texts.dart';

class ConcertsSection extends StatefulWidget {
  const ConcertsSection({super.key});

  @override
  State<ConcertsSection> createState() => _ConcertsSectionState();
}

class _ConcertsSectionState extends State<ConcertsSection> {
  ConcertsState concertsState = Get.find<ConcertsState>();
  late PageController _pageController;
  int initialPage = 0;

  @override
  void initState() {
    fetchConcertsApi();
    super.initState();
    _pageController = PageController(
      // so that we can have small portion shown on left and right side
      viewportFraction: 0.8,
      // by default our movie poster
      initialPage: initialPage,
    );
  }

  List<CategoryModel> categories = categoriesList();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ConcertsState>(builder: (state) {
      List<EventModel> concerts = state.getConcerts;
      return concerts.isEmpty
          ? Container()
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    left: 20,
                    right: 20,
                    bottom: 10,
                    top: 30,
                  ),
                  child: SectionTitle(
                    title: AppTexts.concerts,
                    category: categories[2],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                      vertical: AppConstants.kDefaultPadding),
                  child: AspectRatio(
                    aspectRatio: 0.85,
                    child: PageView.builder(
                      onPageChanged: (value) {
                          initialPage = value;
                      },
                      controller: _pageController,
                      physics: const BouncingScrollPhysics(),
                      itemCount: concerts.length, // we have 3 demo movies
                      itemBuilder: (context, index) => AnimatedBuilder(
                        animation: _pageController,
                        builder: (context, child) {
                          double value = 0;
                          if (_pageController.position.haveDimensions) {
                            value = index - _pageController.page!;

                            value = (value * 0.038).clamp(-1, 1);
                          }
                          return AnimatedOpacity(
                            duration: const Duration(milliseconds: 350),
                            opacity: initialPage == index ? 1 : 0.4,
                            child: Transform.rotate(
                              angle: math.pi * value,
                              child: EventHomeCard(event: concerts[index]),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            );
    });
  }
}
