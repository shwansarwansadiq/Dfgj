import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:card_swiper/card_swiper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/api/swiper_api.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/states/swiper_state.dart';
import 'package:shimmer/shimmer.dart';

import '../../../../models/event_model.dart';
import '../../../../models/event_type_model.dart';
import '../../../event_details/event_details.dart';

class HomeSwiper extends StatelessWidget {
  HomeSwiper({super.key});

  final String currentLanguage = Get.locale!.languageCode;
  final SwiperEventsState swiperEventsState = Get.find<SwiperEventsState>();

  final String currentLang = Get.locale!.languageCode;

  @override
  Widget build(BuildContext context) {
    fetchSwipersApi();
    return GetBuilder<SwiperEventsState>(builder: (state) {
      List<EventModel> swiperEvents = state.getSwiperEvents;

      return swiperEvents.isNotEmpty
          ? SizedBox(
              height: 500,
              child: Swiper(
                onTap: (int index) {
                  Get.to(() => EventDetails(eventModel: swiperEvents[index]));
                },
                physics: const BouncingScrollPhysics(),
                itemBuilder: (BuildContext context, int index) {
                  return Stack(alignment: Alignment.bottomCenter, children: [
                    FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                          width: Get.width,
                          height: 500,
                          child: CachedNetworkImage(
                            imageUrl: swiperEvents[index].show.poster,
                            fit: BoxFit.cover,
                          )),
                    ),
                    Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Colors.black.withOpacity(0.7),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      left: 0,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              currentLanguage == 'en'
                                  ? swiperEvents[index].show.title.textEn
                                  : currentLanguage == 'ar'
                                      ? swiperEvents[index].show.title.textAr
                                      : swiperEvents[index].show.title.textKr,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 40,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            swiperEvents[index].show.type == EventType.MOVIE
                                ? Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(
                                        IconlyBold.star,
                                        color: Colors.amber,
                                        size: 20,
                                      ),
                                      4.width,
                                      SizedBox(
                                        child: AutoSizeText(
                                          swiperEvents[index]
                                              .totalReview
                                              .averageRating
                                              .toDouble()
                                              .toString(),
                                          maxFontSize: 12,
                                          minFontSize: 10,
                                          maxLines: 1,
                                          style: const TextStyle(
                                            color: Colors.white,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      SizedBox(
                                        child: AutoSizeText(
                                          ' (${swiperEvents[index].totalReview.totalReview} ${"reviews".tr})',
                                          maxFontSize: 12,
                                          minFontSize: 10,
                                          maxLines: 1,
                                          style: const TextStyle(
                                            color: Colors.white,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  )
                                : SizedBox(
                                    width: Get.width * 0.8,
                                    child: AutoSizeMultiLangText(
                                      text:
                                          swiperEvents[index].provinces[0].name,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 16,
                                        fontWeight: FontWeight.normal,
                                      ),
                                    ),
                                  ),
                            SizedBox(height: Get.height * 0.05),
                          ],
                        ),
                      ),
                    ),
                  ]);
                },
                autoplay: true,
                itemCount: swiperEvents.length,
                pagination: SwiperPagination(
                    builder: const DotSwiperPaginationBuilder(
                      color: Colors.grey,
                      activeColor: Colors.white,
                      size: 5,
                      activeSize: 10,
                    ),
                    alignment: currentLanguage == 'en'
                        ? Alignment.bottomRight
                        : Alignment.bottomLeft),
              ),
            )
          : Shimmer.fromColors(
              baseColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.grey[800]!
                  : Colors.grey[300]!,
              highlightColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.grey[800]!
                  : Colors.grey[100]!,
              child: Container(
                height: 450,
                color: Colors.grey,
                child: Center(child: Text('Loading...')),
              ),
            );
    });
  }
}
