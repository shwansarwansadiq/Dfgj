// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/models/category_model.dart';

import '../../../../components/cards/categories_card.dart';
import '../../../../utils/app_texts.dart';

class CategoriesSection extends StatelessWidget {
  CategoriesSection({super.key});

  List<CategoryModel> categoriesListData = categoriesList();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Text(AppTexts.categories.tr,
                style:
                    const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
            // const Spacer(),
            // TextButton(onPressed: () {}, child: const Text('See all'))
          ],
        ),
        const SizedBox(height: 20),
        SizedBox(
            height: 150,
            child: ListView.builder(
              padding: const EdgeInsets.only(left: 10, right: 10),
              clipBehavior: Clip.none,
              scrollDirection: Axis.horizontal,
              itemCount: categoriesListData.length,
              itemBuilder: (context, index) {
                return CategoriesCard(
                    categoriesListData: categoriesListData[index]);
              },
            )),
      ],
    );
  }
}
