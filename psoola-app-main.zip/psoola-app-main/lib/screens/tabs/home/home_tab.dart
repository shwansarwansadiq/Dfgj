// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:psoola/screens/tabs/home/sections/categories_section.dart';
import 'package:psoola/screens/tabs/home/sections/concerts_section.dart';
import 'package:psoola/screens/tabs/home/sections/events_events_section.dart';
import 'package:psoola/screens/tabs/home/sections/live_music_section.dart';
import 'package:psoola/screens/tabs/home/sections/movie_section.dart';
import 'package:psoola/utils/app_defaults.dart';

import 'sections/home_swiper.dart';
import 'sections/theatre_section.dart';

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    //fetchProvincesApi();
    return CustomScrollView(slivers: [
      // SliverAppBar(
      //     title: GetBuilder<ProvinceState>(
      //       builder: ((state) => TextButton(
      //             onPressed: () {
      //               //show dialog
      //               showDialog(
      //                   context: context,
      //                   builder: (context) {
      //                     return AlertDialog(
      //                       title: Text(AppTexts.selectProvince.tr),
      //                       content: SizedBox(
      //                         height: 200,
      //                         width: 200,
      //                         child: ListView.builder(
      //                             shrinkWrap: true,
      //                             itemCount: state.getProvinces.length,
      //                             itemBuilder: (context, index) {
      //                               return ListTile(
      //                                 title: Text(state
      //                                     .getProvinces[index].name.textAr),
      //                                 onTap: () {
      //                                   state.setSelectedProvince(
      //                                       state.getProvinces[index]);
      //                                   Get.back();
      //                                 },
      //                               );
      //                             }),
      //                       ),
      //                     );
      //                   });
      //             },
      //             child: Row(
      //               mainAxisSize: MainAxisSize.min,
      //               children: [
      //                 Text(
      //                   state.selectedProvince?.name.textAr ??
      //                       AppTexts.selectProvince.tr,
      //                 ),
      //                 Icon(Icons.arrow_drop_down)
      //               ],
      //             ),
      //           )),
      //     ),
      //     floating: true,
      //     pinned: true),
      SliverToBoxAdapter(
        child: HomeSwiper(),
      ),

      SliverPadding(
        padding:
            EdgeInsets.symmetric(vertical: 40, horizontal: AppDefaults.padding),
        sliver: SliverToBoxAdapter(
          child: CategoriesSection(),
        ),
      ),
      SliverPadding(
        padding: EdgeInsets.symmetric(vertical: AppDefaults.padding),
        sliver: SliverToBoxAdapter(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: const [
              MoviesSection(),
              TheatreSection(),
              LiveMusicsSection(),
              ConcertsSection(),
              EventEventsSection()
            ],
          ),
        ),
      ),
    ]);
  }
}
