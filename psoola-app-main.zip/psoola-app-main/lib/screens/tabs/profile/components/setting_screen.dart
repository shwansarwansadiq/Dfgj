import 'dart:math' as math;

import 'package:bluelab_dialog/panara_dialogs.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/utils/app_icons.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../../../api/user_api.dart';
import '../../../../check_user.dart';
import '../../../../components/botton_up_menu.dart';
import '../../../../services/theme_service.dart';
import '../../../../utils/app_animations.dart';
import '../../../../utils/app_function.dart';

class Settings extends StatelessWidget {
  Settings({Key? key}) : super(key: key);

  updateLocale(Locale locale, BuildContext context) {
    Get.back();
    Get.updateLocale(locale);
  }

  AuthState authState = Get.find<AuthState>();

  @override
  Widget build(BuildContext context) {
    bool tempNotfy = false;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppTexts.settings.tr,
        ),
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            children: <Widget>[
              const SizedBox(height: 10),
              changeLanguage(context),
              const SizedBox(height: 10),
              changeFont(context),
              const SizedBox(height: 10),
              DarkModeSwitch(
                icon: AppIcons.moon,
                isActive: tempNotfy,
                ontab: () {
                  // Get.to(() => ChangePassword());
                  bool isDarkMode = ThemeService().switchTheme();
                  return isDarkMode;
                },
                title: AppTexts.darkMode.tr,
              ),
              NotificationSwitch(
                icon: AppIcons.bell,
                isActive: true,
                ontab: () {
                  tempNotfy = !tempNotfy;
                  return tempNotfy;
                },
                title: AppTexts.notifications.tr,
              ),
              ProfileCard(
                icon: AppIcons.document,
                ontab: () {
                  Get.bottomSheet(BottonUpMenu(
                      title: AppTexts.termsAndConditions.tr,
                      content: const Expanded(
                        child: SingleChildScrollView(
                          child: Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                                '''We, at Psoola, understand the importance of privacy and are committed to protecting the personal information of our users. This privacy policy applies to our movie, concert, and live music ticketing system application (the "Application") and explains how we collect, use, and share information about you when you use the Application.
Collection of Personal Information
We may collect personal information about you when you use the Application. This may include your name, email address, phone number, payment information, and location. We may also collect information about your device, such as your IP address and device identifier.
Use of Personal Information
We may use the personal information we collect for the following purposes:
To process your ticket purchases and provide you with tickets to the events you have selected.
To communicate with you about your ticket purchases and provide you with customer support.
To personalize your experience on the Application by showing you content and ads that may be of interest to you.
To improve the Application and develop new features.
To comply with legal obligations and protect the rights and safety of ourselves and others.
Sharing of Personal Information
We may share your personal information with third parties for the following purposes:
To process your ticket purchases and provide you with tickets to the events you have selected. This may include sharing your information with event organizers, ticketing partners, and payment processors.
To serve you personalized ads. This may include sharing your information with advertising partners to show you ads that may be of interest to you.
To comply with legal obligations, such as responding to a subpoena or court order.
To protect the rights and safety of ourselves and others. This may include sharing your information with law enforcement or other government agencies as required by law.
Data Retention
We will retain your personal information for as long as necessary to fulfill the purposes for which it was collected, unless a longer retention period is required or permitted by law.
Security
We take reasonable measures to protect the personal information we collect from unauthorized access, use, or disclosure. However, no method of transmission over the internet or method of electronic storage is completely secure, and we cannot guarantee the absolute security of your personal information.
Changes to this Privacy Policy
We may update this privacy policy from time to time to reflect changes to our practices or for other operational, legal, or regulatory reasons. We encourage you to review this privacy policy regularly for any changes,
Contact Us'''),
                          ),
                        ),
                      )));
                },
                title: "terms_and_conditions".tr,
              ),
              authState.user.value.name == null
                  ? const SizedBox()
                  : ProfileCard(
                      title: AppTexts.delete.tr,
                      icon: AppIcons.delete,
                      ontab: () {
                        showAlertDelete(context);
                      }),
            ],
          ),
        ),
      ),
    );
  }

  showAlertDelete(BuildContext context) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: AppTexts.delete.tr,
      message: AppTexts.are_you_sure_you_want_to_delete_your_account.tr,
      confirmButtonText: AppTexts.delete.tr,
      textColor: Theme.of(context).textTheme.bodyLarge!.color,
      cancelButtonText: AppTexts.cancel.tr,
      onTapCancel: () {
        Get.back();
      },
      onTapConfirm: () async {
        await Get.find<UserServiceProvider>().deleteAccount();
        authState.logout().then((value) {
          Get.offAll(() => CheckUser());
        });
      },
      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true,
    );
  }

  ProfileCard changeLanguage(BuildContext context) {
    return ProfileCard(
      icon: AppIcons.world,
      ontab: () {
        showModalBottomSheet(
            barrierColor: Colors.black.withOpacity(0.5),
            context: context,
            isScrollControlled: true,
            builder: (BuildContext context) {
              return Wrap(
                runSpacing: 10,
                spacing: 20,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 10,
                      right: 10,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              const SizedBox(height: 10),
                              Center(
                                child: Text(
                                  AppTexts.select_your_language.tr,
                                  style: const TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 30),
                              SizedBox(
                                height: 60,
                                child: OutlinedButton(
                                  style: OutlinedButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(13.0),
                                    ),
                                    foregroundColor:
                                        Theme.of(context).primaryColor,
                                  ),
                                  onPressed: () {
                                    AppFunction.changeLanguage(
                                        const Locale("fa"));
                                    Get.back();
                                  },
                                  child: const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        CircleAvatar(
                                          radius: 20,
                                          backgroundColor: Colors.white,
                                          backgroundImage: AssetImage(
                                              'assets/images/kurdish_flag.png'),
                                        ),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text("کوردی",
                                            style: TextStyle(
                                              fontSize: 20,
                                            )),
                                      ]),
                                ),
                              ),
                              8.height,
                              SizedBox(
                                height: 60,
                                child: OutlinedButton(
                                  style: OutlinedButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(13.0),
                                    ),
                                    foregroundColor:
                                        Theme.of(context).primaryColor,
                                  ),
                                  onPressed: () {
                                    AppFunction.changeLanguage(
                                        const Locale("ar"));
                                    Get.back();
                                  },
                                  child: const Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      CircleAvatar(
                                        radius: 20,
                                        backgroundColor: Colors.white,
                                        backgroundImage: AssetImage(
                                            'assets/images/iraq_flag.jpg'),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text("العربیة",
                                          style: TextStyle(
                                            fontSize: 20,
                                          )),
                                    ],
                                  ),
                                ),
                              ),
                              8.height,
                              SizedBox(
                                height: 60,
                                child: OutlinedButton(
                                  style: OutlinedButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(13.0),
                                    ),
                                    foregroundColor:
                                        Theme.of(context).primaryColor,
                                  ),
                                  onPressed: () {
                                    AppFunction.changeLanguage(
                                        const Locale("en"));
                                    Get.back();
                                  },
                                  child: const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        CircleAvatar(
                                          radius: 20,
                                          backgroundColor: Colors.white,
                                          backgroundImage: AssetImage(
                                              'assets/images/british_flag.png'),
                                        ),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text("English",
                                            style: TextStyle(
                                              fontSize: 20,
                                            )),
                                      ]),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            });
      },
      title: "language".tr,
    );
  }

  ProfileCard changeFont(BuildContext context) {
    return ProfileCard(
        icon: AppIcons.text,
        ontab: () {
          showModalBottomSheet(
              barrierColor: Colors.black.withOpacity(0.5),
              context: context,
              backgroundColor: Theme.of(context).colorScheme.background,
              isScrollControlled: true,
              builder: (BuildContext context) {
                return Wrap(
                  runSpacing: 10,
                  spacing: 20,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        left: 10,
                        right: 10,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(20.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                const SizedBox(height: 10),
                                Center(
                                  child: Text(
                                    AppTexts.select_your_language.tr,
                                    style: const TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 30),
                                SizedBox(
                                  height: 60,
                                  child: OutlinedButton(
                                    style: OutlinedButton.styleFrom(
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(13.0),
                                      ),
                                      foregroundColor:
                                          Theme.of(context).primaryColor,
                                    ),
                                    onPressed: () {
                                      AppFunction.changeFontFamily("shabnam");
                                      Get.back();
                                    },
                                    child: const Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text("shabnam font - شەبنەم فۆنت",
                                            style: TextStyle(
                                                fontSize: 20,
                                                fontFamily: "shabnam")),
                                      ],
                                    ),
                                  ),
                                ),
                                8.height,
                                SizedBox(
                                  height: 60,
                                  child: OutlinedButton(
                                    style: OutlinedButton.styleFrom(
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(13.0),
                                      ),
                                      foregroundColor:
                                          Theme.of(context).primaryColor,
                                    ),
                                    onPressed: () {
                                      AppFunction.changeFontFamily("lumia");
                                      Get.back();
                                    },
                                    child: const Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: <Widget>[
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Text("Sarchia lumia - سەرچیا لومیا",
                                              style: TextStyle(
                                                  fontSize: 20,
                                                  fontFamily: "lumia")),
                                        ]),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              });
        },
        title: AppTexts.font.tr);
  }
}

class ProfileCard extends StatelessWidget {
  const ProfileCard({
    Key? key,
    required this.icon,
    required this.ontab,
    required this.title,
  }) : super(key: key);
  final String icon;
  final String title;
  final Function ontab;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: SizedBox(
        height: 60,
        child: TextButton(
          style: TextButton.styleFrom(
            foregroundColor: Colors.grey,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13.0),
            ),
          ),
          onPressed: () => ontab(),
          child: Row(
            children: <Widget>[
              SvgPicture.asset(
                icon,
                height: 20,
                color: Colors.grey,
              ),
              const SizedBox(width: 20),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                ),
              ),
              const Spacer(),
              Transform(
                alignment: Alignment.center,
                transform: Get.locale == const Locale("en")
                    ? Matrix4.rotationY(math.pi)
                    : Matrix4.rotationY(0),
                child: SvgPicture.asset(AppIcons.angleLeft,
                    height: 18, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ignore: must_be_immutable
class DarkModeSwitch extends StatelessWidget {
  DarkModeSwitch({
    Key? key,
    required this.icon,
    required this.ontab,
    required this.title,
    required this.isActive,
  }) : super(key: key);
  final String icon;
  final String title;
  final Function ontab;
  bool isActive;

  bool isDarkTheme = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: SizedBox(
        height: 60,
        child: TextButton(
          style: TextButton.styleFrom(
            foregroundColor: Colors.grey,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13.0),
            ),
          ),
          onPressed: () {
            isActive = ontab();
          },
          child: Row(
            children: <Widget>[
              SvgPicture.asset(
                icon,
                height: 20,
                color: Colors.grey,
              ),
              const SizedBox(width: 20),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                ),
              ),
              const Spacer(),
              CupertinoSwitch(
                activeColor: Theme.of(context).primaryColor,
                value: ThemeService().theme == ThemeMode.dark ? true : false,
                onChanged: (value) {
                  if (ThemeService().theme == ThemeMode.dark) {
                    ThemeService().switchTheme();
                    isDarkTheme = true;
                  } else {
                    ThemeService().switchTheme();
                    isDarkTheme = false;
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NotificationSwitch extends StatelessWidget {
  NotificationSwitch({
    Key? key,
    required this.icon,
    required this.ontab,
    required this.title,
    required this.isActive,
  }) : super(key: key);
  final String icon;
  final String title;
  final Function ontab;
  bool isActive;

  bool isDarkTheme = false;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10),
      child: SizedBox(
        height: 60,
        child: TextButton(
          style: TextButton.styleFrom(
            foregroundColor: Colors.grey,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(13.0),
            ),
          ),
          onPressed: () {
            isActive = ontab();
          },
          child: Row(
            children: <Widget>[
              SvgPicture.asset(
                icon,
                height: 20,
                color: Colors.grey,
              ),
              const SizedBox(width: 20),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                ),
              ),
              const Spacer(),
              CupertinoSwitch(
                activeColor: Theme.of(context).primaryColor,
                value: isActive,
                onChanged: (value) {
                  isActive = !isActive;
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
