import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/utils/app_animations.dart';
import 'package:rounded_loading_button_plus/rounded_loading_button.dart';

import '../../../../api/balance_code_api.dart';
import '../../../../controllers/auth_controller.dart';
import '../../../../utils/app_image.dart';
import '../../../../utils/app_texts.dart';

class AddBalanceScreen extends StatelessWidget {
  late String? _balanceCode;

  final RoundedLoadingButtonController _btnController = RoundedLoadingButtonController();
  final _formKey = GlobalKey<FormState>();
  final _balanceController = TextEditingController();

  AddBalanceScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        hideKeyboard(context);
      },
      child: Scaffold(
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        floatingActionButton: submitButton(context),
        appBar: AppBar(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          elevation: 0,
          title: Text(AppTexts.add_balance_to_your_wallet.tr),
          centerTitle: true,
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.black,
            ),
          ),
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                const SizedBox(
                  height: 20,
                ),
                Lottie.asset(AppAnimations.creditCard, height: Get.width * 0.5, width: Get.width * 0.5),
                const SizedBox(
                  height: 10,
                ),
                Container(
                  height: 40,
                  width: Get.width,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage(AppImage.logo),
                      fit: BoxFit.contain,
                    ),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                Obx(() {
                  var user = Get.find<AuthState>().user.value;
                  return Text(
                    "${AppTexts.balance.tr}: ${user.balance.toString()} IQD",
                    style: const TextStyle(color: Colors.grey, fontSize: 20),
                  );
                }),

                const SizedBox(
                  height: 20,
                ),

                const SizedBox(
                  height: 20,
                ),

                // text input for just number
                Container(
                  width: Get.width,
                  padding: const EdgeInsets.only(left: 20, right: 20),
                  child: TextFormField(
                    controller: _balanceController,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    keyboardType: TextInputType.number,
                    onChanged: (value) {
                      _balanceCode = value;
                    },
                    validator: (value) {
                      if (value!.isEmpty) {
                        return AppTexts.please_enter_balance_code.tr;
                      } else if (value.length < 12) {
                        return AppTexts.pleaseEnterTwelveDigits.tr;
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                      suffixIcon: const Icon(Icons.qr_code),
                      contentPadding: const EdgeInsets.all(15),
                      hintText: AppTexts.enter_code.tr,
                      filled: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                // submit button with primary color

                const SizedBox(
                  height: 40,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  submitButton(BuildContext context) {
    return Container(
      width: Get.width,
      padding: const EdgeInsets.only(left: 20, right: 20),
      child: RoundedLoadingButton(
        // add primary color to the button
        borderRadius: 15,
        color: Theme.of(context).primaryColor,
        controller: _btnController,
        onPressed: () async {
          // on submit close the bottom sheet
          if (!_formKey.currentState!.validate()) {
            return;
          }
          if (_balanceCode == null) {
            Get.snackbar(AppTexts.error.tr, AppTexts.please_enter_balance_code.tr);
            _btnController.reset();
            return;
          } else if (_balanceCode!.length < 12) {
            Get.snackbar(
              AppTexts.error.tr,
              AppTexts.pleaseEnterTwelveDigits.tr,
            );
            _btnController.reset();
            return;
          }

          bool result = await addBalanceCodeApi(code: _balanceCode!, context: context);
          if (!result) {
            Get.snackbar(AppTexts.please_enter_balance_code.tr, '');
            _btnController.reset();
            return;
          } else {
            _btnController.success();
            _balanceCode = null;
            _balanceController.clear();
          }
        },
        child: Text(AppTexts.add_balance.tr,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            )),
      ),
    );
  }
}
