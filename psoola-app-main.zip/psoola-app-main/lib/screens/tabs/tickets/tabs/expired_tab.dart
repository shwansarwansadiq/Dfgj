import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/api/tickets_api.dart';
import 'package:psoola/components/cards/expired_ticket_card.dart';
import 'package:psoola/states/tickets_state.dart';
import 'package:psoola/utils/app_animations.dart';

import '../../../../models/ticket_model.dart';
import '../../../../utils/app_texts.dart';

class ExpiredTickets extends StatefulWidget {
  const ExpiredTickets({Key? key}) : super(key: key);

  @override
  ExpiredTicketsState createState() => ExpiredTicketsState();
}

class ExpiredTicketsState extends State<ExpiredTickets> {
  @override
  void initState() {
    super.initState();

    init();
  }

  String currentLang = Get.locale!.languageCode;
  Future<void> init() async {
    await fetchExpiredTicketsApi();
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              30.height,
              GetBuilder<TicketsState>(builder: (state) {
                List<TicketModel> tickets = state.getExpiredTickets;
                return tickets.isNotEmpty
                    ? ListView.separated(
                        separatorBuilder: (context, index) =>
                            const SizedBox(height: 20),
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: tickets.length,
                        itemBuilder: (context, index) {
                          return ExpiredTicketCard(
                              ticket: tickets[index], currentLang: currentLang);
                        },
                      )
                    : _noExpiredTickets();
              })
            ],
          ),
        ],
      ),
    );
  }

  Center _noExpiredTickets() {
    return Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            AppAnimations.oldTv,
            width: Get.width * 0.7,
          ),
          const SizedBox(height: 20),
          Text(
            AppTexts.noExpiredTickets.tr,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            AppTexts.noExpiredTicketsHaveBeenFound.tr,
            style: const TextStyle(
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
