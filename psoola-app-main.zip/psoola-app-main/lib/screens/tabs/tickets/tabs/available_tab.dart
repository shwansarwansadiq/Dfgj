import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/api/tickets_api.dart';
import 'package:psoola/states/tickets_state.dart';
import 'package:psoola/utils/app_animations.dart';

import '../../../../components/cards/ticket_card.dart';
import '../../../../models/ticket_model.dart';
import '../../../../utils/app_texts.dart';

class AvailableTickets extends StatefulWidget {
  const AvailableTickets({Key? key}) : super(key: key);

  @override
  AvailableTicketsState createState() => AvailableTicketsState();
}

class AvailableTicketsState extends State<AvailableTickets> {
  @override
  void initState() {
    super.initState();

    init();
  }

  String currentLang = Get.locale!.languageCode;
  Future<void> init() async {
    fetchTicketsApi();
    fetchExpiredTicketsApi();
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              30.height,
              GetBuilder<TicketsState>(builder: (state) {
                List<TicketModel> tickets = state.getCustomerTickets;
                return tickets.isNotEmpty
                    ? ListView.separated(
                        separatorBuilder: (context, index) =>
                            const SizedBox(height: 20),
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: tickets.length,
                        itemBuilder: (context, index) {
                          return TicketCard(
                              ticket: tickets[index], currentLang: currentLang);
                        },
                      )
                    : _noTickets();
              })
            ],
          ),
        ],
      ),
    );
  }

  Center _noTickets() {
    return Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            AppAnimations.ticketLottie,
            width: Get.width * 0.7,
          ),
          const SizedBox(height: 20),
          Text(
            AppTexts.noTickets.tr,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            AppTexts.youDontHaveAnyTicketsYet.tr,
            style: const TextStyle(
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
