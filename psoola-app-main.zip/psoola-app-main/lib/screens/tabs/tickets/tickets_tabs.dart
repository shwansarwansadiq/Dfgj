import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/utils/app_animations.dart';

import '../../../auth/auth.dart';
import '../../../controllers/auth_controller.dart';
import '../../../services/font_service.dart';
import '../../../utils/app_texts.dart';
import 'tabs/available_tab.dart';
import 'tabs/expired_tab.dart';

class TicketsTab extends StatefulWidget {
  const TicketsTab({Key? key}) : super(key: key);

  @override
  State<TicketsTab> createState() => _TicketsTabState();
}

class _TicketsTabState extends State<TicketsTab>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    init();
  }

  Future<void> init() async {}

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  AuthState authState = Get.find<AuthState>();

  @override
  Widget build(BuildContext context) {
    return authState.user.value.name != null ||
            authState.user.value.userType == "CHECKER"
        ? Scaffold(
            appBar: AppBar(
              title: Text(AppTexts.myTickets.tr),
            ),
            body: SafeArea(
              child: Column(
                children: [
                  Column(
                    children: [
                      TabBar(
                        controller: _tabController,
                        labelColor: Theme.of(context).primaryColor,
                        indicatorColor: Theme.of(context).primaryColor,
                        indicatorSize: TabBarIndicatorSize.label,
                        unselectedLabelColor: Colors.grey,
                        labelStyle: primaryTextStyle(
                            size: 14,
                            fontFamily: FontFamilyService().fontFamily),
                        tabs: [
                          Tab(
                            text: AppTexts.availableTickets.tr,
                          ),
                          Tab(
                            text: AppTexts.expiredTickets.tr,
                          ),
                        ],
                      ),
                      TabBarView(
                        controller: _tabController,
                        children: const [
                          AvailableTickets(),
                          ExpiredTickets(),
                        ],
                      ).expand(),
                    ],
                  ).expand()
                ],
              ),
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Lottie.asset(
                    AppAnimations.cinemaFront,
                    width: Get.width,
                  ),
                  Text(
                    AppTexts.pleaseLogin.tr,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    AppTexts.loginToSeeYourTickets.tr,
                    style: const TextStyle(
                      fontSize: 16,
                    ),
                  ),
                  16.height,
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Theme.of(context).primaryColor,
                      side: BorderSide(
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                    onPressed: () {
                      Get.to(() => const AuthScreen());
                    },
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(AppTexts.login.tr),
                        const SizedBox(width: 8),
                        const Icon(Icons.arrow_forward),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
  }
}
