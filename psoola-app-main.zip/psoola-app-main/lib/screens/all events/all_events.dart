import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:line_icons/line_icons.dart';
import 'package:lottie/lottie.dart';
import 'package:psoola/api/location/province_api.dart';
import 'package:psoola/models/category_model.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/location/province_model.dart';
import 'package:psoola/states/event_state.dart';
import 'package:psoola/utils/app_animations.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

import '../../../../utils/app_texts.dart';
import '../../api/events_api.dart';
import '../../controllers/event_view_controller.dart';
import 'components/category_formfield.dart';
import 'components/city_formfield.dart';
import 'components/date_formfield.dart';
import 'components/list_and_card.dart';

class AllEvents extends StatefulWidget {
  final CategoryModel? selectedCategory;
  const AllEvents({Key? key, this.selectedCategory}) : super(key: key);

  @override
  State<AllEvents> createState() => _AllEventsState();
}

class _AllEventsState extends State<AllEvents> {
  EventsState eventsState = Get.find<EventsState>();

  String currentLang = Get.locale!.languageCode;
  ProvinceModel? _currentSelectedCity;

  final ScrollController _scrollController = ScrollController();
  CategoryModel? selectedCategory;
  ProvinceModel? selectedCity;
  PickerDateRange? currentselectedDateRange;

  bool loadMore = false;
  bool onSearch = false;

  UpdateView updateView = Get.find();

  @override
  void initState() {
    eventsState.setEvents = [];
    if (widget.selectedCategory != null) {
      selectedCategory = widget.selectedCategory;
    }
    setState(() {
      onSearch = true;
    });

    onFilter().then((value) => setState(() {
          onSearch = false;
        }));
    // Future.delayed(Duration(seconds: 3), () {
    //   setState(() {
    //     onSearch = false;
    //   });
    // });

    _scrollController.addListener(() async {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        setState(() {
          loadMore = true;
        });

        await EventApi().fetchEventFilterApi(
            eventType:
                selectedCategory != null ? selectedCategory!.eventType : null,
            cityId:
                _currentSelectedCity != null ? _currentSelectedCity!.id : null);
        setState(() {
          loadMore = false;
        });
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          centerTitle: true,
          actions: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () {
                  showModalBottomSheet(
                    backgroundColor: Theme.of(context).colorScheme.background,
                    barrierColor: Colors.black12.withOpacity(0.5),
                    shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(30),
                            topRight: Radius.circular(30))),
                    context: context,
                    builder: (context) => StatefulBuilder(
                      builder: (BuildContext context, StateSetter myState) =>
                          filterBottomModal(context, myState),
                    ),
                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                      border:
                          Border.all(color: Theme.of(context).disabledColor),
                      borderRadius: BorderRadius.circular(10)),
                  height: 50,
                  width: 100,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(AppTexts.filter.tr),
                      const SizedBox(width: 5),
                      const Icon(
                        IconlyLight.filter,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ]),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            children: [
              selectedCategory != null
                  ? GestureDetector(
                      onTap: () {
                        setState(() {
                          selectedCategory = null;

                          onFilter();
                        });
                      },
                      child: filterChip(
                        icon: selectedCategory!.icon,
                        text: currentLang == 'en'
                            ? selectedCategory!.title.textEn
                            : currentLang == 'ar'
                                ? selectedCategory!.title.textAr
                                : selectedCategory!.title.textKr,
                      ),
                    )
                  : Container(),
              const Spacer(),
              SizedBox(
                child: Row(
                  children: [
                    const SizedBox(width: 10),
                    ToggleButtons(
                      renderBorder: true,
                      borderWidth: 0.5,
                      borderRadius: BorderRadius.circular(5),
                      constraints: const BoxConstraints(
                        minWidth: 30,
                        minHeight: 30,
                      ),
                      onPressed: (int index) {
                        index == 0
                            ? updateView.isCard = true
                            : updateView.isCard = false;
                        setState(() {
                          updateView.isCard = index == 0 ? true : false;
                        });
                      },
                      isSelected: [
                        updateView.isCard,
                        !updateView.isCard,
                      ],
                      children: const [
                        Icon(
                          LineIcons.square,
                          size: 20,
                        ),
                        Icon(
                          LineIcons.list,
                          size: 20,
                        ),
                      ],
                    ),
                    const SizedBox(width: 5),
                  ],
                ),
              ),
            ],
          ),
          GetBuilder<EventsState>(builder: (state) {
            List<EventModel> events = state.getEvents;

            return events.isEmpty && onSearch == false
                ? Expanded(
                    child: Column(
                      children: [
                        const Spacer(),
                        SizedBox(
                          width: Get.width * 0.3,
                          child: Lottie.asset(
                            AppAnimations.loading,
                            animate: true,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Text(AppTexts.notifications.tr),
                        const Spacer()
                      ],
                    ),
                  )
                : events.isEmpty && onSearch == true
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                            Lottie.asset(
                              AppAnimations.loading,
                              height: 100,
                              animate: true,
                            )
                          ])
                    : ListAndCard(
                        updateView: updateView,
                        scrollController: _scrollController,
                        events: events,
                        loadMore: loadMore,
                        eventsState: eventsState);
          }),
          loadMore
              ? Lottie.asset(
                  AppAnimations.loading,
                  height: 100,
                  animate: true,
                )
              : Container()
        ],
      ),
    );
  }

  dateFormField() {
    return DateFormfield(
      currentselectedDate: currentselectedDateRange,
      onFilter: ({required datetimeRange}) {
        currentselectedDateRange = datetimeRange;
        onFilter();
      },
    );
  }

  filterBottomModal(context, StateSetter myState) {
    fetchProvincesApi();
    return Wrap(
      children: [
        Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(children: [
            _buildCategoriesFromField(myState),
            const SizedBox(
              height: 20,
            ),
            _buildCityFromField(myState),
            const SizedBox(
              height: 20,
            ),
            dateFormField()
          ]),
        ),
      ],
    );
  }

  filterChip({required String text, String? icon}) {
    return FadeIn(
      child: Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        height: 40,
        decoration: BoxDecoration(
          color: Theme.of(context).primaryColor.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          icon != null
              ? Container(
                  margin: const EdgeInsets.only(right: 8),
                  child: SvgPicture.asset(
                    icon,
                    width: 20,
                    height: 20,
                    color: Theme.of(context).iconTheme.color,
                  ),
                )
              : Container(),
          const SizedBox(width: 5),
          Text(text),
          const Icon(Icons.close),
          const SizedBox(
            width: 5,
          )
        ]),
      ),
    );
  }

  _buildCategoriesFromField(myState) {
    return CategoryFormfield(
      currentselectedCategory: selectedCategory,
      onFilter: ({required CategoryModel category}) {
        selectedCategory = category;
        onFilter();
      },
    );
  }

  _buildCityFromField(myState) {
    return CityFormfield(
      currentselectedCity: _currentSelectedCity,
      onFilter: ({required ProvinceModel city}) {
        _currentSelectedCity = city;
        onFilter();
      },
    );
  }

  Future<bool> onFilter() async {
    eventsState.setLastDocument = null;
    bool resutl = await EventApi().fetchEventFilterApi(
        currentselectedDateRange: currentselectedDateRange,
        eventType:
            selectedCategory != null ? selectedCategory!.eventType : null,
        cityId: _currentSelectedCity != null ? _currentSelectedCity!.id : null);
    return resutl;
  }
}
