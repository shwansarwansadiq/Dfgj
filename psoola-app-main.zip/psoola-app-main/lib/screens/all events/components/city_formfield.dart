// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/models/location/province_model.dart';
import '../../../models/category_model.dart';
import '../../../states/location/province_state.dart';
import '../../../utils/app_texts.dart';

class CityFormfield extends StatelessWidget {
  final Function({required ProvinceModel city}) onFilter;
  ProvinceModel? currentselectedCity;
  CityFormfield({
    Key? key,
    required this.onFilter,
    required this.currentselectedCity,
  }) : super(key: key);
  String currentLang = Get.locale!.languageCode;
  List<CategoryModel> categories = categoriesList();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProvinceState>(
        builder: (_) => DropdownButtonFormField<String>(
              menuMaxHeight: Get.height * 0.5,
              validator: (value) {
                if (value == null) {
                  return AppTexts.pleaseSelectCity.tr;
                }
                return null;
              },
              hint: Text(
                AppTexts.selectCity.tr,
                style: TextStyle(color: Theme.of(context).iconTheme.color),
              ),
              value:
                  currentselectedCity != null ? currentselectedCity!.id : null,
              isDense: true,
              onChanged: (String? newValue) {
                ProvinceModel provinceModel = _.getProvinces
                    .firstWhere((element) => element.id == newValue);
                onFilter(city: provinceModel);
              },
              items: _.getProvinces.map((value) {
                return DropdownMenuItem<String>(
                  value: value.id,
                  child: Text(currentLang == 'en'
                      ? value.name.textEn
                      : currentLang == 'ar'
                          ? value.name.textAr
                          : value.name.textKr),
                );
              }).toList(),
            ));
  }
}
