// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../../../models/category_model.dart';
import '../../../utils/app_texts.dart';

class CategoryFormfield extends StatelessWidget {
  final Function({required CategoryModel category}) onFilter;
  CategoryModel? currentselectedCategory;
  CategoryFormfield({
    Key? key,
    required this.onFilter,
    required this.currentselectedCategory,
  }) : super(key: key);
  String currentLang = Get.locale!.languageCode;
  List<CategoryModel> categories = categoriesList();

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      menuMaxHeight: Get.height * 0.5,
      validator: (value) {
        if (value == null) {
          return 'please_select_category'.tr;
        }
        return null;
      },
      hint: Text(AppTexts.categories.tr),
      value:
          currentselectedCategory != null ? currentselectedCategory!.id : null,
      isDense: true,
      onChanged: (String? newValue) {
        CategoryModel selectedCategory =
            categories.firstWhere((element) => element.id == newValue);

        onFilter(category: selectedCategory);
      },
      items: categories.map((value) {
        return DropdownMenuItem<String>(
          value: value.id,
          child: Row(
            children: [
              SvgPicture.asset(
                value.icon,
                height: 20,
                color: Theme.of(context).iconTheme.color,
              ),
              const SizedBox(
                width: 5,
              ),
              Text(currentLang == 'en'
                  ? value.title.textEn
                  : currentLang == 'ar'
                      ? value.title.textAr
                      : value.title.textKr),
            ],
          ),
        );
      }).toList(),
    );
  }
}
