// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

import '../../../models/category_model.dart';

class DateFormfield extends StatelessWidget {
  final Function({required PickerDateRange datetimeRange}) onFilter;
  PickerDateRange? currentselectedDate;

  DateFormfield({
    Key? key,
    required this.onFilter,
    required this.currentselectedDate,
  }) : super(key: key);
  String currentLang = Get.locale!.languageCode;
  List<CategoryModel> categories = categoriesList();

  @override
  Widget build(BuildContext context) {
    return SfDateRangePicker(
      view: DateRangePickerView.month,
      selectionMode: DateRangePickerSelectionMode.range,
      onSelectionChanged: (DateRangePickerSelectionChangedArgs args) {
        onFilter(datetimeRange: args.value);
      },
      monthViewSettings:
          const DateRangePickerMonthViewSettings(firstDayOfWeek: 1),
    );
  }
}
