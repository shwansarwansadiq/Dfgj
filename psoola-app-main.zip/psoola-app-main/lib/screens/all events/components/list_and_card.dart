// ignore_for_file: must_be_immutable

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/screens/event_details/event_details.dart';
import 'package:psoola/utils/app_defaults.dart';

import '../../../components/cards/event_horizontal_card.dart';
import '../../../controllers/event_view_controller.dart';
import '../../../models/event_model.dart';
import '../../../models/event_type_model.dart';
import '../../../states/event_state.dart';
import '../../../utils/app_constants.dart';

class ListAndCard extends StatelessWidget {
  ListAndCard({
    Key? key,
    required this.updateView,
    required ScrollController scrollController,
    required this.events,
    required this.loadMore,
    required this.eventsState,
  })  : _scrollController = scrollController,
        super(key: key);

  final UpdateView updateView;
  final ScrollController _scrollController;
  final List<EventModel> events;
  final bool loadMore;
  final EventsState eventsState;

  String currentLang = Get.locale!.languageCode;

  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: !updateView.isCard
            ? AnimationLimiter(
                child: ListView.builder(
                  physics: const ClampingScrollPhysics(),
                  controller: _scrollController,
                  itemCount: events.length,
                  itemBuilder: (BuildContext context, int index) {
                    return AnimationConfiguration.staggeredList(
                        position: index,
                        delay: const Duration(milliseconds: 100),
                        child: SlideAnimation(
                          duration: const Duration(milliseconds: 2500),
                          curve: Curves.fastLinearToSlowEaseIn,
                          child: FadeInAnimation(
                              curve: Curves.fastLinearToSlowEaseIn,
                              duration: const Duration(milliseconds: 2500),
                              child: EventCardHorizontal(
                                event: eventsState.getEvents[index],
                              )),
                        ));
                  },
                ),
              )
            : GridView.builder(
                physics: const ClampingScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 0.8,
                ),
                itemCount: eventsState.getEvents.length,
                itemBuilder: (BuildContext context, int index) {
                  return AnimationConfiguration.staggeredList(
                    position: index,
                    delay: const Duration(milliseconds: 100),
                    child: SlideAnimation(
                      duration: const Duration(milliseconds: 2500),
                      curve: Curves.fastLinearToSlowEaseIn,
                      child: FadeInAnimation(
                          curve: Curves.fastLinearToSlowEaseIn,
                          duration: const Duration(milliseconds: 2500),
                          child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: GestureDetector(
                                onTap: () {
                                  Get.to(() => EventDetails(
                                        eventModel: events[index],
                                      ));
                                },
                                child: Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            AppDefaults.radius),
                                        color: Colors.white,
                                        image: DecorationImage(
                                          image: NetworkImage(eventsState
                                              .getEvents[index].show.poster),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(
                                            AppDefaults.radius),
                                        gradient: LinearGradient(

                                            // Where the linear gradient begins and ends
                                            begin: Alignment.topCenter,
                                            end: Alignment.bottomCenter,
                                            // Add one stop for each color. Stops should increase from 0 to 1
                                            stops: const [
                                              0.1,
                                              0.5,
                                              0.7,
                                              0.9
                                            ],
                                            colors: [
                                              Colors.black.withOpacity(0.0),
                                              Colors.black.withOpacity(0.1),
                                              Colors.black.withOpacity(0.3),
                                              Colors.black.withOpacity(0.6),
                                            ]),
                                      ),
                                    ),
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text(
                                            currentLang == "en"
                                                ? eventsState.getEvents[index]
                                                    .show.title.textEn
                                                : currentLang == 'ar'
                                                    ? eventsState
                                                        .getEvents[index]
                                                        .show
                                                        .title
                                                        .textAr
                                                    : eventsState
                                                        .getEvents[index]
                                                        .show
                                                        .title
                                                        .textKr,
                                            textAlign: TextAlign.center,
                                            style: const TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        events[index].show.type ==
                                                EventType.MOVIE
                                            ? Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  const Icon(
                                                    IconlyBold.star,
                                                    color: Colors.amber,
                                                    size: 15,
                                                  ),
                                                  4.width,
                                                  SizedBox(
                                                    child: AutoSizeText(
                                                      events[index]
                                                          .totalReview
                                                          .averageRating
                                                          .toDouble()
                                                          .toString(),
                                                      maxFontSize: 12,
                                                      minFontSize: 10,
                                                      maxLines: 1,
                                                      style: const TextStyle(
                                                        color: Colors.white,
                                                      ),
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    child: AutoSizeText(
                                                      ' (${events[index].totalReview.totalReview} ${"reviews".tr})',
                                                      maxFontSize: 12,
                                                      minFontSize: 10,
                                                      maxLines: 1,
                                                      style: const TextStyle(
                                                        color: Colors.white,
                                                      ),
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                ],
                                              )
                                            : SizedBox(
                                                width: Get.width * 0.8,
                                                child: AutoSizeMultiLangText(
                                                  text: events[index]
                                                      .provinces[0]
                                                      .name,
                                                  style: const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 16,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                  ),
                                                ),
                                              ),
                                        const SizedBox(
                                            height:
                                                AppConstants.kDefaultPadding),
                                      ],
                                    ),
                                  ],
                                ),
                              ))),
                    ),
                  );
                },
              ));
  }
}
