import 'package:bluelab_dialog/panara_dialogs.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:psoola/customer/customer_nav.dart';
import 'package:psoola/utils/app_animations.dart';

import '../../services/notification_services.dart';
import '../../utils/app_texts.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({Key? key}) : super(key: key);

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  List<NotificationModel> notificationList =
      getSavedNotifications() as List<NotificationModel>;
  String currentLang = Get.locale!.languageCode;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: Text(
            "notifications".tr,
            style: TextStyle(color: Theme.of(context).iconTheme.color),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap: () {
                  PanaraConfirmDialog.show(
                    context,
                    imagePath: "assets/animations/alert (1).json",
                    title: "clear_notifications".tr,
                    message: "clear_notifications_message".tr,
                    confirmButtonText: "delete".tr,
                    cancelButtonText: AppTexts.cancel.tr,
                    onTapCancel: () {
                      Get.back();
                    },
                    onTapConfirm: () {
                      deleteAllNotifications();
                      Get.back();
                    },
                    panaraDialogType: PanaraDialogType.normal,
                    barrierDismissible: true,
                  );
                },
                child: Row(
                  children: [
                    // const Icon(
                    //   IconlyLight.delete,
                    //   size: 20,
                    // ),
                    // 4.width,
                    Text(
                      AppTexts.deleteAll.tr,
                      style: TextStyle(
                          color: Theme.of(context).colorScheme.error, fontSize: 12),
                    )
                  ],
                ),
              ),
            ),
          ]),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 20,
            ),
            notificationList.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Lottie.asset(
                          AppAnimations.megaphone,
                          width: Get.width * 0.8,
                        ),
                        Center(
                          child: Text(AppTexts.noNotifications.tr),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: notificationList.length,
                    itemBuilder: (context, index) {
                      return AnimationConfiguration.staggeredList(
                        position: index,
                        duration: const Duration(milliseconds: 375),
                        child: SlideAnimation(
                          verticalOffset: 50.0,
                          child: FadeInAnimation(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 10),
                              child: ListTile(
                                leading: Container(
                                  height: 50,
                                  width: 50,
                                  decoration: BoxDecoration(
                                      color: Theme.of(context).primaryColor,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.network(
                                      notificationList[index].image!,
                                      height: 50,
                                      width: 50,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                title: Text(
                                  notificationList[index].title,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                                subtitle: Text(
                                  notificationList[index].description,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                trailing: GestureDetector(
                                    onTap: () {
                                      deleteSingleNotification(index);
                                      Get.to(() => const CustomerNav());
                                    },
                                    child: const Icon(IconlyLight.delete)),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }
}
