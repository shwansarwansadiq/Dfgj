import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../check_user.dart';
import '../../models/onboarding_model.dart';
import '../../utils/data_provider.dart';

class CheckWalkThrough extends StatelessWidget {
  CheckWalkThrough({super.key});
  final GetStorage box = GetStorage();
  checkSeenWalkThrough() async {
    bool? seenOnBoarding = box.read('seenOnBoarding');
    return seenOnBoarding;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: checkSeenWalkThrough(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const CircularProgressIndicator();
          } else {
            bool? result = snapshot.data as bool?;
            if (result != null && result) {
              return CheckUser();
            } else {
              return const WalkThroughScreen();
            }
          }
        });
  }
}

class WalkThroughScreen extends StatefulWidget {
  const WalkThroughScreen({Key? key}) : super(key: key);

  @override
  State<WalkThroughScreen> createState() => _WalkThroughScreenState();
}

class _WalkThroughScreenState extends State<WalkThroughScreen> {
  PageController controller = PageController();
  final GetStorage box = GetStorage();
  List<WalkThroughData> list = WalkThroughDataList();

  updateIsSeen() async {
    await box.write('seenOnBoarding', true);
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    updateIsSeen();
    init();
  }

  Future<void> init() async {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView(
            physics: const BouncingScrollPhysics(),
            controller: controller,
            children: list.map(
              (e) {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(
                      e.imagePath,
                      width: Get.width * 0.7,
                      height: Get.height * 0.4,
                    ),
                    48.height,
                    Text(e.title.tr,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontSize: 24, fontWeight: FontWeight.bold)),
                    16.height,
                    Text(e.subtitle.tr,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 16)),
                  ],
                ).paddingAll(16.0);
              },
            ).toList(),
          ),
          Positioned(
            bottom: 30,
            left: 16,
            right: 16,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                DotIndicator(
                    indicatorColor: Theme.of(context).primaryColor,
                    pageController: controller,
                    pages: list),
                AppButton(
                  elevation: 0,
                  onTap: () {
                    SharedPreferences.getInstance().then(
                        (value) => {value.setBool('seenOnBoarding', true)});
                    Get.offAll(() => CheckUser());
                  },
                  color: Theme.of(context).primaryColor,
                  child: Text(
                    AppTexts.getStarted.tr,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: 40,
            right: 16,
            child: Text(AppTexts.skip.tr,
                style: const TextStyle(
                  fontSize: 16,
                )).paddingOnly(top: 8, right: 8).onTap(() {
              controller.jumpToPage(2);
            }),
          ),
        ],
      ),
    );
  }
}
