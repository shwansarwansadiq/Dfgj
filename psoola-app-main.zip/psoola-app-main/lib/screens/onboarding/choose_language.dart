import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:lottie/lottie.dart';
import 'package:psoola/utils/app_animations.dart';
import 'package:psoola/utils/app_image.dart';
import '../../utils/app_function.dart';
import '../../utils/app_texts.dart';
import 'walkthrough_screen.dart';

class ChooseLanguage extends StatefulWidget {
  const ChooseLanguage({Key? key}) : super(key: key);

  @override
  State<ChooseLanguage> createState() => ChooseLanguageState();
}

class ChooseLanguageState extends State<ChooseLanguage> {
  Locale? selectedLocal;
  final GetStorage box = GetStorage();
  updateLocale(Locale locale, BuildContext context) async {
    AppFunction.changeLanguage(locale);

    await box.write('isLangSelected', true);
    setState(() {});
    Get.offAll(() => const WalkThroughScreen());
  }

  @override
  Widget build(BuildContext context) {
    box.write('seen', true);

    return Scaffold(
        backgroundColor: Theme.of(context).primaryColor,
        body: Stack(
          children: <Widget>[
            Align(
              alignment: Alignment.topCenter,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(.1),
                          offset: const Offset(0, 10),
                          blurRadius: 30,
                        ),
                      ],
                      color: Theme.of(context).scaffoldBackgroundColor,
                      borderRadius: const BorderRadius.only(
                        bottomLeft: Radius.circular(50),
                        bottomRight: Radius.circular(50),
                      ),
                    ),
                    child: Container(
                      height: Get.height,
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(top: 50),
                            child: SizedBox(
                              child: Center(
                                child: Column(
                                  children: [
                                    Lottie.asset(
                                      AppAnimations.language,
                                      height: 140,
                                      animate: false,
                                      width: 140,
                                      fit: BoxFit.cover,
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Text(
                                      AppTexts.welcomeToPsoola.tr,
                                      style: const TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Center(
                            child: Text(
                              'select_your_language'.tr,
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.normal,
                              ),
                            ),
                          ),
                          const Expanded(
                            child: SizedBox(),
                          ),
                          SizedBox(
                              height: 60,
                              child: selectLangButton(
                                  imageAsset: AppImage.pngKurdishFlag,
                                  locale: const Locale('fa', 'IR'),
                                  text: 'کوردی')),
                          const SizedBox(height: 20),
                          SizedBox(
                            height: 60,
                            child: selectLangButton(
                                imageAsset: AppImage.pngIraqFlag,
                                locale: const Locale('ar', 'IQ'),
                                text: 'العربیة'),
                          ),
                          const SizedBox(height: 20),
                          // Locale('en', 'US')
                          SizedBox(
                            height: 60,
                            child: selectLangButton(
                                imageAsset: AppImage.pngBritishFlag,
                                locale: const Locale('en', 'US'),
                                text: 'English'),
                          ),
                          const Expanded(child: SizedBox()),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ));
  }

  selectLangButton(
      {required Locale locale,
      required String text,
      required String imageAsset}) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
          backgroundColor: selectedLocal != null && selectedLocal == locale
              ? Theme.of(context).primaryColor.withOpacity(0.3)
              : Colors.transparent),
      onPressed: () {
        selectedLocal = locale;
        updateLocale(locale, context);
      },
      child: Row(mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
        CircleAvatar(
          radius: 20,
          backgroundColor: Colors.white,
          backgroundImage: AssetImage(imageAsset),
        ),
        const SizedBox(
          width: 10,
        ),
        Text(text,
            style: const TextStyle(
              fontSize: 20,
            )),
      ]),
    );
  }
}
