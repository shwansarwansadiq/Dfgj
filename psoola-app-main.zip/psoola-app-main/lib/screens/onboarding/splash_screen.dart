import 'dart:async';

import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:psoola/components/developed_by.dart';
import 'package:psoola/utils/app_image.dart';

import 'choose_language.dart';
import 'walkthrough_screen.dart';

class Splash extends StatefulWidget {
  const Splash({Key? key}) : super(key: key);

  @override
  SplashState createState() => SplashState();
}

class SplashState extends State<Splash> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: MyCustomSplashScreen(),
    );
  }
}

class MyCustomSplashScreen extends StatefulWidget {
  const MyCustomSplashScreen({Key? key}) : super(key: key);

  @override
  State<MyCustomSplashScreen> createState() => _MyCustomSplashScreenState();
}

class _MyCustomSplashScreenState extends State<MyCustomSplashScreen>
    with TickerProviderStateMixin {
  @override
  void initState() {
    Timer(const Duration(seconds: 3), () {
      checkFirstSeen(context);
    });
    super.initState();
  }

  Future checkFirstSeen(BuildContext context) async {
    final GetStorage box = GetStorage();
    bool? isLangSelected = box.read('isLangSelected');
    if (isLangSelected != null && isLangSelected) {
      Get.off(() => CheckWalkThrough());
    } else {
      if (!mounted) return;
      Get.off(() => const ChooseLanguage());
    }
  }

  @override
  void dispose() {
    // _controller.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // _controller.forward();

    return Scaffold(
      body: Stack(
        children: [
          Center(
            child: ZoomIn(
              duration: const Duration(milliseconds: 2000),
              child: SizedBox(
                height: Get.width * 0.5,
                width: Get.width * 0.5,
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    SizedBox(
                        height: Get.width * 0.5,
                        width: Get.width * 0.5,
                        child: Image.asset(AppImage.logo)),
                    // Positioned(
                    //   bottom: -40,
                    //   right: 0,
                    //   left: 0,
                    //   child: FadeOutDown(
                    //     delay: const Duration(milliseconds: 1000),
                    //     duration: const Duration(milliseconds: 2000),
                    //     child: Container(
                    //       alignment: Alignment.center,
                    //       height: Get.width * 0.2,
                    //       width: Get.width * 0.2,
                    //       child: const Text(
                    //         'v1.0',
                    //         style: TextStyle(
                    //             fontWeight: FontWeight.bold, fontSize: 22),
                    //       ),
                    //     ),
                    //   ),
                    // )
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            left: 0,
            right: 0,
            child: Column(
              children: [
                FadeInUp(
                    duration: const Duration(milliseconds: 2000),
                    child: const DevelopedBy()),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
