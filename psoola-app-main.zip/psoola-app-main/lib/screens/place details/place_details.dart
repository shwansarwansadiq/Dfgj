import 'package:flutter/material.dart';
import 'package:psoola/screens/place%20details/pages/cinema_details.dart';
import 'package:psoola/screens/place%20details/pages/other_place_details.dart';

import '../../models/event_model.dart';
import '../../models/event_type_model.dart';

class PlaceDetails extends StatefulWidget {
  final EventModel eventModel;
  const PlaceDetails({super.key, required this.eventModel});

  @override
  State<PlaceDetails> createState() => _PlaceDetailsState();
}

class _PlaceDetailsState extends State<PlaceDetails>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    init();
  }

  Future<void> init() async {}

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // switch (widget.eventModel.show.type) {
    //   case EventType.MOVIE:
    //     return CinemaDetails(
    //       eventModel: widget.eventModel,
    //     );
    //   case EventType.THEATER:
    //     return EventTheatreDetails(eventModel: widget.eventModel);
    //   case EventType.CONCERT:
    //     return CinemaDetails(eventModel: widget.eventModel);
    //   default:
    //     return CinemaDetails(
    //       eventModel: widget.eventModel,
    //     );
    // }
    return widget.eventModel.show.type == EventType.MOVIE
        ? CinemaDetails(
            eventModel: widget.eventModel,
          )
        : OtherPlaceDetails(eventModel: widget.eventModel);
  }
}
