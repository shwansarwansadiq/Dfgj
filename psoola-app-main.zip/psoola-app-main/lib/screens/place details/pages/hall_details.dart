import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/models/event_model.dart';

class HallDetails extends StatefulWidget {
  final EventModel eventModel;
  const HallDetails({super.key, required this.eventModel});

  @override
  State<HallDetails> createState() => _HallDetailsState();
}

class _HallDetailsState extends State<HallDetails> {
  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {}

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    super.dispose();
  }

  String currentLang = Get.locale!.languageCode;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        children: [
          Stack(children: [
            Image(image: NetworkImage(widget.eventModel.places[0].cover!)),
            Positioned(
              top: 40,
              left: currentLang == 'en' ? 20 : null,
              right: currentLang == 'ar' || currentLang == 'fa' ? 20 : null,
              child: IconButton(
                onPressed: () => Get.back(),
                icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
              ),
            ),
          ]),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 120,
                      width: 120,
                      decoration: BoxDecoration(
                          color: Colors.black,
                          image: DecorationImage(
                              image: NetworkImage(
                                widget.eventModel.places[0].logo,
                              ),
                              fit: BoxFit.cover),
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    const SizedBox(width: 20),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          currentLang == 'en'
                              ? widget.eventModel.places[0].title.textEn
                              : currentLang == 'ar'
                                  ? widget.eventModel.places[0].title.textAr
                                  : widget.eventModel.places[0].title.textKr,
                          style: const TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Icon(
                              Icons.location_on,
                              color: Colors.red,
                              size: 20,
                            ),
                            const SizedBox(width: 5),
                            Text(
                              currentLang == 'en'
                                  ? "${widget.eventModel.places[0].location.province.name.textEn} - ${widget.eventModel.places[0].location.district.name.textEn}"
                                  : currentLang == 'ar'
                                      ? "${widget.eventModel.places[0].location.province.name.textAr} - ${widget.eventModel.places[0].location.district.name.textAr}"
                                      : "${widget.eventModel.places[0].location.province.name.textKr} - ${widget.eventModel.places[0].location.district.name.textKr}",
                              style: const TextStyle(
                                fontSize: 15,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                MultiLangText(
                  text: widget.eventModel.places[0].title,
                  style: const TextStyle(
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 20),
                _mapWidget(),
              ],
            ),
          ),
        ],
      ),
    ));
  }

  ClipRRect _mapWidget() {
    return ClipRRect(
      borderRadius: const BorderRadius.all(
        Radius.circular(20),
      ),
      child: SizedBox(
        height: 300,
        width: double.infinity,
        child: GoogleMap(
          initialCameraPosition: CameraPosition(
            target: LatLng(widget.eventModel.places[0].geoPoint.latitude,
                widget.eventModel.places[0].geoPoint.longitude),
            zoom: 15,
          ),
          markers: {
            Marker(
              markerId: const MarkerId('1'),
              position: LatLng(widget.eventModel.places[0].geoPoint.latitude,
                  widget.eventModel.places[0].geoPoint.longitude),
            ),
          },
        ),
      ),
    );
  }
}
