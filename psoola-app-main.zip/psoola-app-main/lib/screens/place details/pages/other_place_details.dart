import 'package:draggable_home/draggable_home.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart' as lottie;
import 'package:psoola/api/places_api.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/screens/event_details/event_details.dart';
import 'package:psoola/screens/place%20location/place_location.dart';
import 'package:psoola/utils/app_animations.dart';
import 'package:psoola/utils/app_defaults.dart';
import 'package:psoola/utils/app_texts.dart';

class OtherPlaceDetails extends StatefulWidget {
  final EventModel eventModel;
  const OtherPlaceDetails({super.key, required this.eventModel});

  @override
  State<OtherPlaceDetails> createState() => _OtherPlaceDetailsState();
}

class _OtherPlaceDetailsState extends State<OtherPlaceDetails> {
  @override
  void initState() {
    super.initState();
    init();
  }

  Future<void> init() async {}

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    super.dispose();
  }

  String currentLang = Get.locale!.languageCode;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: DraggableHome(
            alwaysShowLeadingAndAction: true,
            curvedBodyRadius: 0,
            leading: IconButton(
              icon: const Icon(
                Icons.arrow_back,
              ),
              onPressed: () {
                Get.back();
              },
            ),
            actions: [
              GestureDetector(
                onTap: () {
                  Get.to(() => PlaceLocation(
                        eventModel: widget.eventModel,
                      ));
                },
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Text(AppTexts.map.tr,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                      )),
                ),
              )
            ],
            title: Text(
              currentLang == 'en'
                  ? widget.eventModel.places[0].title.textEn
                  : currentLang == 'ar'
                      ? widget.eventModel.places[0].title.textAr
                      : widget.eventModel.places[0].title.textKr,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.normal,
              ),
            ),
            headerWidget: Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                  color: Colors.black,
                  image: DecorationImage(
                      image: NetworkImage(
                        widget.eventModel.places[0].cover!,
                      ),
                      fit: BoxFit.cover),
                  borderRadius: BorderRadius.circular(10)),
            ),
            body: [
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              height: 120,
                              width: 120,
                              decoration: BoxDecoration(
                                  color: Colors.black,
                                  image: DecorationImage(
                                      image: NetworkImage(
                                        widget.eventModel.places[0].logo,
                                      ),
                                      fit: BoxFit.cover),
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                            const SizedBox(width: 20),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  currentLang == 'en'
                                      ? widget.eventModel.places[0].title.textEn
                                      : currentLang == 'ar'
                                          ? widget
                                              .eventModel.places[0].title.textAr
                                          : widget.eventModel.places[0].title
                                              .textKr,
                                  style: const TextStyle(
                                    fontSize: 25,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Row(
                                  children: [
                                    const Icon(
                                      Icons.location_on,
                                      color: Colors.red,
                                      size: 20,
                                    ),
                                    const SizedBox(width: 5),
                                    Text(
                                      currentLang == 'en'
                                          ? "${widget.eventModel.places[0].location.province.name.textEn} - ${widget.eventModel.places[0].location.district.name.textEn}"
                                          : currentLang == 'ar'
                                              ? "${widget.eventModel.places[0].location.province.name.textAr} - ${widget.eventModel.places[0].location.district.name.textAr}"
                                              : "${widget.eventModel.places[0].location.province.name.textKr} - ${widget.eventModel.places[0].location.district.name.textKr}",
                                      style: const TextStyle(
                                        fontSize: 15,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        // ReadMoreText(
                        //   currentLang == 'en'
                        //       ? widget.eventModel.places[0].description.textEn
                        //       : currentLang == 'ar'
                        //           ? widget
                        //               .eventModel.places[0].description.textAr
                        //           : widget
                        //               .eventModel.places[0].description.textKr,
                        //   trimLines: 3,
                        //   colorClickableText: Theme.of(context).primaryColor,
                        //   trimMode: TrimMode.Line,
                        //   trimCollapsedText: AppTexts.showMore.tr,
                        //   trimExpandedText: AppTexts.showLess.tr,
                        //   moreStyle: const TextStyle(
                        //     fontSize: 15,
                        //   ),
                        // ),
                        const SizedBox(height: 20),
                        _eventsSection(),
                        const SizedBox(height: 20),
                        // _mapWidget(),
                      ],
                    ),
                  ),
                ],
              ),
            ]));
  }

  Column _eventsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        FutureBuilder(
          future: fetchPlaceEventsApi(widget.eventModel.places[0].id),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                      '${AppTexts.availableEvents.tr} (${snapshot.data!.length})',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      )),
                  ListView.builder(
                      shrinkWrap: true,
                      itemCount: snapshot.data!.length,
                      clipBehavior: Clip.none,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            Get.to(() => EventDetails(
                                  eventModel: snapshot.data![index],
                                ));
                          },
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                height: 150,
                                width: Get.height,
                                decoration: BoxDecoration(
                                    color: Colors.black,
                                    image: DecorationImage(
                                        image: NetworkImage(
                                          snapshot.data![index].show.poster,
                                        ),
                                        fit: BoxFit.cover),
                                    borderRadius: BorderRadius.circular(
                                        AppDefaults.radius)),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                currentLang == 'en'
                                    ? snapshot.data![index].show.title.textEn
                                    : currentLang == 'ar'
                                        ? snapshot
                                            .data![index].show.title.textAr
                                        : snapshot
                                            .data![index].show.title.textKr,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 25),
                            ],
                          ),
                        );
                      }),
                ],
              );
            } else {
              return Center(
                child: Column(
                  children: [
                    lottie.Lottie.asset(
                      AppAnimations.loading,
                      height: 100,
                      width: 100,
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      "No Events",
                      style: TextStyle(
                        fontSize: 15,
                      ),
                    ),
                  ],
                ),
              );
            }
          },
        ),
      ],
    );
  }

  // ClipRRect _mapWidget() {
  //   return ClipRRect(
  //     borderRadius: const BorderRadius.all(
  //       Radius.circular(20),
  //     ),
  //     child: SizedBox(
  //       height: 300,
  //       width: double.infinity,
  //       child: GoogleMap(
  //         initialCameraPosition: CameraPosition(
  //           target: LatLng(widget.eventModel.places![0].geoPoint.latitude,
  //               widget.eventModel.places![0].geoPoint.longitude),
  //           zoom: 15,
  //         ),
  //         markers: {
  //           Marker(
  //             markerId: const MarkerId('1'),
  //             position: LatLng(widget.eventModel.places![0].geoPoint.latitude,
  //                 widget.eventModel.places![0].geoPoint.longitude),
  //           ),
  //         },
  //       ),
  //     ),
  //   );
  // }
}
