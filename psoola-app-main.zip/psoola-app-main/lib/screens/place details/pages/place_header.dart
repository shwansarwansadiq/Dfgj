import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../models/event_model.dart';
import '../../../utils/app_defaults.dart';

class PlaceHeader extends StatelessWidget {
  final EventModel eventModel;
  PlaceHeader({Key? key, required this.eventModel}) : super(key: key);

  final String currentLang = Get.locale!.languageCode;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: Get.height * 0.4,
      width: Get.width,
      child: Stack(
          clipBehavior: Clip.none,
          alignment: AlignmentDirectional
              .bottomCenter, // Aligns the children to the bottom

          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.black,
                image: DecorationImage(
                    image: NetworkImage(
                      eventModel.places[0].cover!,
                    ),
                    fit: BoxFit.cover),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.7),
                  ],
                ),
              ),
            ),
            Positioned(
              bottom: -120,
              left: 50,
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      height: 200,
                      width: 150,
                      decoration: BoxDecoration(
                          color: Colors.black,
                          image: DecorationImage(
                              image: NetworkImage(
                                eventModel.places[0].logo,
                              ),
                              fit: BoxFit.cover),
                          borderRadius:
                              BorderRadius.circular(AppDefaults.radius)),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    SizedBox(
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        // Aligns the children to the bottom
                        children: [
                          Text(
                            eventModel.places[0].title.textAr,
                            style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 22),
                          ),
                          Text(
                              eventModel
                                  .places[0].location.province.name.textAr,
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.normal,
                                  fontSize: 16)),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Positioned(
              top: 30,
              right: 10,
              child: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(100)),
                child: IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: const Icon(
                    Icons.arrow_back,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              ),
            )
          ]),
    );
  }
}
