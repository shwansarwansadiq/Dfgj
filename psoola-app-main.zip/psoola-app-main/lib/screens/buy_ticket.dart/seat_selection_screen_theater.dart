// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/states/ticket_state.dart';
import '../../components/seat/model/seat_model.dart';
import '../../models/event_type_model.dart';
import 'components/seat_section/seat_section.dart';
import 'components/seat_type_widget.dart';
import 'purchase_button.dart';
import 'seat_picker_appbar.dart';

class SeatSelectionTheater extends StatelessWidget {
  final EventModel event;
  Set<SeatNumber> selectedSeats = {};
  int seatNumber = 0;
  TicketState ticketState = Get.find<TicketState>();

  SeatSelectionTheater({Key? key, required this.event}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: SeatPickerAppbar(event: event),
      ),
      body: SafeArea(
          child: Stack(children: [
        Positioned(
          bottom: 0,
          child: PurchaseButton(),
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            const Expanded(flex: 1, child: SizedBox()),
            Container(
              width: Get.width,
              padding: const EdgeInsets.symmetric(horizontal: 50),
              child: event.show.type == EventType.CONCERT
                  ? const SizedBox()
                  : Image.asset(
                      'assets/images/screen.png',
                    ),
            ),
            SeatSection(
              event: event,
              placeId: ticketState.selectedPlace!.id,
              onSeatSelected: ({required Set<SeatNumber> seats}) {
                seatNumber = seats.length;
              },
            ),
            const Divider(
              thickness: 1,
            ),
            SeatTypeWidget(eventType: event.show.type),
            const Expanded(flex: 2, child: SizedBox()),
          ],
        ),
      ])),
    );
  }
}
