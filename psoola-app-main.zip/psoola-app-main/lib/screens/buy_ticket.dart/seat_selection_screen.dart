import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/screens/buy_ticket.dart/seat_selection_screen_live_music.dart';
import 'package:psoola/screens/buy_ticket.dart/seat_selection_screen_cinema.dart';
import 'package:psoola/screens/buy_ticket.dart/seat_selection_screen_theater.dart';
import 'package:psoola/states/ticket_state.dart';

import '../../models/event_type_model.dart';

class BuyTicket extends StatelessWidget {
  final EventModel event;

  BuyTicket({Key? key, required this.event}) : super(key: key);

  final TicketState ticketState = Get.find<TicketState>();
  @override
  Widget build(BuildContext context) {
    switch (event.show.type) {
      case EventType.MOVIE:
        return SeatSelectionCinema(event: event);
      case EventType.THEATER:
        return SeatSelectionTheater(event: event);
      case EventType.LIVEMUSIC:
        return SeatSelectionLiveMusic(event: event);
      default:
        return SeatSelectionTheater(event: event);
    }
  }
}
