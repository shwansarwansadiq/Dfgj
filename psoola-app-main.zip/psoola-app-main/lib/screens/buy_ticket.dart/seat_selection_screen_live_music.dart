import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/components/seat/controller/seat_widget_controller.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/screens/buy_ticket.dart/purchase_button.dart';

import '../../components/seat/model/seat_model.dart';
import '../../models/event_type_model.dart';
import '../../states/ticket_state.dart';
import '../../utils/app_texts.dart';
import 'components/seat_section/seat_section.dart';
import 'components/seat_type_widget.dart';
import 'seat_picker_appbar.dart';

class SeatSelectionLiveMusic extends StatelessWidget {
  final EventModel event;
  TicketState ticketState = Get.find<TicketState>();
  SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();

  SeatSelectionLiveMusic({Key? key, required this.event}) : super(key: key);
  @override
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: SeatPickerAppbar(event: event),
      ),
      body: SafeArea(
          child: Stack(children: [
        Positioned(bottom: 0, child: PurchaseButton()),
        Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                const Expanded(flex: 1, child: SizedBox()),
                SeatSection(
                  event: event,
                  placeId: ticketState.selectedPlace!.id,
                  onSeatSelected: ({required Set<SeatNumber> seats}) {},
                ),
                const Divider(
                  thickness: 1,
                ),
                const SeatTypeWidget(
                  eventType: EventType.LIVEMUSIC,
                ),
                const Expanded(flex: 2, child: SizedBox()),
              ],
            ),
            Positioned(
                bottom: 70,
                right: 10,
                child: Column(
                  children: [
                    Text(
                      AppTexts.add_seats.tr,
                      style: const TextStyle(fontSize: 20),
                    ),
                    Row(
                      children: [
                        ElevatedButton(
                          child: const Icon(Icons.add),
                          onPressed: () {
                            seatWidgetController.addAddedSeats();
                          },
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        ElevatedButton(
                          child: const Icon(Icons.remove),
                          onPressed: () {
                            seatWidgetController.removeAddedSeats();
                          },
                        )
                      ],
                    ),
                  ],
                ))
          ],
        ),
      ])),
    );
  }
}
