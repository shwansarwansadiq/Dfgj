import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/components/seat/controller/seat_widget_controller.dart';

import '../../components/seat/model/seat_model.dart';
import '../../models/event_model.dart';
import '../../models/event_type_model.dart';
import '../../utils/app_texts.dart';

class SeatPickerAppbar extends StatelessWidget {
  const SeatPickerAppbar({
    Key? key,
    required this.event,
  }) : super(key: key);

  final EventModel event;

  int seatPrice(Set<SeatNumber> seatPrices) {
    int price = 0;
    for (var element in seatPrices) {
      price += element.price!;
    }
    return price;
  }

  numberOfSeats(Set<SeatNumber> seatsNumber) {
    int noSeats = 0;
    if (event.show.type == EventType.LIVEMUSIC) {
      for (var element in seatsNumber) {
        noSeats += element.noSeats!;
      }
      return noSeats;
    } else {
      return seatsNumber.length;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Spacer(),
        const SizedBox(
          width: 10,
        ),
        GetBuilder<SeatWidgetController>(builder: (_) {
          List<SeatModel> seats = _.getSelectedSeats;

          return Column(
            children: [
              Row(
                children: [
                  Text('${seats.length}',
                      style: const TextStyle(
                        fontSize: 15,
                      )),
                  const SizedBox(
                    width: 5,
                  ),
                  Text(AppTexts.seats.tr,
                      style: const TextStyle(
                        fontSize: 15,
                      )),
                  const SizedBox(
                    width: 20,
                  ),
                  _.getTotalAddedSeats > 0
                      ? Row(
                          children: [
                            Text(AppTexts.added_seats.tr,
                                style: const TextStyle(
                                  fontSize: 15,
                                )),
                            const SizedBox(
                              width: 5,
                            ),
                            Text(_.getTotalAddedSeats.toString())
                          ],
                        )
                      : const SizedBox()
                ],
              ),
              Row(
                children: [
                  Text('${AppTexts.price.tr}:',
                      style: const TextStyle(
                        fontSize: 15,
                      )),
                  const SizedBox(
                    width: 5,
                  ),
                  Text(_.totalSeatsPrice().toString()),
                ],
              )
            ],
          );
        }),
        const SizedBox(
          width: 5,
        ),
      ],
    );
  }
}
