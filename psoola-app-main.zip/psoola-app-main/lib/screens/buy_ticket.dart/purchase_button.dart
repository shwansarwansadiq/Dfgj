import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/components/seat/controller/seat_widget_controller.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/models/user_model.dart';
import 'package:psoola/states/ticket_state.dart';

import '../../components/wallet/wallet_sheet.dart';
import '../../utils/app_animations.dart';
import '../../utils/app_function.dart';
import '../../utils/app_texts.dart';

class PurchaseButton extends StatelessWidget {
  PurchaseButton({super.key});
  SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();
  TicketState ticketState = Get.find<TicketState>();
  AuthState authState = Get.find<AuthState>();
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (seatWidgetController.getSelectedSeats.isEmpty && ticketState.getSelectedEvent!.showsType != EventType.EVENT) {
          AppFunction.showPleaseSelectSeatFirstDialog(context);
          return;
        }
        if (authState.user.value.userType == "CHECKER") {
          print("sdljsd");
        } else if (authState.user.value.role == "USER" || authState.user.value.state != UserState.LOGEDIN) {
          AppFunction.showRegisterDialog(context, AppAnimations.loginDialog);
          return;
        }

        if (ticketState.getSelectedEvent!.showsType == EventType.EVENT && ticketState.getSelectedEventTime == null) {
          AppFunction.showPleaseSelectDatetimeDialog(context);
          return;
        }
        if (ticketState.getSelectedEvent!.showsType == EventType.EVENT && ticketState.getSelectedPlace == null) {
          AppFunction.showPleaseSelectPlaceFirstDialog(context);
          return;
        }
        showModalBottomSheet(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          isScrollControlled: true,
          context: context,
          builder: (BuildContext context) {
            return Wrap(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: WalletSheet(),
                )
              ],
            );
          },
        );
      },
      child: Container(
        width: Get.width,
        height: 60,
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Theme.of(context).primaryColor, Theme.of(context).primaryColor],
          ),
        ),
        child: Center(
            child: Text(
          AppTexts.payment.tr,
          style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        )),
      ),
    );
  }
}
