import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';
import '../../components/seat/model/seat_model.dart';
import '../../models/event_type_model.dart';
import '../../states/ticket_state.dart';
import 'components/seat_section/seat_section.dart';
import 'components/seat_type_widget.dart';
import 'purchase_button.dart';
import 'seat_picker_appbar.dart';

class SeatSelectionCinema extends StatelessWidget {
  final EventModel event;
  final TicketState ticketState = Get.find<TicketState>();

  SeatSelectionCinema({Key? key, required this.event}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: SeatPickerAppbar(event: event),
      ),
      body: SafeArea(
          child: Stack(children: [
        Positioned(bottom: 0, child: PurchaseButton()),
        Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            const Expanded(flex: 1, child: SizedBox()),
            Container(
              width: Get.width,
              padding: const EdgeInsets.symmetric(horizontal: 50),
              child: Image.asset(
                'assets/images/screen.png',
              ),
            ),
            SeatSection(
              placeId: ticketState.selectedPlace!.id,
              event: event,
              onSeatSelected: ({required Set<SeatNumber> seats}) {},
            ),
            const Divider(
              thickness: 1,
            ),
            const SeatTypeWidget(eventType: EventType.MOVIE),
            const Expanded(flex: 2, child: SizedBox()),
          ],
        ),
      ])),
    );
  }
}
