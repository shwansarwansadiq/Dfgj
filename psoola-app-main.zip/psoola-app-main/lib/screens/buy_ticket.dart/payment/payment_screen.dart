import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../../models/event_model.dart';
import '../../../utils/app_image.dart';

class PaymentScreen extends StatefulWidget {
  final EventModel event;
  const PaymentScreen({super.key, required this.event});

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Payment"),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                height: 30,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(AppTexts.tickets.tr,
                      style: const TextStyle(fontSize: 17)),
                  const Text("2", style: TextStyle(fontSize: 17)),
                  const Text("10.000 IQD", style: TextStyle(fontSize: 17)),
                ],
              ),
              const Divider(
                color: Colors.grey,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(
                    AppTexts.discount.tr,
                    style: const TextStyle(
                      fontSize: 17,
                    ),
                  ),
                  const Text("%0", style: TextStyle(fontSize: 17)),
                  const Text("10.000 IQD", style: TextStyle(fontSize: 17)),
                ],
              ),
              const Divider(
                color: Colors.grey,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(AppTexts.total.tr, style: const TextStyle(fontSize: 17)),
                  const Text("%0", style: TextStyle(fontSize: 17)),
                  const Text("10.000 IQD", style: TextStyle(fontSize: 17)),
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              Container(
                  width: double.infinity,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade200,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                        AppTexts.total.tr,
                        style: const TextStyle(fontSize: 20),
                      ),
                      const Text(
                        "10.000 IQD",
                        style:
                            TextStyle(fontSize: 20, color: Color(0xffF03069)),
                      ),
                    ],
                  )),
              const SizedBox(
                height: 60,
              ),
              Text(AppTexts.paymentMethod.tr,
                  style: const TextStyle(fontSize: 17)),
              const SizedBox(
                height: 30,
              ),
              Row(
                children: [
                  Image.asset(
                    AppImage.fastpayPng,
                    width: 100,
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Image.asset(
                    AppImage.zaincashPng,
                    width: 100,
                  ),
                ],
              ),
              const SizedBox(
                height: 30,
              ),
              Text(
                AppTexts.byPurchasingYouAgreeToOurTermsAndConditions.tr,
                style: const TextStyle(fontSize: 15),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
