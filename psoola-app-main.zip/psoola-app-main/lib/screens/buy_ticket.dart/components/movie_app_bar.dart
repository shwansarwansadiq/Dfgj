import 'package:flutter/material.dart';
import 'package:psoola/screens/buy_ticket.dart/components/search_bar.dart'
    as SearchBarr;

import '../../../utils/app_constants.dart';

class MovieAppBar extends StatelessWidget {
  const MovieAppBar({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        // todo: convert this to it's own widget
        Container(
          width: MediaQuery.of(context).size.width * .15,
          height: 60.0,
          decoration: AppConstants.kRoundedFadedBorder,
          child: IconButton(icon: const Icon(Icons.menu), onPressed: () {}),
        ),
        const SearchBarr.SearchBar(hint: 'Search Movies..'),
      ],
    );
  }
}
