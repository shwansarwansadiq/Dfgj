import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/models/seat_design_model.dart';
import 'package:psoola/states/ticket_state.dart';

class HallCard extends StatelessWidget {
  final HallModel hallModel;
  final Function({required HallModel hallModel}) onTap;

  HallCard({super.key, required this.hallModel, required this.onTap});

  final String currentLang = Get.locale!.languageCode;
  @override
  Widget build(BuildContext context) {
    return GetBuilder<TicketState>(builder: (_) {
      return GestureDetector(
        onTap: () {
          onTap(hallModel: hallModel);
        },
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: _.getSelectedHall != null &&
                    _.getSelectedHall!.id == hallModel.id
                ? Colors.amber
                : Theme.of(context).scaffoldBackgroundColor,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black12.withOpacity(0.2),
                spreadRadius: 1,
                blurRadius: 7,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ],
          ),
          child: Column(
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  MultiLangText(text: hallModel.title),
                ],
              )
            ],
          ),
        ),
      );
    });
  }
}
