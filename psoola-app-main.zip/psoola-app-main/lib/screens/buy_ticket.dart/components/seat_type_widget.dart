import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:psoola/utils/app_icons.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../../models/event_type_model.dart';

class SeatTypeWidget extends StatelessWidget {
  final EventType eventType;
  const SeatTypeWidget({super.key, required this.eventType});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        SvgPicture.asset(
          eventType == EventType.MOVIE ||
                  eventType == EventType.THEATER ||
                  eventType == EventType.EVENT
              ? AppIcons.svg_seat_selected
              : eventType == EventType.CONCERT
                  ? AppIcons.svg_box_selected
                  : AppIcons.svg_table_selected,
          width: 25,
        ),
        const SizedBox(
          width: 15,
        ),
        Text(AppTexts.your_seat.tr, style: seatTypeTextStyle()),
        const SizedBox(
          width: 15,
        ),
        SvgPicture.asset(
          eventType == EventType.MOVIE ||
                  eventType == EventType.THEATER ||
                  eventType == EventType.EVENT
              ? AppIcons.svg_seat_selected
              : eventType == EventType.CONCERT
                  ? AppIcons.svg_box_selected
                  : AppIcons.svg_table_selected,
          width: 25,
          color: const Color(0xff555555),
        ),
        const SizedBox(
          width: 10,
        ),
        Text(AppTexts.seat_reserved.tr, style: seatTypeTextStyle()),
        const SizedBox(
          width: 20,
        ),
        SvgPicture.asset(
          eventType == EventType.MOVIE ||
                  eventType == EventType.THEATER ||
                  eventType == EventType.EVENT
              ? AppIcons.svg_seat_empty
              : eventType == EventType.CONCERT
                  ? AppIcons.svg_box_empty
                  : AppIcons.svg_table_empty,
          width: 25,
        ),
        const SizedBox(
          width: 10,
        ),
        Text(AppTexts.seat_available.tr, style: seatTypeTextStyle()),
      ]),
    );
  }

  TextStyle seatTypeTextStyle() {
    return const TextStyle(
      fontSize: 13,
    );
  }
}
