import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/models/place_model.dart';
import 'package:psoola/states/ticket_state.dart';

class PlaceCard extends StatelessWidget {
  final PlaceModel placeModel;
  final Function({required PlaceModel place}) onTap;

  PlaceCard({super.key, required this.placeModel, required this.onTap});

  final String currentLang = Get.locale!.languageCode;
  @override
  Widget build(BuildContext context) {
    return GetBuilder<TicketState>(builder: (_) {
      return GestureDetector(
        onTap: () {
          onTap(place: placeModel);
        },
        child: Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color:
                _.selectedPlace != null && _.selectedPlace!.id == placeModel.id
                    ? Colors.amber
                    : Theme.of(context).scaffoldBackgroundColor,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black12.withOpacity(0.2),
                spreadRadius: 1,
                blurRadius: 7,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                width: 120,
                height: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  image: DecorationImage(
                    image: CachedNetworkImageProvider(placeModel.logo),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              5.height,
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  MultiLangText(text: placeModel.title),
                  5.height,
                  MultiLangText(
                    text: placeModel.location.province.name,
                    style: const TextStyle(fontSize: 12),
                  ),
                ],
              )
            ],
          ),
        ),
      );
    });
  }
}
