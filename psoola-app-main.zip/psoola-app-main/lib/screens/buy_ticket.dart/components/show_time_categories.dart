import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:intl/intl.dart';

import '../../../utils/app_constants.dart';
import '../../../utils/app_image.dart';

class ShowTimeCategories extends StatefulWidget {
  bool isActive;
  final DateTime datetime;
  final Function({required DateTime datetime}) onTap;

  ShowTimeCategories(
      {Key? key,
      required this.datetime,
      this.isActive = false,
      required this.onTap})
      : super(key: key);

  @override
  _ShowTimeCategoriesState createState() => _ShowTimeCategoriesState();
}

class _ShowTimeCategoriesState extends State<ShowTimeCategories> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      highlightColor: Colors.transparent,
      splashColor: Colors.transparent,
      onTap: () {
        widget.onTap(datetime: widget.datetime);
      },
      child: Stack(alignment: Alignment.center, children: [
        SvgPicture.asset(
          Theme.of(context).brightness == Brightness.light
              ? AppImage.smallTicketSvg
              : AppImage.smallTicketDark,
          height: 100,
          width: 100,
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: [
                Text(
                  widget.datetime.day.toString(),
                  style: TextStyle(
                      color: widget.isActive
                          ? AppConstants.kPimaryColor
                          : Colors.grey,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  ' - ',
                  style: TextStyle(
                      color: widget.isActive
                          ? AppConstants.kPimaryColor
                          : Colors.grey,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  widget.datetime.month.toString(),
                  style: TextStyle(
                      color: widget.isActive
                          ? AppConstants.kPimaryColor
                          : Colors.grey,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
            Text(DateFormat.jm().format(widget.datetime).toString(),
                style: TextStyle(
                    color: widget.isActive
                        ? AppConstants.kPimaryColor
                        : Colors.grey,
                    fontSize: 18.0))
          ],
        ),
      ]),
    );
  }
}
