import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/states/ticket_state.dart';

import '../../../utils/app_constants.dart';
import '../../../utils/app_image.dart';

class ShowTimeCard extends StatefulWidget {
  final EventTimeModel eventTime;
  final Function({required EventTimeModel eventTime}) onTap;

  const ShowTimeCard({Key? key, required this.eventTime, required this.onTap})
      : super(key: key);

  @override
  _ShowTimeCardState createState() => _ShowTimeCardState();
}

class _ShowTimeCardState extends State<ShowTimeCard> {
  TicketState ticketState = Get.find<TicketState>();

  @override
  Widget build(BuildContext context) {
    EventTimeModel? selectedEventTime = ticketState.getSelectedEventTime;
    bool isActive = selectedEventTime != null &&
        selectedEventTime.id == widget.eventTime.id;
    return InkWell(
      highlightColor: Colors.transparent,
      splashColor: Colors.transparent,
      onTap: () {
        widget.onTap(eventTime: widget.eventTime);
      },
      child: Stack(alignment: Alignment.center, children: [
        SvgPicture.asset(
          Theme.of(context).brightness == Brightness.light
              ? AppImage.smallTicketSvg
              : AppImage.smallTicketDark,
          height: 100,
          width: 100,
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(
              children: [
                Text(
                  widget.eventTime.datetime.day.toString(),
                  style: TextStyle(
                      color: isActive ? AppConstants.kPimaryColor : Colors.grey,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  ' - ',
                  style: TextStyle(
                      color: isActive ? AppConstants.kPimaryColor : Colors.grey,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  widget.eventTime.datetime.month.toString(),
                  style: TextStyle(
                      color: isActive ? AppConstants.kPimaryColor : Colors.grey,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
            Text(DateFormat.jm().format(widget.eventTime.datetime).toString(),
                style: TextStyle(
                    color: isActive ? AppConstants.kPimaryColor : Colors.grey,
                    fontSize: 18.0))
          ],
        ),
      ]),
    );
  }
}
