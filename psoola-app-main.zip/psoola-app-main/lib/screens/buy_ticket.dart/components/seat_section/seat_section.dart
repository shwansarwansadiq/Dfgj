import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/api/hall_api.dart';
import 'package:psoola/components/seat/controller/seat_widget_controller.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/states/ticket_state.dart';

import '../../../../components/seat/model/seat_model.dart';
import '../../../../components/seat/seats_selector.dart';

class SeatSection extends StatefulWidget {
  final EventModel event;

  final String placeId;
  final Function({required Set<SeatNumber> seats}) onSeatSelected;
  const SeatSection({Key? key, required this.event, required this.placeId, required this.onSeatSelected}) : super(key: key);

  @override
  State<SeatSection> createState() => _SeatSectionState();
}

class _SeatSectionState extends State<SeatSection> {
  TicketState ticketState = Get.find<TicketState>();
  SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();

  @override
  void initState() {
    seatWidgetController.clear();
    HallApi().fetchEventHallsBySelectedPlaceIdEventIdTimeId();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Stack(
        children: [
          SeatsSelector(
            width: Get.width,
          ),
        ],
      ),
    );
  }
}
