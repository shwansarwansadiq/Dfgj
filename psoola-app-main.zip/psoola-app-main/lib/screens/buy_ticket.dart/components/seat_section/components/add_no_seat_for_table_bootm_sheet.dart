import 'package:flutter/material.dart';
import 'package:flutter_spinbox/flutter_spinbox.dart';
import 'package:get/get.dart';

import '../../../../../utils/app_texts.dart';

class AddNoSeatForTableBootmSheet extends StatelessWidget {
  double? _noSeats;
  int seatPrice;
  Function(double noSeat) onTap;

  AddNoSeatForTableBootmSheet(
      {super.key, required this.onTap, required this.seatPrice});
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.max,
      children: [
        const SizedBox(
          height: 20,
        ),
        Container(
          height: 5,
          width: 50,
          decoration: BoxDecoration(
            color: Colors.grey.shade300,
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(30),
              topRight: Radius.circular(30),
              bottomLeft: Radius.circular(30),
              bottomRight: Radius.circular(30),
            ),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
        // Container(
        //   height: 50,
        //   width: Get.width,
        //   decoration: const BoxDecoration(
        //     image: DecorationImage(
        //       image: AssetImage(AppImage.logo),
        //       fit: BoxFit.contain,
        //     ),
        //     borderRadius: BorderRadius.only(
        //       topLeft: Radius.circular(30),
        //     ),
        //   ),
        // ),
        const SizedBox(
          height: 50,
        ),
        Text(
          AppTexts.add_seats_for_your_selected_table.tr,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(
          height: 20,
        ),
        Text(
          AppTexts.minimum_seats_per_table_are_two.tr,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(
          height: 20,
        ),

        const SizedBox(
          height: 20,
        ),
        const SizedBox(
          height: 20,
        ),
        // text input for just number
        Container(
            width: Get.width,
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: SpinBox(
              min: 2,
              max: 30,
              value: 2,
              onChanged: (value) {
                _noSeats = value;
              },
            )),
        const SizedBox(
          height: 20,
        ),
        // submit button with primary color
        Container(
          width: Get.width,
          padding: const EdgeInsets.only(left: 20, right: 20),
          child: ElevatedButton(
            // add primary color to the button
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white,
              backgroundColor: Theme.of(context).primaryColor,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(30)),
              ),
            ),
            onPressed: () async {
              if (_noSeats == null) return;
              onTap(_noSeats!);
            },
            child: Text(AppTexts.add_seats.tr,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                )),
          ),
        ),
        const SizedBox(
          height: 40,
        ),
      ],
    );
  }
}
