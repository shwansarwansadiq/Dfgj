import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/api/cast_api.dart';
import 'package:psoola/screens/event_details/components/movie_theater_header.dart';
import 'package:psoola/states/event_state.dart';
import 'package:psoola/states/ticket_state.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../../components/buttons/back_button.dart';
import '../../../models/event_model.dart';
import '../../../services/snackbar.dart';
import '../../buy_ticket.dart/seat_selection_screen.dart';
import '../components/buy_ticket_button.dart';
import '../components/datetime_section.dart';
import '../components/hall_section.dart';
import '../components/place_section.dart';
import 'components/cast_tab.dart';
import 'components/movie_app_bar.dart';
import 'components/review_tab.dart';

class EventMovieDetails extends StatefulWidget {
  final EventModel eventModel;
  const EventMovieDetails({super.key, required this.eventModel});

  @override
  State<EventMovieDetails> createState() => _EventMovieDetailsState();
}

class _EventMovieDetailsState extends State<EventMovieDetails>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  EventsState eventsState = Get.find<EventsState>();
  TicketState ticketState = Get.find<TicketState>();

  @override
  void initState() {
    fetchCastApi(showId: widget.eventModel.show.id);
    ticketState.setSelectedEvent = widget.eventModel;
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        top: false,
        bottom: false,
        child: NestedScrollView(
          headerSliverBuilder: (BuildContext ctx, bool value) {
            return [
              SliverAppBar(
                  leading: Container(
                    padding: const EdgeInsets.all(4),
                    child: CustomBackButton(
                      onPressed: () {
                        Get.back();
                      },
                    ),
                  ),
                  scrolledUnderElevation: 4,
                  pinned: true,
                  snap: false,
                  floating: false,
                  expandedHeight: Get.height * 0.4,
                  flexibleSpace: FlexibleSpaceBar(
                    background: MovieTheaterHeader(event: widget.eventModel),
                  )),
              SliverPersistentHeader(
                pinned: true,
                delegate: SliverAppBarDelegate(
                  maxHeight: 50,
                  minHeight: 30,
                  child: TabBar(
                    controller: _tabController,
                    unselectedLabelColor: Colors.grey,
                    labelColor: Get.theme.primaryColor,
                    indicatorColor: Get.theme.primaryColor,
                    tabs: [
                      Tab(
                        text: AppTexts.buy_ticket.tr,
                      ),
                      Tab(
                        text: AppTexts.reviews.tr,
                      ),
                      Tab(
                        text: AppTexts.cast.tr,
                      ),
                    ],
                  ),
                ),
              ),
            ];
          },
          body: TabBarView(
            controller: _tabController,
            children: [
              _buyTicketTab(),
              ReviewTab(
                eventModel: widget.eventModel,
              ),
              const CastTab(),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: SlideInUp(
        child: BottomSubmitButton(
          onPressed: submitBtn,
        ),
      ),
    );
  }

  Column _buyTicketTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              10.height,
              Text(AppTexts.buy_ticket.tr,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  )),
              const SizedBox(height: 10),
              Text(AppTexts.please_below_select_date_and_time.tr,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.normal,
                    color: Colors.grey,
                  )),
              const SizedBox(height: 10),
            ],
          ),
        ),
        DatetimeSection(
          event: widget.eventModel,
        ),
        const SizedBox(height: 20),
        PlaceSection(
          event: widget.eventModel,
        ),
        HallSection(
          event: widget.eventModel,
        )
      ],
    );
  }

  submitBtn() {
    if (ticketState.getSelectedEventTime != null &&
        ticketState.getSelectedPlace != null &&
        ticketState.getSelectedHall != null) {
      Get.to(BuyTicket(
        event: widget.eventModel,
      ));
    } else {
      if (ticketState.getSelectedEventTime == null) {
        openSnackbar(
          context,
          AppTexts.please_select_time.tr,
        );
        return;
      }
      if (ticketState.getSelectedPlace == null) {
        openSnackbar(
          context,
          AppTexts.please_select_cinema.tr,
        );
        return;
      }
      if (ticketState.getSelectedHall == null) {
        openSnackbar(
          context,
          AppTexts.please_select_hall.tr,
        );
        return;
      }
    }
  }
}
