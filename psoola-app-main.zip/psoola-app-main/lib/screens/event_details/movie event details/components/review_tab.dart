import 'package:flutter/material.dart';
import 'package:psoola/models/event_model.dart';

import '../../../../components/review/review_widget.dart';
import '../../../../models/user_model.dart';

class ReviewTab extends StatelessWidget {
  final EventModel eventModel;

  const ReviewTab({super.key, required this.eventModel});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: EventReview(
        eventId: eventModel.id,
        totalReviewModel: eventModel.totalReview,
        userType: UserType.CUSTOMER,
      ),
    );
  }
}
