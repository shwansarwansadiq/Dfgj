import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/api/events_api.dart';
import 'package:psoola/components/seat/controller/seat_widget_controller.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/models/place_model.dart';
import 'package:psoola/screens/buy_ticket.dart/components/place_card.dart';
import 'package:psoola/states/event_selection_controller.dart';
import 'package:psoola/states/ticket_state.dart';

import '../../../models/event_model.dart';
import '../../../utils/app_texts.dart';

class PlaceSection extends StatefulWidget {
  final EventModel event;

  const PlaceSection({Key? key, required this.event}) : super(key: key);

  @override
  State<PlaceSection> createState() => _PlaceSectionState();
}

class _PlaceSectionState extends State<PlaceSection> {
  TicketState ticketState = Get.find<TicketState>();
  SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<EventSelectionController>(builder: (_) {
      List<PlaceModel> eventPlaces = _.getEventPlaces;
      return eventPlaces.isNotEmpty
          ? Container(
              padding: const EdgeInsets.all(15.0),
              width: Get.width,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                          widget.event.showsType == EventType.MOVIE
                              ? AppTexts.please_select_cinema.tr
                              : AppTexts.please_below_select_category.tr,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          )),
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: Get.width,
                    child: SingleChildScrollView(
                        clipBehavior: Clip.none,
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: eventPlaces
                              .map((e) => PlaceCard(
                                    onTap: ({required PlaceModel place}) async {
                                      ticketState.setSelectedPlace = place;
                                      var result = await EventApi()
                                          .fetchEventHallsBySelectedPlaceIdEventId();
                                    },
                                    placeModel: e,
                                  ))
                              .toList(),
                        )),
                  ),
                ],
              ))
          : const SizedBox();
    });
  }
}
