import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/utils/app_texts.dart';

class BottomSubmitButton extends StatelessWidget {
  final Function() onPressed;

  const BottomSubmitButton({Key? key, required this.onPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onPressed();
      },
      child: Container(
        width: Get.width,
        height: 60,
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(20), topRight: Radius.circular(20)),
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).primaryColor,
              Theme.of(context).primaryColor
            ],
          ),
        ),
        child: Center(
            child: Text(
          AppTexts.buy_ticket.tr,
          style: const TextStyle(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        )),
      ),
    );
  }
}
