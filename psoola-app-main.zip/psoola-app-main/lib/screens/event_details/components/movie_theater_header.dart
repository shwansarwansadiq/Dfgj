import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/utils/app_function.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../../../models/event_type_model.dart';
import '../../../utils/app_defaults.dart';
import '../../../utils/app_texts.dart';

class MovieTheaterHeader extends StatelessWidget {
  final EventModel event;
  MovieTheaterHeader({Key? key, required this.event}) : super(key: key);

  final String currentLang = Get.locale!.languageCode;

  final double herroWidgetWidth = 160;
  final double spaceBetweenHeroAndDetails = 10;
  final double areaPadding = 15;

  @override
  Widget build(BuildContext context) {
    final heroEvent = _buildHeroEvent();
    final eventDetails = _buildEventDetails(context);

    return Stack(
      alignment: AlignmentDirectional.bottomCenter,
      children: [
        _buildCoverImage(),
        _buildGradientOverlay(),
        Padding(
          padding: EdgeInsets.all(areaPadding),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              heroEvent,
              SizedBox(
                width: spaceBetweenHeroAndDetails,
              ),
              eventDetails
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildHeroEvent() {
    return Hero(
      tag: event.id,
      child: Container(
        height: 210,
        width: herroWidgetWidth,
        decoration: BoxDecoration(
            color: Colors.black,
            image: DecorationImage(
                image: NetworkImage(event.show.poster), fit: BoxFit.cover),
            borderRadius: BorderRadius.circular(AppDefaults.radius)),
      ),
    );
  }

  Widget _buildCoverImage() {
    return Container(
      height: Get.height * 0.4,
      width: Get.width,
      decoration: BoxDecoration(
        color: Colors.black,
        image: DecorationImage(
            image: NetworkImage(event.show.cover), fit: BoxFit.cover),
      ),
    );
  }

  Widget _buildGradientOverlay() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.black.withOpacity(0.1),
            Colors.black.withOpacity(0.95),
          ],
        ),
      ),
    );
  }

  Widget _buildEventDetails(BuildContext context) {
    var width = Get.width -
        herroWidgetWidth -
        spaceBetweenHeroAndDetails -
        2 * areaPadding;
    return SizedBox(
      height: 210,
      width: width,
      child: Column(
        mainAxisSize: MainAxisSize.max, // To make the card compact
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildEventTitle(),
          5.height,
          _buildEventDuration(),
          const SizedBox(height: 5),
          _buildDirectorInfo(),
          const SizedBox(height: 5),
          if (event.show.type == EventType.MOVIE) _buildGenreInfo(width),
          10.height,
          if (event.show.type == EventType.MOVIE) _buildReviewInfo(),
          const Spacer(),
          if (event.show.videoUrl != null) _trailerButton(context),
        ],
      ),
    );
  }

  Widget _buildEventTitle() {
    return SizedBox(
      width: Get.width * 0.4,
      child: AutoSizeText(
        currentLang == "en"
            ? event.show.title.textEn
            : currentLang == "ar"
                ? event.show.title.textAr
                : event.show.title.textKr,
        overflow: TextOverflow.ellipsis,
        maxFontSize: 20,
        minFontSize: 18,
        maxLines: 1,
        style: const TextStyle(
            color: Colors.white, fontWeight: FontWeight.bold, fontSize: 22),
      ),
    );
  }

  Widget _buildEventDuration() {
    return Row(
      children: [
        const Icon(
          IconlyLight.timeCircle,
          color: Colors.white,
          size: 20,
        ),
        const SizedBox(width: 5),
        Text(
          AppFunction.durationToHour(Duration(seconds: event.show.duration)),
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.normal, fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildDirectorInfo() {
    return Row(
      children: [
        Text(
          "${AppTexts.director.tr}:",
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.normal, fontSize: 12),
        ),
        Text(
          event.show.director!,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.normal, fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildGenreInfo(double width) {
    return SizedBox(
      width: width,
      height: 30,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: event.show.genres!
            .map((e) => Container(
                  margin: const EdgeInsets.only(right: 5),
                  alignment: Alignment.center,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 5, vertical: 0),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: MultiLangText(
                    style: const TextStyle(color: Colors.white),
                    text: e.title,
                  ),
                ))
            .toList(),
      ),
    );
  }

  Widget _buildReviewInfo() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(
          IconlyBold.star,
          color: Colors.amber,
          size: 20,
        ),
        4.width,
        _buildRating(),
        _buildTotalReviews(),
      ],
    );
  }

  Widget _buildRating() {
    return SizedBox(
      child: AutoSizeText(
        event.totalReview.averageRating.toDouble().toString(),
        maxFontSize: 12,
        minFontSize: 10,
        maxLines: 1,
        style: const TextStyle(
          color: Colors.white,
        ),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  Widget _buildTotalReviews() {
    return SizedBox(
      child: AutoSizeText(
        ' (${event.totalReview.totalReview} ${"reviews".tr})',
        maxFontSize: 12,
        minFontSize: 10,
        maxLines: 1,
        style: const TextStyle(
          color: Colors.white,
        ),
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  Widget _trailerButton(BuildContext context) {
    return Container(
      width: Get.width * 0.4,
      height: 50,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Theme.of(context).secondaryHeaderColor.withOpacity(0.9),
          Theme.of(context).primaryColor
        ]),
        borderRadius: BorderRadius.circular(AppDefaults.radius),
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
        ),
        onPressed: () => _showTrailer(context),
        child: _buildTrailerButtonText(),
      ),
    );
  }

  Widget _buildTrailerButtonText() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(
          IconlyBold.play,
          color: Colors.white,
          size: 20,
        ),
        const SizedBox(width: 4),
        Text(AppTexts.trailer.tr),
      ],
    );
  }

  void _showTrailer(BuildContext context) {
    Get.dialog(
      AlertDialog(
        insetPadding: EdgeInsets.zero,
        contentPadding: EdgeInsets.zero,
        clipBehavior: Clip.antiAliasWithSaveLayer,
        backgroundColor: Colors.transparent,
        content: SizedBox(
          height: Get.height * 0.5,
          width: Get.width,
          child: YoutubePlayer(
            controller: YoutubePlayerController(
              initialVideoId: event.show.videoUrl!,
            ),
            aspectRatio: 16 / 9,
          ),
        ),
      ),
    );
  }
}
