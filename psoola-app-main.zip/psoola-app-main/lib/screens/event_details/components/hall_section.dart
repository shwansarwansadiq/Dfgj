import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/screens/buy_ticket.dart/components/hall_card.dart';
import 'package:psoola/states/event_selection_controller.dart';
import 'package:psoola/states/ticket_state.dart';

import '../../../models/event_model.dart';
import '../../../models/event_type_model.dart';
import '../../../models/seat_design_model.dart';
import '../../../utils/app_texts.dart';

class HallSection extends StatefulWidget {
  final EventModel event;

  const HallSection({Key? key, required this.event}) : super(key: key);

  @override
  State<HallSection> createState() => _HallSectionState();
}

class _HallSectionState extends State<HallSection> {
  TicketState ticketState = Get.find<TicketState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<EventSelectionController>(builder: (_) {
      List<HallModel> eventHall = _.getEventHalls;
      return eventHall.isNotEmpty
          ? Container(
              padding: const EdgeInsets.all(15.0),
              width: Get.width,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const SizedBox(width: 5),
                      Text(
                          widget.event.showsType == EventType.EVENT
                              ? AppTexts.please_below_select_category.tr
                              : "${AppTexts.hall.tr} ",
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          )),
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: Get.width,
                    child: SingleChildScrollView(
                        clipBehavior: Clip.none,
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: eventHall
                              .map((e) => HallCard(
                                    onTap: ({required HallModel hallModel}) {
                                      ticketState.setSelectedHall = hallModel;

                                      // _.setPlacesByEventModel(event: widget.event);
                                    },
                                    hallModel: e,
                                  ))
                              .toList(),
                        )),
                  ),
                ],
              ))
          : const SizedBox();
    });
  }
}
