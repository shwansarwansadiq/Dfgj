import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/api/events_api.dart';
import 'package:psoola/states/event_selection_controller.dart';
import 'package:psoola/states/ticket_state.dart';

import '../../../models/event_model.dart';
import '../../../models/event_type_model.dart';
import '../../../models/place_model.dart';
import '../../../models/seat_design_model.dart';
import '../../buy_ticket.dart/components/show_time_card.dart';

class DatetimeSection extends StatefulWidget {
  final EventModel event;

  const DatetimeSection({Key? key, required this.event}) : super(key: key);

  @override
  State<DatetimeSection> createState() => _DatetimeSectionState();
}

class _DatetimeSectionState extends State<DatetimeSection> {
  TicketState ticketState = Get.find<TicketState>();

  @override
  void initState() {
    super.initState();
    EventApi().fetchEventTimes(eventId: widget.event.id);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<EventSelectionController>(builder: (_) {
      List<EventTimeModel> eventDateTimes = _.getEventTimes;
      return Container(
          padding: const EdgeInsets.all(15.0),
          width: Get.width,
          height: 120,
          child: SingleChildScrollView(
              clipBehavior: Clip.none,
              scrollDirection: Axis.horizontal,
              child: Row(
                children: eventDateTimes
                    .map((e) => ShowTimeCard(
                          onTap: ({required EventTimeModel eventTime}) async {
                            if (widget.event.showsType == EventType.MOVIE) {
                              ticketState.setSelectedEventTime = eventTime;
                              await EventApi().fetchEventPlacesBySelectedTime();
                              return;
                            }
                            if (widget.event.showsType == EventType.THEATER) {
                              ticketState.setSelectedEventTime = eventTime;
                              List<PlaceModel> places = await EventApi()
                                  .fetchEventPlacesBySelectedTime();
                              ticketState.setSelectedPlace = places[0];
                              List<HallModel> halls = await EventApi()
                                  .fetchEventHallsBySelectedPlaceIdEventId();
                              ticketState.setSelectedHall = halls[0];
                            }
                            if (widget.event.showsType == EventType.EVENT) {
                              ticketState.setSelectedEventTime = eventTime;
                              var places = await EventApi()
                                  .fetchEventPlacesBySelectedTime();
                              ticketState.setSelectedPlace = places[0];
                              await EventApi()
                                  .fetchEventHallsBySelectedPlaceIdEventId();
                            }
                          },
                          eventTime: e,
                        ))
                    .toList(),
              )));
    });
  }
}
