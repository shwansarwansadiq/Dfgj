import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';

import '../../../models/event_model.dart';
import '../../../utils/app_function.dart';
import '../../../utils/app_texts.dart';
import '../../place details/place_details.dart';

class LiveMusicConcertHeader extends StatelessWidget {
  final EventModel event;
  final String currentLang;
  const LiveMusicConcertHeader({
    Key? key,
    required this.event,
    required this.currentLang,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Hero(
      tag: event.id,
      child: Container(
        height: Get.height * 0.5,
        width: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: CachedNetworkImageProvider(event.show.poster),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(children: [
          Container(
            height: Get.height * 0.5,
            width: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  Colors.black,
                ],
              ),
            ),
          ),
          Positioned(
            top: 30,
            left: currentLang == 'en' ? 10 : null,
            right: currentLang == 'ar' || currentLang == 'fa' ? 10 : null,
            child: Container(
              height: 50,
              width: 50,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                borderRadius: const BorderRadius.all(
                  Radius.circular(25),
                ),
              ),
              child: IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: const Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            left: currentLang == 'en' ? 20 : null,
            right: currentLang == 'ar' || currentLang == 'fa' ? 20 : null,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  currentLang == 'en'
                      ? event.show.title.textEn
                      : currentLang == 'ar'
                          ? event.show.title.textAr
                          : event.show.title.textKr,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Row(
                  children: [
                    const Icon(
                      Icons.location_on,
                      color: Colors.white,
                      size: 15,
                    ),
                    const SizedBox(width: 5),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        AutoSizeMultiLangText(
                          text: event.places[0].title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(width: 5),
                        SizedBox(
                          height: 40,
                          child: TextButton(
                            onPressed: () {
                              Get.to(() => PlaceDetails(eventModel: event));
                            },
                            child: MultiLangText(
                              text: event.places[0].title,
                              style: const TextStyle(
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    const Icon(
                      Icons.calendar_today,
                      color: Colors.white,
                      size: 15,
                    ),
                    const SizedBox(width: 5),
                    Row(
                      children: [
                        Text("${AppTexts.startDate.tr}: ",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                            )),
                        Text(
                          '${event.startTime.day} /${event.startTime.month}/ ${event.startTime.year}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Row(
                  children: [
                    const Icon(
                      Icons.timer_outlined,
                      color: Colors.white,
                      size: 15,
                    ),
                    const SizedBox(width: 5),
                    Text("${AppTexts.time.tr}:",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                        )),
                    const SizedBox(width: 5),
                    Text(
                      AppFunction.convertTimestampToTimeWithAmPm(
                              Timestamp.fromDate(event.startTime))
                          .toString(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ]),
      ),
    );
  }
}
