import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/models/event_model.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../../../utils/app_defaults.dart';
import '../../../utils/app_texts.dart';

class EventHeader extends StatelessWidget {
  final EventModel event;
  const EventHeader({Key? key, required this.event}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: Get.height * 0.4,
      width: Get.width,
      child: Stack(
          alignment: AlignmentDirectional
              .bottomCenter, // Aligns the children to the bottom

          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.black,
                image: DecorationImage(
                    image: NetworkImage(event.show.poster), fit: BoxFit.cover),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.1),
                    Colors.black.withOpacity(0.95),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 210,
                    width: 150,
                    decoration: BoxDecoration(
                        color: Colors.black,
                        image: DecorationImage(
                            image: NetworkImage(event.show.poster),
                            fit: BoxFit.cover),
                        borderRadius:
                            BorderRadius.circular(AppDefaults.radius)),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  SizedBox(
                    height: 210,
                    child: Column(
                      mainAxisSize:
                          MainAxisSize.max, // To make the card compact
                      crossAxisAlignment: CrossAxisAlignment.start,
                      // Aligns the children to the bottom
                      children: [
                        SizedBox(
                          width: Get.width * 0.4,
                          child: AutoSizeText(
                            event.show.title.textAr,
                            maxFontSize: 20,
                            minFontSize: 15,
                            maxLines: 2,
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 22),
                          ),
                        ),
                        const Row(
                          children: [
                            Icon(
                              IconlyLight.timeCircle,
                              color: Colors.white,
                              size: 20,
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              "یەک کاتژمێر و چل خولەک",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.normal,
                                  fontSize: 12),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Row(
                          children: [
                            Text(
                              "${AppTexts.director.tr}:",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.normal,
                                  fontSize: 12),
                            ),
                            const Text(
                              "نەهرۆ ئاسۆ",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.normal,
                                  fontSize: 12),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Row(
                          children: [
                            Text(
                              "${AppTexts.geners.tr}:",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.normal,
                                  fontSize: 12),
                            ),
                            const Text(
                              " ترسناک، درامی",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.normal,
                                  fontSize: 12),
                            ),
                          ],
                        ),
                        10.height,
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Icon(
                              IconlyBold.star,
                              color: Colors.amber,
                              size: 20,
                            ),
                            4.width,
                            SizedBox(
                              width: Get.width * 0.06,
                              child: const AutoSizeText(
                                "10",
                                maxFontSize: 12,
                                minFontSize: 10,
                                maxLines: 1,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 13),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            SizedBox(
                              width: Get.width * 0.3,
                              child: const AutoSizeText(
                                "هەڵسەنگاندن",
                                maxFontSize: 12,
                                minFontSize: 10,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.normal,
                                    fontSize: 13),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        Container(
                          width: Get.width * 0.4,
                          height: 50,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(colors: [
                              Theme.of(context)
                                  .secondaryHeaderColor
                                  .withOpacity(0.6),
                              Theme.of(context).primaryColor
                            ]),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                            ),
                            onPressed: () {
                              //show dialog
                              Get.dialog(
                                AlertDialog(
                                  backgroundColor: Colors.transparent,
                                  content: SizedBox(
                                    height: Get.height * 0.5,
                                    width: Get.width,
                                    child: YoutubePlayer(
                                      controller: YoutubePlayerController(
                                        initialVideoId: event.show.videoUrl!,
                                      ),
                                      aspectRatio: 16 / 9,
                                    ),
                                  ),
                                ),
                              );
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(
                                  IconlyBold.play,
                                  color: Colors.white,
                                  size: 20,
                                ),
                                4.width,
                                Text(AppTexts.trailer.tr),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
            Positioned(
              top: 30,
              right: 10,
              child: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(100)),
                child: IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: const Icon(
                    Icons.arrow_back,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
              ),
            )
          ]),
    );
  }
}
