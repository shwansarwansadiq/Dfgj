import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/components/cards/map_card.dart';
import 'package:psoola/screens/place%20location/place_location.dart';

import '../../api/events_api.dart';
import '../../models/event_model.dart';
import '../../states/ticket_state.dart';
import '../buy_ticket.dart/seat_selection_screen.dart';
import 'components/buy_ticket_button.dart';
import 'components/live_music_concert_header.dart';
import 'event_details.dart';

class EventConcertDetails extends StatefulWidget {
  final EventModel eventModel;
  const EventConcertDetails({super.key, required this.eventModel});

  @override
  State<EventConcertDetails> createState() => _EventConcertDetailsState();
}

class _EventConcertDetailsState extends State<EventConcertDetails> {
  late final String currentLang;

  // Ideally, this state should be handled and managed outside this widget.
  TicketState ticketState = Get.find<TicketState>();

  @override
  void initState() {
    init();
    super.initState();
  }

  init() async {
    ticketState.setSelectedEvent = widget.eventModel;
    var eventTime =
        await EventApi().fetchEventTimes(eventId: widget.eventModel.id);
    ticketState.setSelectedEventTime = eventTime[0];
    var places = await EventApi().fetchEventPlacesBySelectedTime();
    ticketState.setSelectedPlace = places[0];
    var halls = await EventApi().fetchEventHallsBySelectedPlaceIdEventId();
    ticketState.setSelectedHall = halls[0];
  }

  @override
  Widget build(BuildContext context) {
    currentLang = Get.locale!.languageCode;
    setupInitialState();

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        clipBehavior: Clip.none,
        children: [
          SingleChildScrollView(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                LiveMusicConcertHeader(
                  event: widget.eventModel,
                  currentLang: currentLang,
                ),
                const SizedBox(height: defaultSizedBoxHeight),
                _buildBody(),
                const SizedBox(height: defaultSizedBoxHeight * 5),
              ])),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: GetBuilder<TicketState>(builder: (_) {
        var selectedHall = _.getSelectedHall;
        return selectedHall == null
            ? const SizedBox(
                child: Center(child: CircularProgressIndicator()),
              )
            : BottomSubmitButton(
                onPressed: () {
                  Get.to(() => BuyTicket(
                        event: widget.eventModel,
                      ));
                },
              );
      }),
    );
  }

  void setupInitialState() {
    ticketState.selectedDate = widget.eventModel.startTime;

    ticketState.setSelectedEvent = widget.eventModel;
  }

  Widget _buildBody() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _getLocalizedDescription(),
            style: const TextStyle(
              fontSize: descriptionTextSize,
              fontWeight: FontWeight.normal,
            ),
          ),
          const SizedBox(height: defaultSizedBoxHeight),
          SizedBox(
            height: mapCardHeight,
            child: ClipRRect(
              borderRadius: const BorderRadius.all(
                Radius.circular(defaultPadding),
              ),
              child: MapCard(
                geoPoint: widget.eventModel.places[0].geoPoint,
                onTap: () {
                  Get.to(() => PlaceLocation(
                        eventModel: widget.eventModel,
                      ));
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getLocalizedDescription() {
    switch (currentLang) {
      case 'en':
        return widget.eventModel.show.description.textEn;
      case 'ar':
        return widget.eventModel.show.description.textAr;
      case 'kr':
        return widget.eventModel.show.description.textKr;
      default:
        return widget.eventModel.show.description.textEn; // default language
    }
  }
}
