import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/api/events_api.dart';
import '../../components/cards/map_card.dart';
import '../../models/event_model.dart';
import '../../states/ticket_state.dart';
import '../buy_ticket.dart/seat_selection_screen.dart';
import '../place location/place_location.dart';
import 'components/buy_ticket_button.dart';
import 'components/live_music_concert_header.dart';

class EventLiveMusicDetails extends StatefulWidget {
  final EventModel eventModel;

  const EventLiveMusicDetails({super.key, required this.eventModel});

  @override
  State<EventLiveMusicDetails> createState() => _EventLiveMusicDetailsState();
}

class _EventLiveMusicDetailsState extends State<EventLiveMusicDetails> {
  final TicketState ticketState = Get.find<TicketState>();

  String currentLang = Get.locale!.languageCode;

  @override
  void initState() {
    init();
    super.initState();
  }

  init() async {
    ticketState.setSelectedEvent = widget.eventModel;
    var eventTime =
        await EventApi().fetchEventTimes(eventId: widget.eventModel.id);
    ticketState.setSelectedEventTime = eventTime[0];
    var places = await EventApi().fetchEventPlacesBySelectedTime();
    ticketState.setSelectedPlace = places[0];
    var halls = await EventApi().fetchEventHallsBySelectedPlaceIdEventId();
    ticketState.setSelectedHall = halls[0];
  }

  @override
  Widget build(BuildContext context) {
    currentLang = Get.locale!.languageCode;
    return Scaffold(
      body: Stack(
        clipBehavior: Clip.none,
        children: [
          SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                LiveMusicConcertHeader(
                  event: widget.eventModel,
                  currentLang: currentLang,
                ),
                const SizedBox(height: 20),
                _buildBody(),
                const SizedBox(height: 100),
              ],
            ),
          ),
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: GetBuilder<TicketState>(builder: (_) {
        var selectedHall = _.getSelectedHall;
        return selectedHall == null
            ? const SizedBox(
                child: Center(child: CircularProgressIndicator()),
              )
            : BottomSubmitButton(
                onPressed: () {
                  Get.to(() => BuyTicket(
                        event: widget.eventModel,
                      ));
                },
              );
      }),
    );
  }

  void setupInitialState() {
    ticketState.selectedDate = widget.eventModel.startTime;
    // ticketState.setSeatDesignId = eventModel
    //     .eventDatePlaces![0].placesIdWithSelectedSeatId[0].seatDesignId;
    ticketState.setSelectedEvent = widget.eventModel;
  }

  Padding _buildBody() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildEventDescription(),
          const SizedBox(height: 20),
          _buildMapCard(),
        ],
      ),
    );
  }

  Text _buildEventDescription() {
    return Text(
      getEventDescription(),
      style: const TextStyle(fontSize: 15),
    );
  }

  String getEventDescription() {
    switch (currentLang) {
      case 'en':
        return widget.eventModel.show.description.textEn;
      case 'ar':
        return widget.eventModel.show.description.textAr;
      default:
        return widget.eventModel.show.description.textKr;
    }
  }

  SizedBox _buildMapCard() {
    return SizedBox(
      height: Get.height * 0.3,
      child: MapCard(
        geoPoint: widget.eventModel.places[0].geoPoint,
        onTap: () => Get.to(() => PlaceLocation(eventModel: widget.eventModel)),
      ),
    );
  }
}
