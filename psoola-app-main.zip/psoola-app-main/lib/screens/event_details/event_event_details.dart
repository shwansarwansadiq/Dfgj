// ignore_for_file: must_be_immutable

import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/models/event_category_model.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../components/cards/map_card.dart';
import '../../controllers/auth_controller.dart';
import '../../models/event_model.dart';
import '../../states/ticket_state.dart';
import '../../utils/app_function.dart';
import '../buy_ticket.dart/purchase_button.dart';
import '../place details/place_details.dart';
import '../place location/place_location.dart';
import 'components/datetime_section.dart';
import 'components/hall_section.dart';
import 'event_details.dart';

class EventEventsDetail extends StatefulWidget {
  final EventModel eventModel;
  const EventEventsDetail({super.key, required this.eventModel});

  @override
  State<EventEventsDetail> createState() => _EventEventsDetailState();
}

class _EventEventsDetailState extends State<EventEventsDetail> {
  final String currentLang = Get.locale!.languageCode;

  TicketState ticketState = Get.find<TicketState>();
  AuthState authState = Get.find<AuthState>();

  @override
  void initState() {
    ticketState.setSelectedEvent = widget.eventModel;
    super.initState();
  }

  Widget dotWidget(String text) {
    return Text(
      text,
      style: const TextStyle(fontSize: 22, color: Colors.black38, height: 0.7),
    );
  }

  Widget arrowDown() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        dotWidget('.'),
        dotWidget('.'),
        dotWidget('↓'),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        clipBehavior: Clip.none,
        fit: StackFit.expand,
        children: [
          SingleChildScrollView(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                _buildHeader(),
                const SizedBox(height: 20),
                _buildBody(),
                const SizedBox(height: 100),
              ])),
          Positioned(bottom: 0, child: PurchaseButton()),
        ],
      ),
    );
  }

  Padding _buildBody() {
    return Padding(
      padding: const EdgeInsets.only(left: 20, right: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          ReadMoreText(
            currentLang == 'en'
                ? widget.eventModel.show.description.textEn
                : currentLang == 'ar'
                    ? widget.eventModel.show.description.textAr
                    : widget.eventModel.show.description.textKr,
            trimLines: 3,
            colorClickableText: Theme.of(context).primaryColor,
            trimMode: TrimMode.Length,
            trimCollapsedText: AppTexts.showMore.tr,
            trimExpandedText: AppTexts.showLess.tr,
            style: const TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              10.height,
              Text(AppTexts.buy_ticket.tr,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  )),
              const SizedBox(height: 10),
              Text(AppTexts.please_below_select_date_and_time.tr,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.normal,
                    color: Colors.grey,
                  )),
            ],
          ),
          const SizedBox(height: 20),
          DatetimeSection(
            event: widget.eventModel,
          ),
          // arrowDown(),
          HallSection(
            event: widget.eventModel,
          ),
          20.height,
          SizedBox(
            height: mapCardHeight,
            child: ClipRRect(
              borderRadius: const BorderRadius.all(
                Radius.circular(defaultPadding),
              ),
              child: MapCard(
                geoPoint: widget.eventModel.places[0].geoPoint,
                onTap: () {
                  Get.to(() => PlaceLocation(
                        eventModel: widget.eventModel,
                      ));
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  checkIfTheCardIsSelected(EventCategoryModel categoryModel) {
    if (ticketState.getSelectedEventCategory != null) {
      if (ticketState.getSelectedEventCategory!.time == categoryModel.time &&
          ticketState.getSelectedEventCategory!.name == categoryModel.name) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  List<EventCategoryModel>? getCategoriesBasedOnSelectedDate() {
    if (ticketState.selectedDate != null) {
      // return widget.eventModel.eventCategories!
      //     .where(
      //         (element) => element.time.toDate() == ticketState.selectedDate!)
      //     .toList();
    } else {
      return null;
    }
    return null;
  }

  Container _buildHeader() {
    return Container(
      height: Get.height * 0.5,
      width: double.infinity,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: CachedNetworkImageProvider(widget.eventModel.show.poster),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(children: [
        Container(
          height: Get.height * 0.5,
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.transparent,
                Colors.black,
              ],
            ),
          ),
        ),
        Positioned(
          top: 30,
          left: currentLang == 'en' ? 10 : null,
          right: currentLang == 'ar' || currentLang == 'fa' ? 10 : null,
          child: Container(
            height: 50,
            width: 50,
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.5),
              borderRadius: const BorderRadius.all(
                Radius.circular(25),
              ),
            ),
            child: IconButton(
              onPressed: () {
                Get.back();
              },
              icon: const Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
            ),
          ),
        ),
        Positioned(
          bottom: 20,
          left: currentLang == 'en' ? 20 : null,
          right: currentLang == 'ar' || currentLang == 'fa' ? 20 : null,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                currentLang == 'en'
                    ? widget.eventModel.show.title.textEn
                    : currentLang == 'ar'
                        ? widget.eventModel.show.title.textAr
                        : widget.eventModel.show.title.textKr,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Row(
                children: [
                  const Icon(
                    Icons.location_on,
                    color: Colors.white,
                    size: 15,
                  ),
                  const SizedBox(width: 5),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      AutoSizeText(
                        currentLang == 'en'
                            ? '${widget.eventModel.places[0].location.province.name.textEn} - ${widget.eventModel.places[0].location.district.name.textEn}'
                            : currentLang == 'ar'
                                ? '${widget.eventModel.places[0].location.province.name.textAr} - ${widget.eventModel.places[0].location.district.name.textAr}'
                                : '${widget.eventModel.places[0].location.province.name.textKr} - ${widget.eventModel.places[0].location.district.name.textKr}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(width: 5),
                      SizedBox(
                        height: 40,
                        child: TextButton(
                          onPressed: () {
                            Get.to(() =>
                                PlaceDetails(eventModel: widget.eventModel));
                          },
                          child: Text(
                            currentLang == 'en'
                                ? widget.eventModel.places[0].title.textEn
                                : currentLang == 'ar'
                                    ? widget.eventModel.places[0].title.textAr
                                    : widget.eventModel.places[0].title.textKr,
                            style: const TextStyle(
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  const Icon(
                    Icons.calendar_today,
                    color: Colors.white,
                    size: 15,
                  ),
                  const SizedBox(width: 5),
                  Row(
                    children: [
                      Text("${AppTexts.startDate.tr}: ",
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                          )),
                      Text(
                        '${widget.eventModel.startTime.day} /${widget.eventModel.startTime.month}/ ${widget.eventModel.startTime.year}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  const Icon(
                    Icons.timer_outlined,
                    color: Colors.white,
                    size: 15,
                  ),
                  const SizedBox(width: 5),
                  Text("${AppTexts.time.tr}:",
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                      )),
                  const SizedBox(width: 5),
                  Text(
                    AppFunction.convertTimestampToTimeWithAmPm(
                            Timestamp.fromDate(widget.eventModel.startTime))
                        .toString(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ]),
    );
  }
}
