import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/components/seat/controller/seat_widget_controller.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/screens/event_details/event_concert.dart';
import 'package:psoola/screens/event_details/event_event_details.dart';
import 'package:psoola/screens/event_details/movie%20event%20details/event_movie.dart';
import 'package:psoola/states/event_selection_controller.dart';
import 'package:psoola/states/ticket_state.dart';

import '../../models/event_model.dart';
import 'event_live_music.dart';
import 'event_theatre.dart';

const double defaultPadding = 20.0;
const double defaultSizedBoxHeight = 20.0;
const double mapCardHeight = 200.0;
const double descriptionTextSize = 15.0;

class EventDetails extends StatefulWidget {
  final EventModel eventModel;
  const EventDetails({super.key, required this.eventModel});

  @override
  State<EventDetails> createState() => _EventDetailsState();
}

class _EventDetailsState extends State<EventDetails>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  TicketState ticketState = Get.find<TicketState>();
  EventSelectionController eventSelectionController =
      Get.find<EventSelectionController>();
  SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();

  @override
  void initState() {
    ticketState.resetStateForNewOpenedEvent();
    eventSelectionController.resetStateForNewOpenedEvent();
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    init();
  }

  Future<void> init() async {}

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    switch (widget.eventModel.show.type) {
      case EventType.MOVIE:
        return EventMovieDetails(eventModel: widget.eventModel);
      case EventType.THEATER:
        return EventTheatreDetails(eventModel: widget.eventModel);
      case EventType.CONCERT:
        return EventConcertDetails(eventModel: widget.eventModel);
      case EventType.LIVEMUSIC:
        return EventLiveMusicDetails(eventModel: widget.eventModel);

      case EventType.EVENT:
        return EventEventsDetail(eventModel: widget.eventModel);
      default:
        return EventMovieDetails(eventModel: widget.eventModel);
    }
  }
}
