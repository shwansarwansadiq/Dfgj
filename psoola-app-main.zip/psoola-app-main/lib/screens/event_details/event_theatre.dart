import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/api/cast_api.dart';
import 'package:psoola/api/event_event_api.dart';
import 'package:psoola/utils/app_texts.dart';

import '../../components/buttons/back_button.dart';
import '../../models/event_model.dart';
import '../../models/show_model.dart';
import '../../states/cast_state.dart';
import '../../states/ticket_state.dart';
import '../buy_ticket.dart/seat_selection_screen.dart';
import 'components/buy_ticket_button.dart';
import 'components/datetime_section.dart';
import 'components/event_top_bar.dart';
import 'components/movie_theater_header.dart';

class EventTheatreDetails extends StatefulWidget {
  final EventModel eventModel;
  const EventTheatreDetails({super.key, required this.eventModel});

  @override
  State<EventTheatreDetails> createState() => _EventTheatreDetailsState();
}

class _EventTheatreDetailsState extends State<EventTheatreDetails>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  TicketState ticketState = Get.find<TicketState>();
  @override
  void initState() {
    EventApi().fetchEventDateTime(widget.eventModel.id);
    fetchCastApi(showId: widget.eventModel.show.id);
    ticketState.setSelectedEvent = widget.eventModel;
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    init();
  }

  Future<void> init() async {}

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: GetBuilder<TicketState>(builder: (_) {
          var selectedHall = _.getSelectedHall;
          return selectedHall == null
              ? const SizedBox()
              : BottomSubmitButton(
                  onPressed: () {
                    Get.to(() => BuyTicket(
                          event: widget.eventModel,
                        ));
                  },
                );
        }),
        body: Stack(children: [
          NestedScrollView(
            headerSliverBuilder: (context, value) {
              return [
                SliverAppBar(
                    // automaticallyImplyLeading: false,
                    leading: Container(
                      padding: const EdgeInsets.all(4),
                      child: CustomBackButton(
                        onPressed: () {
                          Get.back();
                        },
                      ),
                    ),
                    scrolledUnderElevation: 4,
                    pinned: true,
                    snap: false,
                    floating: false,
                    backgroundColor: Get.theme.primaryColor,
                    expandedHeight: Get.height * 0.4,
                    flexibleSpace: FlexibleSpaceBar(
                      background: MovieTheaterHeader(event: widget.eventModel),
                    )),
                SliverToBoxAdapter(
                    child: EventTopBar(
                  tabController: _tabController,
                )),
              ];
            },
            body: TabBarView(
              controller: _tabController,
              children: [
                _buyTicketTab(),
                Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Text(widget.eventModel.show.description.textAr)),
                _castTab()
              ],
            ),
          ),
        ]));
  }

  Column _buyTicketTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              10.height,
              Text(AppTexts.buy_ticket.tr,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  )),
              const SizedBox(height: 10),
              Text(AppTexts.please_below_select_date_and_time.tr,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.normal,
                    color: Colors.grey,
                  )),
              const SizedBox(height: 10),
            ],
          ),
        ),
        DatetimeSection(
          event: widget.eventModel,
        ),
      ],
    );
  }

  Widget _castTab() {
    return GetBuilder<CastsState>(
      builder: (state) {
        List<CastModel> cast = state.getCasts;
        return cast.isNotEmpty
            ? Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    Text(AppTexts.cast.tr,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        )),
                    ListView.separated(
                      separatorBuilder: (context, index) => const SizedBox(
                        height: 20,
                      ),
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: cast.length,
                      itemBuilder: (context, index) {
                        return Row(
                          children: [
                            Container(
                              height: 50,
                              width: 50,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(25),
                                image: DecorationImage(
                                  image: CachedNetworkImageProvider(
                                      cast[index].image),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  cast[index].name,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  cast[index].role,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.normal,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        );
                      },
                    )
                  ],
                ),
              )
            : Center(
                child: Text(AppTexts.noCastInformationHasBeenFound.tr),
              );
      },
    );
  }
}
