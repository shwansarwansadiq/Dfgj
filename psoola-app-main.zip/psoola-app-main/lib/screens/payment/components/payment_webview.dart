import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../../success_purchase.dart';

class PaymentWebview extends StatefulWidget {
  const PaymentWebview({Key? key, required this.url}) : super(key: key);
  final String url;
  @override
  PaymentWebviewState createState() => PaymentWebviewState();
}

class PaymentWebviewState extends State<PaymentWebview> {
  StreamSubscription? stream;
  late WebViewController controller;

  @override
  void initState() {
    init();
    super.initState();
    // Enable virtual display.
  }

  init() {
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading bar.
          },
          onPageStarted: (String url) {
            if (url.contains('success')) {
              print('URL contains "success"');
              // navigate to tickets
              Get.to(() => SuccessPurchase());
            }
          },
          onPageFinished: (String url) {},
          onWebResourceError: (WebResourceError error) {},
          // onNavigationRequest: (NavigationRequest request) {
          //   if (request.url
          //       .startsWith('https://www.youtube.com/')) {
          //     return NavigationDecision.prevent;
          //   }
          //   return NavigationDecision.navigate;
          // },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  void dispose() {
    if (stream != null) {
      stream!.cancel();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Payment'),
        ),
        body: SizedBox(
          width: Get.width,
          height: Get.height,
          child: WebViewWidget(
            controller: controller,
          ),
        ));
  }
}
