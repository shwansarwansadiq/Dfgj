import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../models/payment_method.dart';
import '../../utils/app_texts.dart';
import 'secret_card_number.dart';
import 'select_phone_page.dart';

class SelectBalanceMethod extends StatefulWidget {
  final PaymentMethodModel paymentMethodModel;
  const SelectBalanceMethod({Key? key, required this.paymentMethodModel})
      : super(key: key);
  @override
  State<SelectBalanceMethod> createState() => _SelectBalanceMethodState();
}

class _SelectBalanceMethodState extends State<SelectBalanceMethod> {
  List<String> methods = [
    AppTexts.send_balance,
    AppTexts.send_card,
  ];

  String selectedMethod = "send_balance";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('پڕکردنەوەی باڵانس'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('هەڵبژاردنی شێوازی پارەدان',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(
            height: 10,
          ),
          const Text("هەڵبژاردنی شێوازی پارەدان"),
          const SizedBox(height: 10),
          //radio buttons
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (int i = 0; i < methods.length; i++)
                Column(
                  children: [
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Radio(
                          value: methods[i],
                          groupValue: selectedMethod,
                          onChanged: (value) {
                            setState(() {
                              selectedMethod = value.toString();

                              if (selectedMethod == AppTexts.send_balance) {
                                Navigator.push(context, CupertinoPageRoute(
                                    builder: (BuildContext ctx) {
                                  return SelectPhoneNumberPage(
                                    paymentMethodModel:
                                        widget.paymentMethodModel,
                                  );
                                }));
                              } else {
                                Navigator.push(context, CupertinoPageRoute(
                                    builder: (BuildContext ctx) {
                                  return SecretCardNumber(
                                    paymentMethodModel:
                                        widget.paymentMethodModel,
                                  );
                                }));
                              }
                            });
                          },
                        ),
                        Text(
                          methods[i],
                          style: TextStyle(
                              fontSize: 18,
                              color: selectedMethod == methods[i]
                                  ? Theme.of(context).primaryColor
                                  : Colors.grey),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                  ],
                ),
            ],
          ),
        ]),
      ),
    );
  }
}
