import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/controllers/auth_controller.dart';

import '../../models/payment_method.dart';
import '../../utils/app_texts.dart';

class SecretCardNumber extends StatefulWidget {
  final PaymentMethodModel paymentMethodModel;
  const SecretCardNumber({Key? key, required this.paymentMethodModel})
      : super(key: key);
  @override
  State<SecretCardNumber> createState() => _SecretCardNumberState();
}

class _SecretCardNumberState extends State<SecretCardNumber> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  TextEditingController mycontrollerPhone = TextEditingController();

  String selectedAccount = "My account number";
  AuthState authState = Get.find<AuthState>();

  @override
  void initState() {
    mycontrollerPhone.text = authState.user.value.phonenumber!;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(FocusNode());
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Balance Recharge'),
        ),
        body: Padding(
          padding: EdgeInsets.all(size.width * 0.05),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(AppTexts.card_number,
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
            const SizedBox(
              height: 10,
            ),
            const Text(AppTexts.PleaseBelowWriteSecretCardNumber),
            const SizedBox(height: 10),
            //radio buttons

            Form(
              key: _formKey,
              child: Column(
                children: [
                  SizedBox(
                    height: 60,
                    child: TextFormField(
                      keyboardType: TextInputType.number,
                      controller: mycontrollerPhone,
                      decoration: InputDecoration(
                        labelText: AppTexts.card_number,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                      validator: (String? value) {
                        if (value!.isEmpty) {
                          return 'Please enter some text';
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
            Center(
              child: SizedBox(
                height: 60,
                width: size.width,
                child: ElevatedButton(
                    onPressed: () {},
                    child: Text(AppTexts.confirm.tr,
                        style: const TextStyle(
                            fontSize: 20, color: Colors.white))),
              ),
            ),
            const Spacer(),
          ]),
        ),
      ),
    );
  }
}
