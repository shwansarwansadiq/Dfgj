import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../models/payment_method.dart';
import 'select_balance_method.dart';

class BalanceRechargePage extends StatefulWidget {
  final PaymentMethodModel paymentMethodModel;
  const BalanceRechargePage({Key? key, required this.paymentMethodModel})
      : super(key: key);
  @override
  State<BalanceRechargePage> createState() => _BalanceRechargePageState();
}

class _BalanceRechargePageState extends State<BalanceRechargePage> {
  List<int> prices = [
    10000,
    20000,
    30000,
    40000,
    50000,
  ];

  final TextEditingController mycontrollerPhone = TextEditingController();

  var formatter = NumberFormat('#,##,000');
  int selectedPrice = 10000;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Balance Recharge'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('هەڵبژاردنی بڕی پارە',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(
            height: 10,
          ),
          const Text("تکایە بڕی پارەکە هەڵبژێرە"),
          const SizedBox(height: 10),
          //radio buttons
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (int i = 0; i < prices.length; i++)
                Column(
                  children: [
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Radio(
                          value: prices[i],
                          groupValue: selectedPrice,
                          onChanged: (value) {
                            setState(() {
                              selectedPrice = value as int;
                              Navigator.push(context, CupertinoPageRoute(
                                  builder: (BuildContext ctx) {
                                return SelectBalanceMethod(
                                  paymentMethodModel: widget.paymentMethodModel,
                                );
                              }));
                            });
                          },
                        ),
                        Text(
                          "${formatter.format(prices[i])} IQD",
                          style: TextStyle(
                              fontSize: 18,
                              color: selectedPrice == prices[i]
                                  ? Theme.of(context).primaryColor
                                  : Colors.grey),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                  ],
                ),
            ],
          ),
        ]),
      ),
    );
  }
}
