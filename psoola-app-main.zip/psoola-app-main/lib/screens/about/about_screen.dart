// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:line_icons/line_icons.dart';
import 'package:psoola/utils/app_commons.dart';
import 'package:psoola/utils/app_texts.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../api/about_us_api.dart';
import '../../states/about_us_state.dart';
import '../../utils/app_image.dart';

class AboutScreen extends StatefulWidget {
  const AboutScreen({Key? key}) : super(key: key);

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> {
  AboutUsState aboutUsState = Get.find<AboutUsState>();
  String currentLange = Get.locale!.languageCode;

  @override
  Widget build(BuildContext context) {
    fetchAboutUsApi();
    fetchStaffApi();
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        title: Text(
          'about_us'.tr,
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            GetBuilder<AboutUsState>(
              builder: (_) => _.getAboutUs != null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 50),
                        SizedBox(
                          height: Get.height * 0.2,
                          width: Get.width * 0.5,
                          child: Image.asset(
                            AppImage.logo,
                            fit: BoxFit.contain,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          'about_us'.tr,
                          style: const TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Text(
                            currentLange == 'en'
                                ? _.getAboutUs!.descriptionEn
                                : currentLange == 'ar'
                                    ? _.getAboutUs!.descriptionAr
                                    : _.getAboutUs!.descriptionKrd,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              letterSpacing: 1,
                              fontSize: 15,
                              fontWeight: FontWeight.normal,
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const SizedBox(
                              height: 29,
                            ),
                            Center(
                              child: Text(
                                AppTexts.reachUs.tr,
                                style: const TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Center(
                              child: Text(
                                  AppTexts
                                      .pleaseFeelFreeToContactUsAtAnyTime.tr,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontSize: 17,
                                    fontWeight: FontWeight.normal,
                                  )),
                            ),
                            const SizedBox(
                              height: 40,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Wrap(
                                      direction: Axis.horizontal,
                                      alignment: WrapAlignment.center,
                                      children: [
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        TextButton(
                                          onPressed: () {
                                            launch(
                                              _.getAboutUs!.facebook,
                                            );
                                          },
                                          child: Row(
                                            children: [
                                              const Icon(
                                                LineIcons.facebook,
                                                color: Colors.grey,
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                "facebook".tr,
                                                style: const TextStyle(
                                                  fontSize: 15,
                                                  color: Colors.grey,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        TextButton(
                                          onPressed: () {
                                            launch(
                                              _.getAboutUs!.instagram,
                                            );
                                          },
                                          child: Row(
                                            children: [
                                              const Icon(
                                                LineIcons.instagram,
                                                color: Colors.grey,
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                "instagram".tr,
                                                style: const TextStyle(
                                                  fontSize: 15,
                                                  color: Colors.grey,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        TextButton(
                                          onPressed: () {
                                            launch(
                                              _.getAboutUs!.youtube,
                                            );
                                          },
                                          child: Row(
                                            children: [
                                              const Icon(
                                                LineIcons.youtube,
                                                color: Colors.grey,
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                "youtube".tr,
                                                style: const TextStyle(
                                                  fontSize: 15,
                                                  color: Colors.grey,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                      ],
                    )
                  : SizedBox(
                      height: Get.height * 0.8,
                      child: Center(
                        child: AppCommons.pssolaLoading(),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
