// ignore_for_file: avoid_print

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:lottie/lottie.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/models/seat_design_model.dart';
import 'package:psoola/screens/place%20location/place_location.dart';
import 'package:psoola/utils/app_defaults.dart';
import 'package:psoola/utils/app_icons.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:screenshot/screenshot.dart';
import 'package:simple_shadow/simple_shadow.dart';
import 'package:widgets_to_image/widgets_to_image.dart';

import '../../api/places_api.dart';
import '../../api/tickets_api.dart';
import '../../models/event_type_model.dart';
import '../../models/ticket_model.dart';
import '../../utils/app_animations.dart';
import '../../utils/app_texts.dart';

class TicketDetails extends StatelessWidget {
  final TicketModel ticketModel;
  TicketDetails({super.key, required this.ticketModel});
  final ScreenshotController screenshotController = ScreenshotController();

  final GlobalKey<ScaffoldState> globalKey = GlobalKey<ScaffoldState>();
  final WidgetsToImageController controller = WidgetsToImageController();

  final String currentLang = Get.locale!.languageCode;
  @override
  Widget build(BuildContext context) {
    print(ticketModel);
    return Scaffold(
      key: globalKey,
      appBar: AppBar(
        title: Text(AppTexts.ticketDetails.tr),
      ),
      body: Screenshot(
        controller: screenshotController,
        child: Stack(children: [
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: SimpleShadow(
              color: Colors.black12,
              child: SvgPicture.asset(
                Theme.of(context).brightness == Brightness.dark ? AppIcons.svg_ticket_dark : AppIcons.svg_ticket_light,
                fit: BoxFit.cover,
                height: Get.height,
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(AppDefaults.radius),
                    child: Image.network(
                      ticketModel.event.show.cover,
                      height: Get.height * 0.2,
                      width: Get.width,
                      fit: BoxFit.cover,
                    ),
                  ),
                  30.width,
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        10.height,
                        MultiLangText(
                          text: ticketModel.event.show.title,
                          style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                        ),
                        // 10.height,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            FutureBuilder(
                                future: fetchPlaceByPlaceIdApi(placeId: ticketModel.placeId),
                                builder: (BuildContext ctx, AsyncSnapshot snap) {
                                  if (snap.connectionState == ConnectionState.waiting) {
                                    return const CircularProgressIndicator();
                                  }
                                  if (snap.hasError) {
                                    return const Text("Error");
                                  }
                                  var place = snap.data;
                                  return MultiLangText(
                                    text: place.title,
                                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                                  );
                                }),
                            GestureDetector(
                              onTap: () {
                                Get.to(PlaceLocation(eventModel: ticketModel.event));
                              },
                              child: Text(
                                "${AppTexts.map.tr}  >",
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                              ),
                            ),
                          ],
                        ),

                        10.height,
                        ticketModel.selectedEventTime != null
                            ? Row(children: [
                                Text(
                                  AppTexts.your_event_time.tr,
                                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                ),
                                5.width,
                                Directionality(
                                  textDirection: TextDirection.ltr,
                                  child: Text(
                                    ticketModel.selectedEventTime.toString(),
                                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                                  ),
                                ),
                              ])
                            : const SizedBox(),

                        10.height,
                        ticketModel.event.showsType == EventType.EVENT
                            ? Column(
                                children: [
                                  Text(
                                    AppTexts.categories.tr,
                                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                  ),
                                  5.height,
                                  MultiLangText(text: ticketModel.category!)
                                ],
                              )
                            : Column(
                                children: [
                                  5.height,
                                  ticketModel.seatName != null && ticketModel.seatName != ''
                                      ? Row(
                                          children: [
                                            Text(
                                              AppTexts.seat.tr,
                                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                            ),
                                            5.width,
                                            Text(ticketModel.seatName!),
                                          ],
                                        )
                                      : const SizedBox(),
                                ],
                              ),
                        20.height,
                        ticketModel.addedSeats! > 0
                            ? Row(
                                children: [
                                  Text(
                                    AppTexts.added_seats.tr,
                                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                  ),
                                  5.width,
                                  Text(ticketModel.addedSeats.toString())
                                ],
                              )
                            : const SizedBox(),
                        30.height,
                        // Text("${AppTexts.purchaseCode.tr}: ${ticketModel.id}",
                        //     style: const TextStyle(
                        //         fontSize: 15, fontWeight: FontWeight.normal)),
                        10.height,
                        qrCode(context),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget tableNameAndChares() {
    return Column(
      children: [Text(AppTexts.seat.tr, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), 5.height, Text(ticketModel.seatId!)],
    );
  }

  Center qrCode(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Stack(children: [
            Container(
              height: 120,
              width: 120,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            QrImageView(
              data: ticketModel.id,
              version: QrVersions.auto,
              size: 120,
              gapless: false,
            ),
          ]),
          downloadButton(context),
        ],
      ),
    );
  }

  Future<Uint8List?> screenShot() async {
    Uint8List? image = await screenshotController.capture();
    return image;
  }

  TextButton downloadButton(BuildContext context) {
    return TextButton(
        onPressed: () async {
          var test1 = await screenShot();
          // File imageFile = await writeCounter(test1!);
          final result = await ImageGallerySaver.saveImage(test1!);

          bool isSaved = result["isSuccess"];

          if (isSaved) {
            showDialog(
                context: context,
                builder: (context) {
                  return SizedBox.shrink(
                    child: AlertDialog(
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Lottie.asset(AppAnimations.downloaded.tr, height: 150, width: 150),
                          Text(AppTexts.fileDownloaded.tr, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                          10.height,
                          Text(
                            '${AppTexts.fileDownloadedTo.tr} ${result["filePath"]}',
                            style: const TextStyle(color: Colors.grey, fontSize: 14),
                          ),
                        ],
                      ),
                    ),
                  );
                });
          } else {
            SizedBox.shrink(
              child: AlertDialog(
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Lottie.asset(AppAnimations.error.tr, height: 150, width: 150),
                    Text(AppTexts.pleaseTryAgain.tr, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    10.height,
                  ],
                ),
              ),
            );
          }

          print('data saved');
        },
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.download,
            ),
            10.width,
            Text(
              AppTexts.download.tr,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.normal),
            ),
          ],
        ));
  }
}

class EventSeat extends StatelessWidget {
  const EventSeat({super.key, required this.hallId, required this.seatId, required this.placeId});
  final String hallId;
  final String seatId;
  final String placeId;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: fetchEventSeatApi(placeId: placeId, seatId: seatId, hallId: hallId),
        builder: (BuildContext ctx, AsyncSnapshot snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const CircularProgressIndicator();
          }
          if (snap.hasError) {
            return const Text("Error");
          }
          SingleSeatModel? seat = snap.data;
          if (seat != null) {
            return Text(
              '${seat.number.rowI}_${seat.number.colI}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            );
          } else {
            return const SizedBox();
          }
        });
  }
}
