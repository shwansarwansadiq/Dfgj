import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/models/event_model.dart';

class PlaceLocation extends StatefulWidget {
  final EventModel eventModel;
  const PlaceLocation({super.key, required this.eventModel});

  @override
  State<PlaceLocation> createState() => _PlaceLocationState();
}

class _PlaceLocationState extends State<PlaceLocation> {
  String currentlang = Get.locale!.languageCode;

  late String _mapStyle;

  @override
  void initState() {
    // request permission

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: MultiLangText(
        text: widget.eventModel.places[0].title,
      )),
      body: SizedBox(
        height: Get.height,
        child: Stack(
          children: [
            GoogleMap(
              myLocationEnabled: true,
              onMapCreated: (controller) => _onMapCreated(controller, context),
              markers: {
                Marker(
                  markerId: const MarkerId('marker'),
                  position: LatLng(
                    widget.eventModel.places[0].geoPoint.latitude,
                    widget.eventModel.places[0].geoPoint.longitude,
                  ),
                ),
              },
              initialCameraPosition: CameraPosition(
                target: LatLng(
                  widget.eventModel.places[0].geoPoint.latitude,
                  widget.eventModel.places[0].geoPoint.longitude,
                ),
                zoom: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _onMapCreated(GoogleMapController controller, BuildContext context) {
    Theme.of(context).brightness == Brightness.light
        ? rootBundle
            .loadString('assets/images/map-light-style.txt')
            .then((string) {
            _mapStyle = string;
            controller.setMapStyle(_mapStyle);
          })
        : rootBundle
            .loadString('assets/images/map-dark-style.txt')
            .then((string) {
            _mapStyle = string;
            controller.setMapStyle(_mapStyle);
          });
  }
}
