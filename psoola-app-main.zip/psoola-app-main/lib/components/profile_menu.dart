import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'dart:math' as math;
import '../utils/app_icons.dart';

class ProfileMenu extends StatelessWidget {
  const ProfileMenu({
    Key? key,
    required this.text,
    required this.icon,
    this.isLottie = false,
    this.press,
  }) : super(key: key);

  final String text, icon;
  final VoidCallback? press;
  final bool isLottie;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(5),
      child: TextButton(
        style: TextButton.styleFrom(
          foregroundColor: Colors.grey.shade800,
          padding: const EdgeInsets.all(20),
        ),
        onPressed: press,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Row(
              children: <Widget>[
                isLottie
                    ? Lottie.asset(
                        icon,
                        height: 22,
                        width: 22,
                        fit: BoxFit.fill,
                      )
                    : SvgPicture.asset(
                        icon,
                        height: 22,
                        color: Colors.grey,
                      ),
                const SizedBox(
                  width: 15,
                ),
              ],
            ),
            Text(text,
                style: const TextStyle(fontSize: 16, color: Colors.grey)),
            const Spacer(),
            Transform(
              alignment: Alignment.center,
              transform: Get.locale == const Locale("en")
                  ? Matrix4.rotationY(math.pi)
                  : Matrix4.rotationY(0),
              child: SvgPicture.asset(
                AppIcons.angleLeft,
                height: 18,
                color: Colors.grey,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
