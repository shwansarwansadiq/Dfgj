import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/text_lang_model.dart';

class MultiLangText extends StatelessWidget {
  final String _currentLang = Get.locale!.languageCode;

  final TextLangModel text;
  final TextStyle? style;
  MultiLangText({Key? key, this.style, required this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      _currentLang == 'ar'
          ? text.textAr
          : _currentLang == 'en'
              ? text.textEn
              : text.textKr,
      style: style,
    );
  }
}

class AutoSizeMultiLangText extends StatelessWidget {
  final String _currentLang = Get.locale!.languageCode;
  final double maxFontSize;
  final double minFontSize;
  final TextLangModel text;
  final TextStyle? style;
  AutoSizeMultiLangText(
      {Key? key,
      this.maxFontSize = 24.0,
      this.minFontSize = 10.0,
      this.style,
      required this.text})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AutoSizeText(
      _currentLang == 'ar'
          ? text.textAr
          : _currentLang == 'en'
              ? text.textEn
              : text.textKr,
      style: style,
      maxFontSize: maxFontSize,
      minFontSize: minFontSize,
    );
  }
}
