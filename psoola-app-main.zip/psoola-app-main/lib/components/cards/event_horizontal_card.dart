import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/components/network_image.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/screens/event_details/event_details.dart';

class EventCardHorizontal extends StatelessWidget {
  final EventModel event;
  EventCardHorizontal({
    required this.event,
    Key? key,
  }) : super(key: key);

  final String currentLang = Get.locale!.languageCode;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () {
          Get.to(() => EventDetails(eventModel: event));
        },
        child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(30),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 10,
                  offset: Offset(0, 5),
                ),
              ],
            ),
            margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            child: Material(
              color: Theme.of(context).cardColor,
              shadowColor: Colors.black12,
              clipBehavior: Clip.antiAliasWithSaveLayer,
              borderOnForeground: false,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(23),
              ),
              child: InkWell(
                onTap: () {
                  Get.to(() => EventDetails(eventModel: event));
                },
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ClipRRect(
                        borderRadius:
                            const BorderRadius.all(Radius.circular(23)),
                        child: SizedBox(
                          height: 120,
                          width: 100,
                          child: NetworkImageWithLoader(
                            event.show.poster,
                            fit: BoxFit.cover,
                          ),
                        )),
                    8.width,
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 8),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: Get.width * 0.5,
                              child: AutoSizeText(
                                currentLang == 'en'
                                    ? event.show.title.textEn
                                    : currentLang == 'ar'
                                        ? event.show.title.textAr
                                        : event.show.title.textKr,
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                                maxFontSize: 18,
                                minFontSize: 16,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            4.height,
                            event.show.type != EventType.MOVIE
                                ? SizedBox(
                                    width: Get.width * 0.5,
                                    child: AutoSizeMultiLangText(
                                      text: event
                                          .places[0].location.province.name,
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.normal,
                                      ),
                                      maxFontSize: 14,
                                      minFontSize: 12,
                                    ),
                                  )
                                : Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(
                                        IconlyBold.star,
                                        color: Colors.amber,
                                        size: 20,
                                      ),
                                      4.width,
                                      SizedBox(
                                        child: AutoSizeText(
                                          event.totalReview.averageRating
                                              .toDouble()
                                              .toString(),
                                          maxFontSize: 12,
                                          minFontSize: 10,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      SizedBox(
                                        child: AutoSizeText(
                                          ' (${event.totalReview.totalReview} ${"reviews".tr})',
                                          maxFontSize: 12,
                                          minFontSize: 10,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),

                            10.height,
                            // Row(
                            //   crossAxisAlignment: CrossAxisAlignment.center,
                            //   children: [
                            //     const Icon(
                            //       IconlyBold.star,
                            //       color: Colors.amber,
                            //       size: 20,
                            //     ),
                            //     4.width,
                            //     SizedBox(
                            //       width: Get.width * 0.06,
                            //       child: const AutoSizeText(
                            //         "10",
                            //         maxFontSize: 12,
                            //         minFontSize: 10,
                            //         maxLines: 1,
                            //         overflow: TextOverflow.ellipsis,
                            //       ),
                            //     ),
                            //     SizedBox(
                            //       width: Get.width * 0.4,
                            //       child: AutoSizeText(
                            //         ' 16${"reviews".tr})',
                            //         maxFontSize: 12,
                            //         minFontSize: 10,
                            //         maxLines: 1,
                            //         overflow: TextOverflow.ellipsis,
                            //       ),
                            //     ),
                            //   ],
                            // ),
                          ]),
                    ),
                  ],
                ),
              ),
            )));
  }
}
