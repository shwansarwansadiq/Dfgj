import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_iconly/flutter_iconly.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/models/event_type_model.dart';

import '../../models/event_model.dart';
import '../../screens/event_details/event_details.dart';
import '../../utils/app_constants.dart';

class EventHomeCard extends StatelessWidget {
  final EventModel event;

  EventHomeCard({Key? key, required this.event}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(horizontal: AppConstants.kDefaultPadding),
      child: buildCardWidget(context),
    );
  }

  String currentLang = Get.locale!.languageCode;

  Column buildCardWidget(BuildContext context) {
    return Column(
      children: <Widget>[
        GestureDetector(
          onTap: () {
            Get.to(() => EventDetails(eventModel: event));
          },
          child: Stack(
            children: [
              Hero(
                tag: event.id,
                flightShuttleBuilder: (flightContext, animation, direction,
                    fromContext, toContext) {
                  if (direction == HeroFlightDirection.push) {
                    return Container(
                      height: 210,
                      width: 150,
                      decoration: BoxDecoration(
                          color: Colors.black,
                          image: DecorationImage(
                              image:
                                  CachedNetworkImageProvider(event.show.poster),
                              fit: BoxFit.cover),
                          borderRadius: BorderRadius.circular(30)),
                    );
                  } else {
                    return Container(
                      height: 350,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: const [AppConstants.kDefaultShadow],
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: CachedNetworkImageProvider(event.show.poster),
                        ),
                      ),
                    );
                  }
                },
                // transitionOnUserGestures: true,
                child: Container(
                  height: 350,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: const [AppConstants.kDefaultShadow],
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: NetworkImage(event.show.poster),
                    ),
                  ),
                ),
              ),
              Container(
                height: 350,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(30),
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      Colors.black.withOpacity(0.5),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                right: 0,
                left: 0,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: AppConstants.kDefaultPadding),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: Get.width * 0.8,
                        child: AutoSizeText(
                          currentLang == 'en'
                              ? event.show.title.textEn
                              : currentLang == 'ar'
                                  ? event.show.title.textAr
                                  : event.show.title.textKr,
                          maxLines: 2,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(height: AppConstants.kDefaultPadding / 3),
                      event.show.type == EventType.MOVIE
                          ? Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  IconlyBold.star,
                                  color: Colors.amber,
                                  size: 20,
                                ),
                                4.width,
                                SizedBox(
                                  child: AutoSizeText(
                                    event.totalReview.averageRating
                                        .toDouble()
                                        .toString(),
                                    maxFontSize: 12,
                                    minFontSize: 10,
                                    maxLines: 1,
                                    style: const TextStyle(
                                      color: Colors.white,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                SizedBox(
                                  child: AutoSizeText(
                                    ' (${event.totalReview.totalReview} ${"reviews".tr})',
                                    maxFontSize: 12,
                                    minFontSize: 10,
                                    style: const TextStyle(
                                      color: Colors.white,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            )
                          : SizedBox(
                              width: Get.width * 0.8,
                              child: AutoSizeMultiLangText(
                                text: event.places[0].location.province.name,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.normal,
                                ),
                              ),
                            ),
                      const SizedBox(height: AppConstants.kDefaultPadding),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
