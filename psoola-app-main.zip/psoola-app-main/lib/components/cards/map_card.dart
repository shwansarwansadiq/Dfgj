import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shimmer/shimmer.dart';

class MapCard extends StatefulWidget {
  final GeoPoint geoPoint;
  final Function onTap;
  const MapCard({
    Key? key,
    required this.geoPoint,
    required this.onTap,
  }) : super(key: key);

  @override
  State<MapCard> createState() => _MapCardState();
}

class _MapCardState extends State<MapCard> {
  late String _mapStyle;

  bool isLoaded = false;

  @override
  void initState() {
    requestPermission();

    super.initState();
  }

  requestPermission() async {
    await Permission.location.request();
    setState(() {
      isLoaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: !isLoaded
          ? Shimmer.fromColors(
              baseColor: Colors.grey[300]!,
              highlightColor: Colors.grey[100]!,
              child: Container(
                color: Colors.grey[300],
              ),
            )
          : Stack(
              children: [
                IgnorePointer(
                  child: GoogleMap(
                    compassEnabled: true,
                    onMapCreated: (controller) =>
                        _onMapCreated(controller, context),
                    markers: {
                      Marker(
                          position: LatLng(widget.geoPoint.latitude,
                              widget.geoPoint.longitude),
                          icon: BitmapDescriptor.defaultMarker,
                          markerId: const MarkerId("1"))
                    },
                    myLocationEnabled: true,
                    myLocationButtonEnabled: false,
                    tiltGesturesEnabled: false,
                    zoomGesturesEnabled: false,
                    mapToolbarEnabled: false,
                    mapType: MapType.normal,
                    buildingsEnabled: false,
                    indoorViewEnabled: false,
                    zoomControlsEnabled: false,
                    initialCameraPosition: CameraPosition(
                      target: LatLng(
                          widget.geoPoint.latitude, widget.geoPoint.longitude),
                      zoom: 15,
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  left: 0,
                  top: 0,
                  child: GestureDetector(
                      child: Container(
                        color: Colors.transparent,
                        height: 200,
                      ),
                      onTap: () {
                        widget.onTap();
                      }),
                )
              ],
            ),
    );
  }

  void _onMapCreated(GoogleMapController controller, BuildContext context) {
    Theme.of(context).brightness == Brightness.light
        ? rootBundle
            .loadString('assets/images/map-light-style.txt')
            .then((string) {
            _mapStyle = string;
            controller.setMapStyle(_mapStyle);
          })
        : rootBundle
            .loadString('assets/images/map-dark-style.txt')
            .then((string) {
            _mapStyle = string;
            controller.setMapStyle(_mapStyle);
          });
  }
}
