import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:psoola/models/ticket_model.dart';
import 'package:simple_shadow/simple_shadow.dart';

import '../../screens/ticket_details/ticket_details.dart';
import '../../utils/app_image.dart';
import 'dart:math' as math;

import '../../utils/app_texts.dart';

class TicketCard extends StatelessWidget {
  const TicketCard({
    Key? key,
    required this.currentLang,
    required this.ticket,
  }) : super(key: key);

  final String currentLang;
  final TicketModel ticket;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Get.to(() => TicketDetails(
              ticketModel: ticket,
            ));
      },
      child: Stack(alignment: Alignment.center, children: [
        SimpleShadow(
          opacity: 0.5,
          color: Colors.black.withOpacity(0.1),
          offset: const Offset(0, 5),
          sigma: 7,
          child: Transform(
            alignment: Alignment.center,
            transform: currentLang == 'en'
                ? Matrix4.rotationY(math.pi)
                : Matrix4.rotationY(0),
            child: SvgPicture.asset(
              Get.theme.brightness == Brightness.dark
                  ? AppImage.ticketDarkSvg
                  : AppImage.ticketSvg,
              width: Get.width,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: CachedNetworkImage(
                  imageUrl: ticket.event.show.poster,
                  height: 100,
                  width: 100,
                  fit: BoxFit.cover,
                ),
              ),
              10.width,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  SizedBox(
                    width: Get.width * 0.3,
                    child: AutoSizeText(
                      currentLang == 'en'
                          ? ticket.event.show.title.textEn
                          : currentLang == 'ar'
                              ? ticket.event.show.title.textAr
                              : ticket.event.show.title.textKr,
                      maxLines: 2,
                      maxFontSize: 20,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  5.height,
                  MultiLangText(
                    text: ticket.event.places[0].location.province.name,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w500),
                  ).onTap(() {}),
                  10.height,
                  Text(AppTexts.ticketDetails.tr,
                      style: primaryTextStyle(
                          size: 14, color: Theme.of(context).primaryColor)),
                ],
              )
            ],
          ),
        ),
      ]),
    );
  }
}
