import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/models/event_category_model.dart';

class EventCategoryCard extends StatelessWidget {
  final EventCategoryModel categoryModel;
  bool isSelected = false;

  EventCategoryCard({
    super.key,
    required this.isSelected,
    required this.categoryModel,
  });

  final String currentLang = Get.locale!.languageCode;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: Get.width * 0.3,
      decoration: BoxDecoration(
        color: isSelected
            ? Theme.of(context).primaryColor
            : Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.black12.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 7,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: Get.width * 0.3,
            child: AutoSizeText(
              categoryModel.name.toString(),
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: isSelected ? Colors.white : Colors.black,
                  fontWeight: FontWeight.bold),
              maxLines: 2,
              maxFontSize: 20,
              minFontSize: 15,
            ),
          ),
          5.height,
          SizedBox(
            width: 80,
            child: AutoSizeText(
              categoryModel.price.toString(),
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: isSelected ? Colors.white : Colors.black,
                  fontWeight: FontWeight.normal),
              maxLines: 1,
              maxFontSize: 20,
              minFontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
