import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';

import '../../screens/all events/all_events.dart';
import '../../models/category_model.dart';
import '../../utils/app_defaults.dart';

class CategoriesCard extends StatelessWidget {
  const CategoriesCard({
    Key? key,
    required this.categoriesListData,
  }) : super(key: key);

  final CategoryModel categoriesListData;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Get.to(() => AllEvents(
              selectedCategory: categoriesListData,
            ));
      },
      child: Container(
        margin: const EdgeInsets.only(right: 10),
        width: 150,
        height: 150,
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.light
              ? Colors.grey[200]
              : Colors.grey[900],
          borderRadius: BorderRadius.circular(AppDefaults.radius),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SvgPicture.asset(
              categoriesListData.icon,
              height: 50,
              width: 50,
              color: Theme.of(context).brightness == Brightness.light
                  ? Colors.grey[800]
                  : Colors.grey,
            ),
            const SizedBox(height: 10),
            MultiLangText(
              text: categoriesListData.title,
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
