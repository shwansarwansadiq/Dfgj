import 'dart:math' as math;

import 'package:auto_size_text/auto_size_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:psoola/components/multi_lang_text_widget.dart';
import 'package:simple_shadow/simple_shadow.dart';

import '../../models/ticket_model.dart';
import '../../utils/app_image.dart';

class ExpiredTicketCard extends StatelessWidget {
  const ExpiredTicketCard({
    Key? key,
    required this.currentLang,
    required this.ticket,
  }) : super(key: key);

  final String currentLang;
  final TicketModel ticket;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Stack(alignment: Alignment.center, children: [
        SimpleShadow(
          opacity: 0.5,
          color: Colors.black.withOpacity(0.1),
          offset: const Offset(0, 5),
          sigma: 7,
          child: Transform(
            alignment: Alignment.center,
            transform: currentLang == 'en'
                ? Matrix4.rotationY(math.pi)
                : Matrix4.rotationY(0),
            child: SvgPicture.asset(
              Get.theme.brightness == Brightness.dark
                  ? AppImage.ticketDarkSvg
                  : AppImage.ticketSvg,
              width: Get.width,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Stack(children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: CachedNetworkImage(
                    imageUrl: ticket.event.show.poster,
                    height: 100,
                    width: 100,
                    fit: BoxFit.cover,
                  ),
                ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Container(
                    height: 100,
                    width: 100,
                    color: Colors.grey.withOpacity(0.1),
                  ),
                ),
              ]),
              10.width,
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                children: [
                  SizedBox(
                    width: Get.width * 0.3,
                    child: AutoSizeText(
                      currentLang == 'en'
                          ? ticket.event.show.title.textEn
                          : currentLang == 'ar'
                              ? ticket.event.show.title.textAr
                              : ticket.event.show.title.textKr,
                      maxLines: 2,
                      maxFontSize: 20,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, color: Colors.grey),
                    ),
                  ),
                  5.height,
                  MultiLangText(
                    text: ticket.event.places[0].location.province.name,
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: Colors.grey),
                  ).onTap(() {}),
                ],
              )
            ],
          ),
        ),
      ]),
    );
  }
}
