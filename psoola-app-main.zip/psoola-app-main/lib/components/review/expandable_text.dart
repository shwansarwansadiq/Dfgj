import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class ExpandableText extends StatefulWidget {
  final String? text;
  final int? trimLines;
  final bool? isExpandByTextTouch;
  final TextStyle? style;

  const ExpandableText({
    this.text,
    Key? key,
    this.style,
    this.trimLines = 2,
    this.isExpandByTextTouch = true,
  })  : assert(text != null),
        super(key: key);

  @override
  ExpandableTextState createState() => ExpandableTextState();
}

class ExpandableTextState extends State<ExpandableText> {
  bool _readMore = true;

  void _onTapLink() {
    setState(() => _readMore = !_readMore);
  }

  @override
  Widget build(BuildContext context) {
    TextSpan link = TextSpan(
//        text: _readMore ? "... read more" : " read less",
        text: _readMore ? 'show_more' : 'show_less',
        style: TextStyle(
//          color: colorClickableText,
            color: Theme.of(context).primaryColor),
        recognizer: TapGestureRecognizer()..onTap = _onTapLink);
    Widget result = LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        assert(constraints.hasBoundedWidth);
        final double maxWidth = constraints.maxWidth;
        // Create a TextSpan with data
        final text = TextSpan(
          text: widget.text,
        );
        // Layout and measure link
        TextPainter textPainter = TextPainter(
          text: link,
          textDirection: TextDirection
              .rtl, //better to pass this from master widget if ltr and rtl both supported
          maxLines: widget.trimLines,
          ellipsis: '...',
        );
        textPainter.layout(minWidth: constraints.minWidth, maxWidth: maxWidth);
        final linkSize = textPainter.size;
        // Layout and measure text
        textPainter.text = text;
        textPainter.layout(minWidth: constraints.minWidth, maxWidth: maxWidth);
        final textSize = textPainter.size;
        // Get the endIndex of data
        int endIndex;
        final pos = textPainter.getPositionForOffset(Offset(
          textSize.width - linkSize.width,
          textSize.height,
        ));
        if (textPainter.getOffsetBefore(pos.offset) != null) {
          endIndex = textPainter.getOffsetBefore(pos.offset)!;
        } else {
          endIndex = pos.offset;
        }

        TextSpan textSpan;
        if (textPainter.didExceedMaxLines) {
          textSpan = TextSpan(
            text: _readMore ? widget.text!.substring(0, endIndex) : widget.text,
            style: widget.style,
            children: <TextSpan>[link],
          );
        } else {
          textSpan = TextSpan(
            text: widget.text,
            style: widget.style ??
                const TextStyle(
                  color: Colors.black,
                ),
          );
        }
        return GestureDetector(
          onTap: widget.isExpandByTextTouch! ? _onTapLink : null,
          child: RichText(
            softWrap: true,
            overflow: TextOverflow.clip,
            text: textSpan,
            textDirection: TextDirection.rtl,
            textAlign: TextAlign.right,
          ),
        );
      },
    );
    return GestureDetector(
        onTap: widget.isExpandByTextTouch! ? _onTapLink : null, child: result);
  }
}
