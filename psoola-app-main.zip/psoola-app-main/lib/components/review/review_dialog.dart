import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../models/review_model.dart';
import '../../utils/app_texts.dart';
import 'custom_rating_bar.dart';
import 'shakeable_widget.dart';

class ReviewDialog extends StatefulWidget {
  final Function onRatingSubmitted;
  final SingleReviewModel? reviewModel;

  const ReviewDialog(
      {Key? key, required this.onRatingSubmitted, required this.reviewModel})
      : super(key: key);

  @override
  State<ReviewDialog> createState() => _ReviewDialogState();
}

class _ReviewDialogState extends State<ReviewDialog> {
  int rating = 0;
  String comment = '';
  FocusNode? commentFocusNode;
  bool isRatingWarning = false;
  bool isCommentWarning = false;
  final TextEditingController _commentController = TextEditingController();

  @override
  void initState() {
    super.initState();
    commentFocusNode = FocusNode();
//    commentFocusNode.addListener(() {
//      setState(() {
//        isCommentWarning = false;
//      });
//    });

    rating = widget.reviewModel == null ? 0 : widget.reviewModel!.star!;
    comment = widget.reviewModel == null ? '' : widget.reviewModel!.comment!;
    if (widget.reviewModel != null) {
      _commentController.text = widget.reviewModel!.comment!;
    }
    _commentController.selection = TextSelection.fromPosition(
        TextPosition(offset: _commentController.text.length));
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      elevation: 0,
      child: _buildContent(context),
    );
  }

  Widget _buildContent(BuildContext context) {
    return SizedBox(
//      padding: EdgeInsets.only(bottom: mediaQuery.viewInsets.bottom + 10),
      height: Get.height * 0.5,
      child: SingleChildScrollView(
        child: Container(
          height: Get.height * 0.5,
          decoration: const BoxDecoration(
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.all(Radius.circular(22))),
          child: Column(
            children: <Widget>[
//               Container(
//                   decoration: BoxDecoration(
//                       shape: BoxShape.rectangle,
//                       borderRadius: const BorderRadius.only(
//                           topRight: Radius.circular(22),
//                           topLeft: Radius.circular(22)),
//                       color: Theme.of(context).primaryColor),
//                   width: double.infinity,
//                   alignment: Alignment.center,
// //              margin: EdgeInsets.all(10),
// //              color: Theme.of(context).colorScheme.secondary,
//                   height: Get.height * 0.05,
//                   child: const Text(
//                     AppTexts.rate,
//                     style: TextStyle(fontSize: 20, color: Colors.white),
//                   )),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          SizedBox(
                              width: double.infinity,
                              child: Text(
                                AppTexts.setStarHere.tr,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                    color: isRatingWarning
                                        ? Colors.red
                                        : Theme.of(context)
                                            .textTheme
                                            .displayLarge!
                                            .color),
                              )),
                          const SizedBox(
                            height: 10,
                          ),
                          _ratingBar,
                        ],
                      ),
                      _commentField,
                      const SizedBox(
                        height: 10,
                      ),
                      _buttons(context),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  rebuild() {
    setState(() {});
  }

  Widget get _ratingBar {
    if (isRatingWarning) {
      return ShakeableWidget(
          child: CustomRatingBar(
        onStarUpdated: _onStarUpdated,
        initialRating: rating.toDouble(),
      ));
    } else {
      return CustomRatingBar(
        onStarUpdated: _onStarUpdated,
        initialRating: rating.toDouble(),
      );
    }
  }

  Widget get _commentField {
    Widget widget;
    if (isCommentWarning) {
      widget = ShakeableWidget(
        key: UniqueKey(),
        onEnd: rebuild,
        child: _commentFieldWidget(true),
      );
    } else {
      widget = _commentFieldWidget(false);
    }
    isCommentWarning = false;
    return widget;
  }

  Widget _commentFieldWidget(bool hasError) {
    Widget commentWidget = Directionality(
      textDirection: TextDirection.rtl,
      child: CupertinoTextField(
        placeholder: AppTexts.writeYourCommentHere.tr,
        placeholderStyle: TextStyle(
            fontSize: 14,
            fontFamily: "shabnam",
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black),
        controller: _commentController,
        padding: const EdgeInsets.all(10),
        textAlign: TextAlign.right,
        decoration: BoxDecoration(
            color: Theme.of(context).scaffoldBackgroundColor,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
                color: hasError ? Colors.red.shade300 : Colors.grey.shade400)),

        maxLines: 15,
        minLines: 5,
        focusNode: commentFocusNode,
        autofocus: rating > 0,
//        onChanged: (value) => setState(() {
//          comment = value;
//        }),
        onChanged: (value) => comment = value,
//        onTap: (){
//          setState(() {
//            isCommentWarning = false;
//            commentFocusNode.requestFocus();
//          });
//        },
      ),
    );

//    if(hasError) commentFocusNode.requestFocus();
    return commentWidget;
  }

  Widget _buttons(context) {
    return Column(
      children: <Widget>[
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          width: double.infinity,
          height: 50,
          child: ElevatedButton(
            onPressed: () => _onRatingSubmitted(context),
            style: ButtonStyle(
                shape: MaterialStateProperty.all(RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18.0),
                )),
                backgroundColor:
                    MaterialStateProperty.all(Theme.of(context).primaryColor)),
            child: Text(
              "add_review".tr,
              style: const TextStyle(color: Colors.white, fontSize: 20),
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          width: double.infinity,
          child: TextButton(
              child: Text(
                'cancel'.tr,
                style: const TextStyle(
                    color: Colors.grey,
                    fontSize: 15,
                    fontWeight: FontWeight.normal),
              ),
              onPressed: () => Get.back()),
        ),
      ],
    );
  }

  _onStarUpdated(double star) {
    rating = star.toInt();
    if (isRatingWarning) {
      setState(() {
        isRatingWarning = false;
      });
    }
    commentFocusNode!.requestFocus();
  }

  _onRatingSubmitted(context) {
    if (rating == 0) {
      setState(() {
        isRatingWarning = true;
      });
      return;
    }

    if (rating < 3 && comment == '') {
      setState(() {
        isCommentWarning = true;
      });
      return;
    }

//    if(comment.trim().length == 0){
//      Utils.showSnackBar(context, 'تکایە ڕای خۆت دەربڕە لە کۆمێنتەکەدا');
//      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
//        content: Text('sdfsd', textAlign: TextAlign.right,),
//      ));
//      return;
//    }

    widget.onRatingSubmitted(context, rating, comment);
    Navigator.pop(context);
  }
}
