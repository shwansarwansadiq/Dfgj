// ignore_for_file: overridden_fields

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:intl/intl.dart' as intl;

import '../../models/review_model.dart';
import '../../utils/app_function.dart';

class ReviewCard extends StatelessWidget {
  final SingleReviewModel singleReviewModel;

  @override
  final Key key = UniqueKey();
  ReviewCard({Key? key, required this.singleReviewModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      child: Column(
        children: <Widget>[
          _userProfile(),
          const SizedBox(height: 12),
          _ratingAndDate(),
          const SizedBox(height: 5),
          _comment(),
        ],
      ),
    );
  }

  Widget _userProfile() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        CircleAvatar(
            backgroundColor:
                AppFunction.getColorBasedOnText(singleReviewModel.name),
            foregroundColor: Colors.white,
            backgroundImage:
                singleReviewModel.image != null && singleReviewModel.image != ''
                    ? NetworkImage(
                        singleReviewModel.image!,
                      )
                    : null,
            radius: 16,
            child:
                singleReviewModel.image == null || singleReviewModel.image == ''
                    ? Text(
                        singleReviewModel.name.substring(0, 1),
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      )
                    : null),
        const SizedBox(
          width: 8,
        ),
        Text(singleReviewModel.name,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _comment() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(3),
      child: Text(
        singleReviewModel.comment!,
        style: const TextStyle(fontSize: 14),
        textAlign: TextAlign.start,
      ),
    );
//    return RichText(
//      softWrap: true,
//      overflow: TextOverflow.clip,
//      text: TextSpan(text: 'هح', style: TextStyle(color: Colors.grey)),
//      textDirection: TextDirection.rtl,
//      textAlign: TextAlign.start,
//    );
  }

  Widget _ratingAndDate() {
    final dateFormat = intl.DateFormat('dd/MM/yyyy');
    final date = dateFormat.format(singleReviewModel.created.toDate());

    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Text(
          date,
          style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
        ),
        const SizedBox(
          width: 8,
        ),
        _rating(singleReviewModel.star),
      ],
    );
  }

  Widget _rating(int star) {
    return RatingBarIndicator(
      rating: star.toDouble(),
      itemBuilder: (context, index) => const Icon(
        Icons.star,
        color: Colors.amber,
      ),
      itemCount: 5,
      itemSize: 15.0,
      unratedColor: Colors.amber.shade100,
    );
  }
}
