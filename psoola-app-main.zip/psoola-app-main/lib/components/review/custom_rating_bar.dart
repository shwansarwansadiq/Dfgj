import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class CustomRatingBar extends StatefulWidget {
  final Function? onStarUpdated;
  final double? initialRating;

  const CustomRatingBar({Key? key, this.onStarUpdated, this.initialRating = 0})
      : super(key: key);

  @override
  State<CustomRatingBar> createState() => _CustomRatingBarState();
}

class _CustomRatingBarState extends State<CustomRatingBar> {
  @override
  Widget build(BuildContext context) {
    return RatingBar(
        initialRating: widget.initialRating!,
        minRating: 1,
        direction: Axis.horizontal,
        allowHalfRating: false,
        itemCount: 5,
        itemPadding: const EdgeInsets.symmetric(horizontal: 2.0),
        // itemBuilder: (context, _) => Icon(
        //       Icons.star,
        //       color: Colors.amber,
        //     ),
        ratingWidget: RatingWidget(
          full: const Icon(
            Icons.star,
            color: Colors.amber,
          ),
          half: const Icon(
            Icons.star_half,
            color: Colors.amber,
          ),
          empty: const Icon(
            Icons.star_border,
            color: Colors.grey,
          ),
        ),
        onRatingUpdate: (rating) {
          widget.onStarUpdated!(rating);
        });
  }
}
