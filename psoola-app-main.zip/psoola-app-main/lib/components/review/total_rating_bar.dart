import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';

import '../../models/review_model.dart';
import '../../utils/app_texts.dart';

class TotalRatingBar extends StatelessWidget {
//  final List<double> ratings = [10, 3, 0, 0, 1];
//  final totalReview = 23;
//  final averageRating = 4.7;
  final TotalReviewModel reviewModel;

  const TotalRatingBar({Key? key, required this.reviewModel}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;

    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        const SizedBox(
          height: 30,
        ),
        Text(
          AppTexts.what_people_say.tr,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(
          height: 30,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            _ratingBars(Colors.amber, screenSize.width),
            _totalRating(),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
      ],
    );
  }

  Widget _ratingBars(color, width) {
//    return Center(child: Text('bars'),);
    return SizedBox(
      width: width * 0.50,
      child: Column(
        children: <Widget>[
          _progressBar(color, width, 5, reviewModel.star5Percent),
          _progressBar(color, width, 4, reviewModel.star4Percent),
          _progressBar(color, width, 3, reviewModel.star3Percent),
          _progressBar(color, width, 2, reviewModel.star2Percent),
          _progressBar(color, width, 1, reviewModel.star1Percent),
        ],
      ),
    );
  }

  Widget _totalRating() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        SizedBox(
          height: 65,
          child: Text(reviewModel.averageRating.toString(),
              style: const TextStyle(
                fontSize: 50,
              )),
        ),
        _star(reviewModel.averageRating),
        SizedBox(
          child: AutoSizeText(
            "${AppTexts.from_sum_of.tr}  ${reviewModel.totalReview} ${AppTexts.people.tr}",
            maxLines: 1,
            minFontSize: 10,
            maxFontSize: 16,
            style: TextStyle(color: Colors.grey.shade600),
          ),
        ),
      ],
    );
  }

  Widget _star(star) {
    return RatingBarIndicator(
      rating: star.toDouble(),
      itemBuilder: (context, index) => const Icon(
        Icons.star,
        color: Colors.amber,
      ),
      itemCount: 5,
      itemSize: 15.0,
      unratedColor: Colors.amber.shade100,
    );
  }

  Widget _progressBar(color, width, star, percent) {
    return SizedBox(
      width: width * 0.50,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Text('$star'),
          const SizedBox(
            width: 5,
          ),
          SizedBox(
            height: 10,
            width: width * 0.30,
            child: Stack(
//              fit: StackFit.expand,
              children: <Widget>[
                Container(
                  decoration: BoxDecoration(
//                    border: Border.all(color: Colors.grey, width: 1),
//                    color: Color.fromRGBO(220, 220, 220, 1),
                    color: Colors.amber.shade100,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                if (percent > 0)
                  FractionallySizedBox(
                    widthFactor: percent / 100,
                    child: Container(
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  )
              ],
            ),
          ),
          const SizedBox(
            width: 5,
          ),
          Text(
            '(${(percent).toStringAsFixed(0)}%)',
            style: const TextStyle(fontSize: 11, color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
