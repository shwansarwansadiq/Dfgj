import 'package:flutter/material.dart';

class ShakeableWidget extends StatefulWidget {
  final Duration? duration;
  final double? deltaX;
  final Widget? child;
  final Curve? curve;
  final Function? onEnd;

  const ShakeableWidget({
    super.key,
    this.duration = const Duration(milliseconds: 500),
    this.deltaX = 20,
    this.curve = Curves.bounceOut,
    this.child,
    this.onEnd,
  });

  @override
  ShakeableWidgetState createState() => ShakeableWidgetState();
}

class ShakeableWidgetState extends State<ShakeableWidget> {
  bool isEnded = false;

  /// convert 0-1 to 0-1-0
  double shake(double animation) =>
      2 * (0.5 - (0.5 - widget.curve!.transform(animation)).abs());

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      onEnd: () {
        setState(() {
          isEnded = true;
        });
        widget.onEnd!();
      },
      key: widget.key,
      tween: Tween(begin: 0.0, end: 1.0),
      duration: widget.duration!,
      builder: (context, animation, child) => Transform.translate(
        offset: Offset(widget.deltaX! * shake(animation), 0),
        child: child,
      ),
      child: widget.child,
    );
  }

//  start() {
//    print('shakeable start()');
//    setState(() {});
//  }
}
