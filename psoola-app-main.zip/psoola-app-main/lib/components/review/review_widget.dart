import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:psoola/utils/app_animations.dart';
import 'package:psoola/utils/app_function.dart';

import '../../api/review_api.dart';
import '../../controllers/auth_controller.dart';
import '../../models/review_model.dart';
import '../../models/user_model.dart';
import '../../utils/app_texts.dart';
import 'review_card.dart';
import 'review_dialog.dart';
import 'total_rating_bar.dart';

class EventReview extends StatefulWidget {
//  final String courseId;
  final UserType userType;
  final String eventId;
  final TotalReviewModel totalReviewModel;

  const EventReview(
      {Key? key,
      required this.userType,
      required this.eventId,
      required this.totalReviewModel})
      : super(key: key);

  @override
  State<EventReview> createState() => _EventReviewState();
}

class _EventReviewState extends State<EventReview> {
  @override
  void initState() {
    super.initState();
  }

  SingleReviewModel? myReviewModel;
  AuthState authState = Get.find<AuthState>();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: fetchMyReviewApi(
            eventId: widget.eventId, userType: widget.userType),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else {
            myReviewModel = snapshot.data;
            return Column(
              children: <Widget>[
                _myReviewWidgetLoader(),
                TotalRatingBar(
                  reviewModel: widget.totalReviewModel,
                ),
                const SizedBox(height: 20),
                _peoplesReviewWidget(),
              ],
            );
          }
        });
  }

  Widget _myReviewWidgetLoader() {
    if (myReviewModel != null) {
      return _myReviewWidget(myReviewModel!);
    } else {
      return const SizedBox();
    }
  }

  Widget _myReviewWidget(SingleReviewModel myReviewModel) {
    return GestureDetector(
      onTap: () => {},
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          const Divider(
            thickness: 0.8,
            endIndent: 20,
            indent: 20,
          ),
          const SizedBox(
            height: 5,
          ),
          Text(
            AppTexts.yourReview.tr,
            style: const TextStyle(
              fontSize: 18,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(
            height: 10,
          ),
          RatingBar(
              initialRating: myReviewModel.star.toDouble(),
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: false,
              itemCount: 5,
              itemSize: 35.0,
              unratedColor: Colors.amber.shade100,
              itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
              ratingWidget: RatingWidget(
                full: const Icon(
                  Icons.star,
                  color: Colors.amber,
                ),
                half: const Icon(
                  Icons.star,
                  color: Colors.amber,
                ),
                empty: Icon(
                  Icons.star,
                  color: Colors.grey.shade400,
                ),
              ),
              onRatingUpdate: (rating) {
                showReviewDialog(context, myReviewModel);
              }),
          const SizedBox(
            height: 5,
          ),
        ],
      ),
    );
  }

  //list of course reviews (star with comment):
  Widget _peoplesReviewWidget() {
    return FutureBuilder(
      future: fetchPeopleReviewsApi(
          eventId: widget.eventId, userType: widget.userType, limit: 3),
      builder: (ctx, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          //when widget is still fetching reviews data:
          return Container(
            alignment: Alignment.center,
            child: const CircularProgressIndicator(),
          );
        } else if (snapshot.hasData) {
          //when there are no reviews yet.
          List<SingleReviewModel> reviews =
              snapshot.data as List<SingleReviewModel>;
          if (reviews.isEmpty) {
            return Container(
              alignment: Alignment.center,
              margin: const EdgeInsets.all(10),
              child: Column(
                key: UniqueKey(),
                children: <Widget>[
                  Text(
                    AppTexts.no_comment_added.tr,
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  _addCommentButton(),
                  const SizedBox(
                    height: 15,
                  ),
                ],
              ),
            );
          } else {
            List<SingleReviewModel> reviewsList =
                snapshot.data as List<SingleReviewModel>;
            List<Widget> reviewsWidgetList = [];
            for (int i = 0; i < reviewsList.length; i++) {
              reviewsWidgetList
                  .add(ReviewCard(singleReviewModel: reviewsList[i]));
            }
            return Column(
              children: <Widget>[
                _addCommentButton(),
                ...reviewsWidgetList,
                const SizedBox(
                  height: 10,
                ),
                if (widget.totalReviewModel.totalReview > 3)
                  Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      alignment: Alignment.centerRight,
                      child: TextButton(
//                  onPressed: () => Navigator.of(context).pushNamed(CourseReviews.routeName),
                          onPressed: () => Container(),
                          child: Row(children: [
                            Text(
                              AppTexts.see_all_review,
                              style: TextStyle(
                                  fontSize: 15,
                                  color: Theme.of(context).primaryColor,
                                  fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(width: 12),
                            const Icon(Icons.arrow_forward_ios, size: 12),
                          ]))),
              ],
            );
          }
        } else {
          return Container(
            alignment: Alignment.center,
            child: const Text('error'),
          );
        }
      },
    );

//    return Column(children: reviewTestList());
  }

  loginToCommentAlert() {
    return AppFunction.showRegisterDialog(context, AppAnimations.comment);
  }

  Widget _addCommentButton() {
    return SizedBox(
      width: Get.width * 0.5,
      child: TextButton(
        onPressed: () {
          authState.user.value.state == UserState.LOGEDIN
              ? showReviewDialog(context, myReviewModel)
              : loginToCommentAlert();
        },
        style: TextButton.styleFrom(
          backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: BorderSide(
              color: Theme.of(context).primaryColor,
              width: 1,
            ),
          ),
        ),
        child: Text(
          myReviewModel != null
              ? AppTexts.edit_your_review.tr
              : AppTexts.add_your_review.tr,
          style: TextStyle(
              fontSize: 15,
              color: Theme.of(context).primaryColorDark,
              fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  showReviewDialog(context, myReview) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return ReviewDialog(
            onRatingSubmitted: (context, rating, comment) =>
                _onRatingSubmitted(context, rating, comment),
            reviewModel: myReview,
          );
        });
  }

  _onRatingSubmitted(context, rating, comment) async {
    bool result = await addReviewApi(
        rating: rating,
        comment: comment,
        eventId: widget.eventId,
        userType: widget.userType);
    if (result) {
      Get.snackbar(
          AppTexts.success.tr, AppTexts.your_review_successfully_added.tr);
      setState(() {});
    }
    try {
      setState(() {});
    } catch (error) {
      debugPrint(error.toString());
    }
  }
}
