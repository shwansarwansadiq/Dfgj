import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:psoola/utils/app_image.dart';
import 'package:psoola/utils/app_texts.dart';
import 'package:url_launcher/url_launcher.dart';

class DevelopedBy extends StatelessWidget {
  const DevelopedBy({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        SvgPicture.asset(
          AppImage.armanLogo,
          height: 50,
          width: 50,
          color: Colors.blue,
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(AppTexts.developedBy.tr,
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.normal)),
            const SizedBox(width: 5),
            GestureDetector(
              onTap: () {
                launchUrl(Uri.parse("https://www.armanhadi.com/"));
              },
              child: Text("Arman".tr,
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.normal,
                      color: Colors.blue)),
            ),
          ],
        ),
      ],
    );
  }
}
