import 'package:flutter/material.dart';

class BottonUpMenu extends StatelessWidget {
  const BottonUpMenu({
    Key? key,
    required this.content,
    required this.title,
  }) : super(key: key);
  final String title;
  final Widget content;

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.background),
        padding: const EdgeInsets.only(
          bottom: 10,
          top: 4,
          left: 10,
          right: 10,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const SizedBox(
              width: 20,
              child: Divider(
                thickness: 3,
              ),
            ),
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 15),
            content
          ],
        ));
  }
}
