import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/models/user_model.dart';
import '../utils/app_texts.dart';
import 'package:circular_profile_avatar/circular_profile_avatar.dart';

class ProfilePic extends StatelessWidget {
  final AuthState authState;
  ProfilePic({
    required this.authState,
    Key? key,
  }) : super(key: key);

  String currentLang = Get.locale!.languageCode;

  @override
  Widget build(BuildContext context) {
    UserModel user = authState.user.value;
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        authState.user.value.name == null
            ? SizedBox(
                child: Icon(
                  Icons.account_circle,
                  color: Colors.grey.shade300,
                  size: 150,
                ),
              )
            : SizedBox(
                height: 120,
                width: 120,
                child: CircularProfileAvatar(
                  "",
                  radius: 80,
                  backgroundColor: Colors.transparent,
                  borderWidth: 10,
                  initialsText: Text(
                    authState.user.value.name!.substring(0, 2).toUpperCase(),
                    style: const TextStyle(fontSize: 33, color: Colors.white),
                  ),
                  borderColor: Colors.brown,
                  elevation: 5.0,
                  foregroundColor: Colors.brown.withOpacity(0.5),
                  cacheImage: true,
                  imageFit: BoxFit.contain,
                  // sets on tap
                  showInitialTextAbovePicture:
                      true, // setting it true will show initials text above profile picture, default false
                ),
              ),
        const SizedBox(height: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              authState.user.value.name == null
                  ? AppTexts.youDonthaveAccount.tr
                  : authState.user.value.name!,
              style: TextStyle(
                  fontSize: 20,
                  color: Theme.of(context).textTheme.displayLarge!.color,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            // Directionality(
            //   textDirection: TextDirection.ltr,
            //   child: Text(
            //     authState.user.value.name == null
            //         ? AppTexts.pleaseLogin.tr
            //         : authState.user.value.userType == "CUSTOMER"
            //             ? authState.user.value.phonenumber!
            //             : authState.user.value.email!,
            //     style: const TextStyle(
            //       fontSize: 14,
            //       color: Colors.grey,
            //     ),
            //   ),
            // ),
            authState.user.value.userType == "PROVIDER" ||
                    authState.user.value.name == null
                ? const SizedBox()
                : SizedBox(
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // SvgPicture.asset(
                        //   AppIcons.dollar,
                        //   height: 15,
                        //   color: Colors.grey,
                        // ),
                        const SizedBox(width: 5),
                        Text(
                          "${AppTexts.balance.tr}: ${user.balance.toString()} IQD",
                          style: const TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
          ],
        ),
        // const Spacer(),
        const SizedBox(
          width: 10,
        ),
      ],
    );
  }
}
