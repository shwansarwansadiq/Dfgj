// ignore_for_file: depend_on_referenced_packages

import '../utils/seat_state.dart';

class SeatModel {
  String? id;
  late int row;
  late int column;
  int? price;
  String? imageUrl;
  late SeatState seatState;
  String? seatName;

  int? addedSeats = 0;

  SeatModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    row = json['row'];
    column = json['column'];
    seatName = json['seat_name'];
    price = json['price'];
    imageUrl = json['image_url'];
    seatState = seatStateFromString(json['seat_state']);
    addedSeats = json['added_seats'] ?? 0;
  }

  SeatModel({this.id, required this.row, required this.column, this.price, this.imageUrl, this.seatName, required this.seatState, this.addedSeats});

  toJson() {
    return {
      'id': id,
      'row': row,
      'column': column,
      'seat_state': seatState.name,
      'seat_name': seatName,
      'image_url': imageUrl,
      'price': price,
      'added_seats': addedSeats
    };
  }
}

class SeatNumber {
  final int rowI;
  final int colI;
  final SeatState seatState;
  String? icon;
  int? noSeats;
  int? price;

  SeatNumber({required this.rowI, required this.colI, this.price, this.noSeats, this.icon, required this.seatState});

  SeatNumber.fromJson(Map<String, dynamic> json)
      : rowI = json['rowI'],
        colI = json['colI'],
        icon = json['icon'],
        seatState = seatStateFromString(json['seatState'] ?? 'sold'),
        price = json['price'],
        noSeats = json['noSeats'];

  @override
  bool operator ==(Object other) {
    return rowI == (other as SeatNumber).rowI && colI == (other).colI;
  }

  toJson() {
    if (price == null && noSeats == null) {
      return {
        'rowI': rowI,
        'colI': colI,
      };
    }
    if (price == null && noSeats != null) {
      return {
        'rowI': rowI,
        'colI': colI,
        'noSeats': noSeats,
      };
    }
    if (price != null && noSeats == null) {
      return {
        'rowI': rowI,
        'colI': colI,
        'price': price,
      };
    }
    if (price != null && noSeats != null) {
      return {
        'rowI': rowI,
        'colI': colI,
        'price': price,
        'noSeats': noSeats,
      };
    }
  }

  @override
  int get hashCode => rowI.hashCode;

  @override
  String toString() {
    return '[$rowI][$colI]';
  }
}
