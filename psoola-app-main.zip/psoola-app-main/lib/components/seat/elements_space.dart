import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../../models/elements_model.dart';
import 'controller/seat_item_controller copy.dart';

class ElementSpace extends StatefulWidget {
  const ElementSpace({Key? key, required this.size}) : super(key: key);
  final double size;

  @override
  State<ElementSpace> createState() => _ElementSpaceState();
}

class _ElementSpaceState extends State<ElementSpace> {
  Color caughtColor = Colors.grey;
  final stackKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SeatItemController>(builder: (_) {
      List<ElementModel> elements = _.getSeatItems;
      return SizedBox(
        width: widget.size,
        height: widget.size,
        child: Stack(
          key: stackKey,
          children:
              // [
              elements.isNotEmpty ? elements.map((e) => DragBox(const Offset(0, 0), e, widget.size, stackKey)).toList() : [const SizedBox()],
        ),
      );
    });
  }
}

class DragBox extends StatefulWidget {
  final Offset initPos;
  final GlobalKey stackKey;
  final ElementModel element;
  final double containerSize;

  const DragBox(this.initPos, this.element, this.containerSize, this.stackKey, {super.key});

  @override
  DragBoxState createState() => DragBoxState();
}

class DragBoxState extends State<DragBox> {
  Offset position = const Offset(0.0, 0.0);
  SeatItemController seatItemController = Get.find<SeatItemController>();
  late FocusAttachment focusAttachment;
  late FocusNode focusNode;

  late double itemSize;

  @override
  void initState() {
    super.initState();
    itemSize = widget.element.itemRatio * widget.containerSize;
    position = widget.initPos;
    focusNode = FocusNode(debugLabel: 'DragBox ${widget.element.name}');
    focusAttachment = focusNode.attach(context);
  }

  @override
  void dispose() {
    focusAttachment.detach();
    focusNode.dispose();
    super.dispose();
  }

  // handleKeyEvent(RawKeyEvent event) {
  //   if (event is RawKeyDownEvent) {
  //     if (event.logicalKey == LogicalKeyboardKey.numpadAdd ||
  //         event.logicalKey == LogicalKeyboardKey.equal) {
  //       itemSize = itemSize * 1.1;
  //       seatItemController.changeElementSize(widget.element, itemSize);
  //     } else if (event.logicalKey == LogicalKeyboardKey.numpadSubtract ||
  //         event.logicalKey == LogicalKeyboardKey.minus) {
  //       itemSize = itemSize * 0.9;
  //       seatItemController.changeElementSize(widget.element, itemSize);
  //     }
  //   }
  //   return KeyEventResult.handled;
  // }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: widget.element.x * widget.containerSize,
      top: widget.element.y * widget.containerSize,
      child: Draggable(
        feedback: Container(
          color: Colors.deepPurple.withOpacity(0.5),
          width: itemSize,
          height: itemSize,
          child: SvgPicture.network(
            widget.element.iconUrl,
            width: 20 * widget.element.x,
            height: 20 * widget.element.x,
          ),
        ),
        onDraggableCanceled: (velocity, offset) {
          final RenderBox stackBox = widget.stackKey.currentContext!.findRenderObject() as RenderBox;
          final localPosition = stackBox.globalToLocal(offset);

          // seatItemController.changeElementPosition(
          //     widget.element, localPosition);
          // change element position based on container size
          // seatItemController.changeElementPosition(
          //     widget.element,
          //     Offset(localPosition.dx / widget.containerSize,
          //         localPosition.dy / widget.containerSize));

          FocusScope.of(context).requestFocus(focusNode);
        },
        child: Focus(
          focusNode: focusNode,
          // onKey: (_, __) {
          //   // return handleKeyEvent(__);
          // },
          child: SizedBox(
              width: itemSize,
              height: itemSize,
              child: SvgPicture.network(
                widget.element.iconUrl,
                width: itemSize,
                height: itemSize,
              )),
        ),
      ),
    );
  }
}
