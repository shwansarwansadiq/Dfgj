/// current state of a seat
enum SeatState {
  /// current user selected this seat
  selected,

  /// current user has not selected this seat yet,
  /// but it is available to be booked
  unselected,

  /// this seat is already sold to other user
  sold,

  /// this seat is disabled to be booked for some reason
  disabled,

  /// empty area e.g. aisle, staircase etc
  empty,
}

// seatState to json
seatStateToJson(SeatState seatState) {
  switch (seatState) {
    case SeatState.selected:
      return 'selected';
    case SeatState.unselected:
      return 'unselected';
    case SeatState.sold:
      return 'sold';
    case SeatState.disabled:
      return 'disabled';
    case SeatState.empty:
      return 'empty';
  }
}

// json to seatState
seatStateFromString(String seatState) {
  switch (seatState) {
    case 'selected':
      return SeatState.selected;
    case 'unselected':
      return SeatState.unselected;
    case 'sold':
      return SeatState.sold;
    case 'disabled':
      return SeatState.disabled;
    case 'empty':
      return SeatState.empty;
    default:
      return SeatState.empty;
  }
}
