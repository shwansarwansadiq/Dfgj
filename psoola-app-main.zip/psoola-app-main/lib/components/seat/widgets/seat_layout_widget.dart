import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/seat_widget_controller.dart';
import '../elements_space.dart';
import '../model/seat_layout_state_model.dart';
import '../utils/seat_state.dart';
import 'seat_widget.dart';

class SeatLayoutWidget extends StatelessWidget {
  final SeatLayoutStateModel stateModel;
  final void Function(int rowI, int colI, SeatState currentState, {String? icon}) onSeatStateChanged;

  const SeatLayoutWidget({
    super.key,
    required this.stateModel,
    required this.onSeatStateChanged,
  });

  @override
  Widget build(BuildContext context) {
    return InteractiveViewer(
      maxScale: 5,
      minScale: 0.1,
      boundaryMargin: const EdgeInsets.all(0),
      constrained: true,
      scaleEnabled: true,
      panEnabled: true,
      child: Stack(
        children: [
          IgnorePointer(
            child: ElementSpace(
              size: Get.width,
            ),
          ),
          SizedBox(
            width: Get.width,
            height: Get.width,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ...List<int>.generate(stateModel.rows, (rowI) => rowI).map<Row>(
                  (rowI) => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      ...List<int>.generate(stateModel.cols, (colI) => colI).map<SeatWidget>((colI) {
                        return SeatWidget(
                          size: stateModel.seatSvgSize,
                          model: Get.find<SeatWidgetController>().getSeatByRowAndColumn(rowI, colI),
                          onSeatStateChanged: (rowI, colI, currentState, {String? icon}) {
                            onSeatStateChanged(rowI, colI, currentState, icon: icon);
                          },
                        );
                      })
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
