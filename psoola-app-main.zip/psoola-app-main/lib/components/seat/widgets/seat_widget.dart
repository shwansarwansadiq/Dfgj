import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:psoola/models/event_model.dart';

import '../../../states/ticket_state.dart';
import '../controller/seat_widget_controller.dart';
import '../model/seat_model.dart';
import '../utils/seat_state.dart';
import 'seat_icon.dart';

class SeatWidget extends StatefulWidget {
  final SeatModel model;
  final double size;
  final void Function(int rowI, int colI, SeatState currentState, {String? icon}) onSeatStateChanged;

  const SeatWidget({
    Key? key,
    required this.model,
    required this.size,
    required this.onSeatStateChanged,
  }) : super(key: key);

  @override
  State<SeatWidget> createState() => _SeatWidgetState();
}

class _SeatWidgetState extends State<SeatWidget> {
  SeatState? seatState;
  EventModel selectedEvent = Get.find<TicketState>().getSelectedEvent!;
  int rowI = 0;
  int colI = 0;
  String unselectedSeatColor = "B8B8B8";
  String soldSeatColor = "555555";

  SeatWidgetController seatDesignController = Get.find<SeatWidgetController>();

  @override
  void initState() {
    super.initState();
    seatState = widget.model.seatState;
    rowI = widget.model.row;
    colI = widget.model.column;
  }

  @override
  Widget build(BuildContext context) {
    final safeCheckedSeatState = seatState;
    if (safeCheckedSeatState != null) {
      return GestureDetector(
          onTapUp: (_) {
            if (seatState == SeatState.unselected) {
              seatState = SeatState.selected;
              seatDesignController.changeSeatState(widget.model, seatState!);
              return;
            }
            if (seatState == SeatState.selected) {
              seatState = SeatState.unselected;
              seatDesignController.changeSeatState(widget.model, seatState!);
              return;
            }
          },
          child: SizedBox(
              height: widget.size,
              width: widget.size,
              child: seatState != SeatState.empty
                  ? widget.model.imageUrl != null
                      ? SvgPicture.network(widget.model.imageUrl!,
                          height: widget.size,
                          width: widget.size,
                          // height: widget.model.seatSvgSize.toDouble(),
                          // width: widget.model.seatSvgSize.toDouble(),
                          fit: BoxFit.cover,
                          // change color
                          colorFilter: ColorFilter.mode(
                              seatState == SeatState.selected
                                  ? Theme.of(context).primaryColor
                                  : seatState == SeatState.sold
                                      ? Color(int.parse("0xFF$soldSeatColor"))
                                      : Color(int.parse("0xFF$unselectedSeatColor")),
                              BlendMode.srcIn))
                      : SvgPicture.asset(
                          _getSvgPath(safeCheckedSeatState),
                          height: widget.size,
                          width: widget.size,
                          // height: widget.model,
                          // width: widget.model.seatSvgSize.toDouble(),
                          fit: BoxFit.cover,
                        )
                  : Container(
                      color: Colors.transparent,
                      height: widget.size,
                      width: widget.size,
                      // height: widget.model.seatSvgSize.toDouble(),
                      // width: widget.model.seatSvgSize.toDouble(),
                    )));
    }
    return const SizedBox();
  }

  String _getSvgPath(SeatState state) {
    return SeatIcon.getSeatSvgByEventTypeAndState(seatState: state);
  }
}
