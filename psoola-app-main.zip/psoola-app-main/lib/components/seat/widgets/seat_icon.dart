import 'package:psoola/components/seat/utils/seat_state.dart';
import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/utils/app_icons.dart';

class SeatIcon {
  static String getSeatSvgByEventTypeAndState(
      {EventType? eventType, required SeatState seatState}) {
    switch (eventType) {
      case EventType.MOVIE:
        return getCinemaSeatByState(seatState);
      case EventType.CONCERT:
        return getCinemaSeatByState(seatState);
      case EventType.THEATER:
        return getCinemaSeatByState(seatState);
      case EventType.EVENT:
        return getCinemaSeatByState(seatState);
      case EventType.LIVEMUSIC:
        return getCinemaSeatByState(seatState);
      default:
        return getCinemaSeatByState(seatState);
    }
  }

  static String getCinemaSeatByState(SeatState seatState) {
    switch (seatState) {
      case SeatState.sold:
        return AppIcons.cinema_seat_sold;
      case SeatState.selected:
        return AppIcons.cinema_seat_selected;
      case SeatState.unselected:
        return AppIcons.cinema_seat_unselected;
      default:
        return AppIcons.cinema_seat_sold;
    }
  }
}
