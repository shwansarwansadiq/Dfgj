import 'package:get/get.dart';
import 'package:psoola/states/ticket_state.dart';

import '../model/seat_model.dart';
import '../utils/seat_state.dart';

class SeatWidgetController extends GetxController {
  int _seatRows = 0;
  int _seatColumns = 0;
  bool _isChangeIcon = false;

  bool get isChangeIcon => _isChangeIcon;
  set isChangeIcon(bool value) {
    _isChangeIcon = value;
    update();
  }

  changeSeatIcon({required int row, required int col, required String imageUrl}) {
    // Find seat index inside _seats
    int seatIndex = _seats.indexWhere((element) => element.row == row && element.column == col);

    if (seatIndex != -1) {
      // Create a new seat with updated imageUrl
      SeatModel newSeat = SeatModel.fromJson({..._seats[seatIndex].toJson(), 'image_url': imageUrl});

      // Replace the seat in the list
      _seats[seatIndex] = newSeat;
      update();
    }
  }

  totalSeatsPrice() {
    int totalSeatsPrice = 0;
    int? addedSeatPrice = Get.find<TicketState>().getSelectedHall!.defaultPrice;
    for (var element in getSelectedSeats) {
      totalSeatsPrice += element.price!;
      if (addedSeatPrice != null && element.addedSeats != null) {
        totalSeatsPrice += element.price! * element.addedSeats!;
      }
    }
    return totalSeatsPrice;
  }

  int get getTotalAddedSeats {
    int totalAddedSeats = 0;
    for (var element in getSelectedSeats) {
      if (element.addedSeats != null) {
        totalAddedSeats += element.addedSeats!;
      }
    }
    return totalAddedSeats;
  }

  List<SeatModel> _seats = [];
  // List<SeatItemModel> _seatItems = [];

  List<SeatModel> get getSeats => _seats;

  set setSeats(List<SeatModel> value) {
    _seats = value;
    // update row and column number
    _seatRows = _seats.map((e) => e.row).reduce((value, element) => value > element ? value : element) + 1;
    _seatColumns = _seats.map((e) => e.column).reduce((value, element) => value > element ? value : element) + 1;

    update();
  }

  int get getSeatRows => _seatRows;
  int get getSeatColumns => _seatColumns;

  set setSeatRows(int value) {
    _seatRows = value;
    _updateSeatList();
    update();
  }

  set setSeatColumns(int value) {
    _seatColumns = value;
    _updateSeatList();
    update();
  }

  _updateSeatList() {
    // add or remove seatModel from list if row or column changed
    if (_seats.length > _seatRows * _seatColumns) {
      for (var i = _seats.length - 1; i >= 0; i--) {
        if (_seats[i].row >= _seatRows || _seats[i].column >= _seatColumns) {
          _seats.removeAt(i);
        }
      }
    } else {
      // add new seatModel to list
      // Create a set of strings that represent existing seats in the format 'row,column'.
      final existingSeats = _seats.map((seat) => '${seat.row},${seat.column}').toSet();

// Traverse all possible seats in the grid.
      for (var i = 0; i < _seatRows; i++) {
        for (var j = 0; j < _seatColumns; j++) {
          // Check if the current seat is already in the _seats list.
          if (!existingSeats.contains('$i,$j')) {
            // If it's not, add a new seat with the current row and column.
            _seats.add(SeatModel(
              row: i,
              column: j,
              seatState: SeatState.unselected,
            ));
          }
        }
      }
    }
  }

  // get seatModel by row and column
  SeatModel getSeatByRowAndColumn(int row, int column) {
    return _seats.firstWhere((element) => element.row == row && element.column == column);
  }

  changeSeatState(SeatModel seatModel, SeatState seatState) {
    // Find seat index inside _seats
    int seatIndex = _seats.indexWhere((element) => element.row == seatModel.row && element.column == seatModel.column);

    if (seatIndex != -1) {
      // Create a new seat with updated seatState
      SeatModel newSeat = SeatModel.fromJson({...(_seats[seatIndex].toJson()), 'seat_state': seatState.name});

      // Replace the seat in the list
      _seats[seatIndex] = newSeat;
      update();
    }
  }

  List<SeatModel> get getSelectedSeats {
    List<SeatModel> selectedSeats = [];
    for (var i = 0; i < _seats.length; i++) {
      if (_seats[i].seatState == SeatState.selected) {
        var seat = _seats[i];
        selectedSeats.add(_seats[i]);
      }
    }
    return selectedSeats;
  }

  // add addedSeats to seatModel
  addAddedSeats() {
    // last seatModel
    if (getSelectedSeats.isEmpty) return;
    SeatModel lastSeatModel = getSelectedSeats.last;
    int prevAddedSeats = lastSeatModel.addedSeats ?? 0;

    // Find seat index inside _seats
    int seatIndex = _seats.indexWhere((element) => element.row == lastSeatModel.row && element.column == lastSeatModel.column);

    if (seatIndex != -1) {
      // Create a new seat with updated addedSeats
      SeatModel newSeat = SeatModel.fromJson({...(_seats[seatIndex].toJson()), 'added_seats': prevAddedSeats + 1});

      // Replace the seat in the list
      _seats[seatIndex] = newSeat;
      update();
    }
  }

  removeAddedSeats() {
    // last seatModel
    if (getSelectedSeats.isEmpty) return;
    SeatModel lastSeatModel = getSelectedSeats.last;
    int prevAddedSeats = lastSeatModel.addedSeats ?? 0;

    // Find seat index inside _seats
    int seatIndex = _seats.indexWhere((element) => element.row == lastSeatModel.row && element.column == lastSeatModel.column);

    if (seatIndex != -1 && prevAddedSeats > 0) {
      // Create a new seat with updated addedSeats
      SeatModel newSeat = SeatModel.fromJson({...(_seats[seatIndex].toJson()), 'added_seats': prevAddedSeats - 1});

      // Replace the seat in the list
      _seats[seatIndex] = newSeat;
      update();
    }
  }

  void clear() {
    _seats.clear();
    _seatRows = 0;
    _seatColumns = 0;
  }
}
