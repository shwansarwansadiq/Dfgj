import 'package:get/get.dart';

import '../../../models/elements_model.dart';

class SeatItemController extends GetxController {
  List<ElementModel> _seatItems = [];
  // List<SeatItemModel> _seatItems = [];

  List<ElementModel> get getSeatItems => _seatItems;

  set setSeatItems(List<ElementModel> value) {
    _seatItems = value;
    update();
  }

  // addSeatItem(ElementModel seatItemModel) {
  //   _seatItems.add(seatItemModel);
  //   update();
  // }

  // removeSeatItem(String seatItemModel) {
  //   _seatItems.remove(seatItemModel);
  //   update();
  // }

  // changeElementSize(ElementModel element, double size) {
  //   int elementIndex = _seatItems.indexWhere((e) => e.id == element.id);
  //   if (elementIndex != -1) {
  //     _seatItems[elementIndex].itemRatio = size;
  //     update();
  //   }
  // }

  // changeElementPosition(ElementModel element, Offset position) {
  //   int elementIndex = _seatItems.indexWhere((e) => e.id == element.id);
  //   if (elementIndex != -1) {
  //     _seatItems[elementIndex].x = position.dx;
  //     _seatItems[elementIndex].y = position.dy;
  //     update();
  //   }
  // }
}
