import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'controller/seat_widget_controller.dart';
import 'model/seat_layout_state_model.dart';
import 'model/seat_model.dart';
import 'utils/seat_state.dart';
import 'widgets/seat_layout_widget.dart';

class SeatsSelector extends StatefulWidget {
  const SeatsSelector({super.key, required this.width});
  final double width;
  @override
  SeatsSelectorState createState() => SeatsSelectorState();
}

class SeatsSelectorState extends State<SeatsSelector> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<SeatWidgetController>(builder: (controller) {
      var row = controller.getSeatRows;
      if (row == 0) {
        return SizedBox(
            width: widget.width,
            height: widget.width,
            child: const Center(
              child: CircularProgressIndicator(),
            ));
      }
      var maxDimension = controller.getSeatRows > controller.getSeatColumns ? controller.getSeatRows : controller.getSeatColumns;

      var seatSvgSize = (widget.width / maxDimension) - ((widget.width / maxDimension) * 0.08);

      return SeatLayoutWidget(
        onSeatStateChanged: (rowI, colI, seatState, {String? icon}) {
          ScaffoldMessenger.of(context).hideCurrentSnackBar();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(seatState == SeatState.selected ? "Selected Seat[$rowI][$colI]" : "De-selected Seat[$rowI][$colI]"),
            ),
          );

          List<SeatModel> seats = controller.getSeats;
          seats[rowI * controller.getSeatColumns + colI].seatState = seatState;
          seats[rowI * controller.getSeatColumns + colI].imageUrl = icon;
          controller.setSeats = seats;
          // SeatModel initialization is not used, remove or use it if necessary.
        },
        stateModel: SeatLayoutStateModel(
          pathDisabledSeat: 'assets/seats/svg_disabled_bus_seat.svg',
          pathSelectedSeat: 'assets/seats/svg_selected_bus_seats.svg',
          pathSoldSeat: 'assets/seats/svg_sold_bus_seat.svg',
          pathUnSelectedSeat: 'assets/seats/svg_unselected_bus_seat.svg',
          rows: controller.getSeatRows,
          cols: controller.getSeatColumns,
          seatSvgSize: seatSvgSize,
        ),
      );
    });
  }
}
