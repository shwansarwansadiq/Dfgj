import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

fibModal({required qr, required applink, required context}) {
  final String base64String = qr.contains('base64,') ? qr.split('base64,')[1] : qr;
  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: const Text('scan result'),
        content: Image.memory(base64Decode(base64String)),
        actions: [
          TextButton(
            onPressed: () {
              var uri = Uri.parse(applink);
              launchUrl(uri, mode: LaunchMode.externalApplication);
            },
            style: TextButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [Text('Open FIB App')],
            ),
          ),
        ],
      );
    },
  );
}
