import 'package:bluelab_dialog/panara_dialogs.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:psoola/components/seat/controller/seat_widget_controller.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/models/event_model.dart';
import 'package:psoola/states/ticket_state.dart';
import 'package:psoola/success_purchase.dart';
import 'package:psoola/utils/app_image.dart';

import '../../api/payment/payment_api.dart';
import '../../api/payment/payment_method_api.dart';
import '../../models/payment_method.dart';
import '../../models/text_lang_model.dart';
import '../../models/user_model.dart';
import '../../screens/payment/balance_recharge_page.dart';
import '../../screens/payment/components/payment_webview.dart';
import '../../utils/app_animations.dart';
import '../../utils/app_texts.dart';
import 'fib_modal.dart';
import 'recharge_options.dart';

class WalletSheet extends StatelessWidget {
  final ScrollController? scrollController;
  WalletSheet({
    super.key,
    this.scrollController,
  });

  final AuthState authState = Get.find<AuthState>();
  final TicketState ticketState = Get.find<TicketState>();
  final SeatWidgetController seatWidgetController = Get.find<SeatWidgetController>();

  @override
  Widget build(BuildContext context) {
    if (authState.user.value.state == UserState.LOGEDIN) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: GestureDetector(
              onTap: () {
                Get.back();
              },
              child: Container(
                height: 5,
                width: 40,
                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          const SizedBox(
            height: 15,
          ),
          //credit card
          Container(
            height: 175,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 20,
                  offset: Offset(0, 10),
                ),
              ],
              borderRadius: const BorderRadius.all(
                Radius.circular(20),
              ),
              // image: DecorationImage(
              //   image: AssetImage("assets/images/wane_card_2.png"),
              //   fit: BoxFit.cover,
              // ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 30,
                        width: 100,
                        child: Image.asset(
                          AppImage.logo,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  const Spacer(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(10),
                        child: SvgPicture.asset("assets/images/Group 250.svg", height: 40),
                      ),
                      Column(
                        children: [
                          Text(
                            AppTexts.your_balance.tr,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                            ),
                          ),
                          Row(
                            children: [
                              const SizedBox(
                                width: 10,
                              ),
                              Text(
                                authState.user.value.balance.toString(),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "IQD",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(
            height: 30,
          ),
          Text(
            AppTexts.recharge.tr,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(
            height: 10,
          ),
          Text(AppTexts.please_choose_one_of_the_following_payment_methods.tr,
              textAlign: TextAlign.start,
              style: const TextStyle(
                fontSize: 14,
              )),
          const SizedBox(
            height: 20,
          ),

          FutureBuilder(
              future: fetchPaymentMethodsApi(),
              builder: (BuildContext ctx, AsyncSnapshot snapshot) {
                if (snapshot.hasData) {
                  List<PaymentMethodModel> paymentMethods = snapshot.data;
                  return Column(children: [
                    RechargeOptionType(
                      ontap: () {
                        byWithCredit(context);

                        // Navigator.of(context).pop();
                      },
                      type: "single",
                      typeTitle: TextLangModel.fromJson({"textAr": " اشتری بالرسید", "textEn": "buy with your balance", "textKr": "بە باڵانسەکەت بیکڕە"}),
                      lottie: AppAnimations.wallet,
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    ...paymentMethods.map((e) => RechargeOptionType(
                          ontap: () {
                            makePayment(paymentMethod: e, context: context);
                          },
                          type: "single",
                          typeTitle: e.title,
                          typeImage: e.imageUrl,
                        )),
                  ]);
                } else {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              }),
          const SizedBox(
            height: 20,
          ),

          const SizedBox(
            height: 20,
          ),
        ],
      );
    } else {
      return Container();
    }
  }

  byWithCredit(context) {
    int totalSeatPrice = seatWidgetController.totalSeatsPrice();
    if (authState.user.value.balance >= totalSeatPrice) {
      showBuyDialog(context);
    } else {
      showDoNotHaveEnoughDialog(context);
    }
  }

  showDoNotHaveEnoughDialog(context) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: AppTexts.sorry.tr,
      message: AppTexts.you_do_not_have_enough_balance.tr,
      confirmButtonText: AppTexts.recharge.tr,
      cancelButtonText: AppTexts.cancel.tr,
      onTapConfirm: () {},
      onTapCancel: () {
        Get.back();
      },

      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true, // optional parameter (default is true)
    );
  }

  showBuyDialog(context) {
    PanaraConfirmDialog.show(
      context,
      imagePath: AppAnimations.alert,
      title: AppTexts.are_you_sure.tr,
      message: AppTexts.buy_ticket.tr,
      confirmButtonText: AppTexts.buy_ticket.tr,
      cancelButtonText: AppTexts.cancel.tr,
      onTapConfirm: () async {
        EasyLoading.show(status: AppTexts.pleaseWait.tr, dismissOnTap: false, maskType: EasyLoadingMaskType.black);
        try {
          EventModel? event = ticketState.getSelectedEvent;
          if (event == null) {
            EasyLoading.dismiss();
            return;
          }
          bool result;

          result = await buyTicketWithBalanceApi();

          EasyLoading.dismiss();

          if (result) {
            Get.to(() => const SuccessPurchase());
          } else {
            Get.snackbar(AppTexts.error.tr, AppTexts.pleaseTryAgain.tr);
          }
        } catch (e) {
          EasyLoading.dismiss();
          Get.snackbar(AppTexts.error.tr, AppTexts.pleaseTryAgain.tr);
        }
      },
      onTapCancel: () {
        Get.back();
      },

      panaraDialogType: PanaraDialogType.normal,
      barrierDismissible: true, // optional parameter (default is true)
    );
  }

  static makePayment({required PaymentMethodModel paymentMethod, required BuildContext context}) async {
    if (paymentMethod.type == PaymentType.FIB) {
      EasyLoading.show(status: AppTexts.pleaseWait.tr, dismissOnTap: false, maskType: EasyLoadingMaskType.black);
      var data = await paymentUrl(paymentMethod: PaymentType.FIB);
      EasyLoading.dismiss();
      if (data['status'] == 200) {
        String qrCode = data['qrCode'];
        String appLink = data['appLink'];
        fibModal(applink: appLink, qr: qrCode, context: context);
      }
      return;
    }
    if (paymentMethod.type == PaymentType.FASTPAY) {
      // loading animation
      EasyLoading.show(status: AppTexts.pleaseWait.tr, dismissOnTap: false, maskType: EasyLoadingMaskType.black);
      var data = await paymentUrl(paymentMethod: PaymentType.FASTPAY);
      EasyLoading.dismiss();
      if (data['status'] == 200) {
        String url = data['data'];
        return Navigator.push(context, CupertinoPageRoute(builder: (BuildContext ctx) {
          return PaymentWebview(url: url);
        }));
      }
    } else if (paymentMethod.type == PaymentType.ZAINCASH) {
    } else if (paymentMethod.type == PaymentType.ASIA || paymentMethod.type == PaymentType.KOREK) {
      Navigator.push(context, CupertinoPageRoute(builder: (BuildContext ctx) {
        return BalanceRechargePage(
          paymentMethodModel: paymentMethod,
        );
      }));
    }
  }
}
