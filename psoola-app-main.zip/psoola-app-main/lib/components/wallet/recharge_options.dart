import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import '../../models/text_lang_model.dart';
import '../multi_lang_text_widget.dart';

class RechargeOptionType extends StatefulWidget {
  final String? type;
  final Function ontap;
  final TextLangModel typeTitle;
  final String? titleOne;
  final String? titleTwo;
  final String? typeImage;
  final String? lottie;
  final String? imageOne;
  final String? imageTwo;
  const RechargeOptionType(
      {this.imageOne,
      this.lottie,
      this.imageTwo,
      this.typeImage,
      required this.ontap,
      required this.typeTitle,
      this.titleOne,
      this.titleTwo,
      this.type,
      Key? key})
      : super(key: key);

  @override
  State<RechargeOptionType> createState() => _RechargeOptionTypeState();
}

class _RechargeOptionTypeState extends State<RechargeOptionType> {
  @override
  Widget build(BuildContext context) {
    return widget.type == 'single'
        ? RechargeTile(
            title: widget.typeTitle,
            typeImage: widget.typeImage,
            lottie: widget.lottie,
            ontap: widget.ontap,
          )
        : ExpandRechargeTile(
            titleOne: widget.titleOne,
            titleTwo: widget.titleTwo,
            typeTitle: widget.typeTitle,
            imageOne: widget.imageOne,
            imageTwo: widget.imageTwo,
            typeImage: widget.typeImage,
            ontap: widget.ontap,
          );
  }
}

class RechargeTile extends StatefulWidget {
  final TextLangModel title;
  final Function ontap;
  final String? typeImage;
  final String? lottie;
  const RechargeTile(
      {this.typeImage,
      required this.title,
      required this.ontap,
      Key? key,
      this.lottie})
      : super(key: key);

  @override
  State<RechargeTile> createState() => _RechargeTileState();
}

class _RechargeTileState extends State<RechargeTile> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (context) => MySample(),
        //   ),
        // );
      },
      child: ListTile(
        onTap: () {
          widget.ontap();
        },
        contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        leading: widget.lottie != null
            ? Lottie.asset(
                widget.lottie!,
                width: 40,
                height: 40,
              )
            : CircleAvatar(
                radius: 20,
                backgroundColor: Colors.grey.shade200,
                backgroundImage: Image.network(
                  widget.typeImage!,
                  fit: BoxFit.cover,
                ).image),
        title: MultiLangText(
          text: widget.title,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: const Icon(
          Icons.arrow_forward_ios,
          size: 15,
        ),
      ),
    );
  }
}

class ExpandRechargeTile extends StatelessWidget {
  final String? titleOne;
  final String? titleTwo;
  final TextLangModel typeTitle;
  final String? typeImage;
  final String? imageOne;
  final String? imageTwo;
  final Function ontap;

  const ExpandRechargeTile({
    this.titleOne,
    this.titleTwo,
    required this.typeTitle,
    this.typeImage,
    this.imageOne,
    this.imageTwo,
    required this.ontap,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ExpandablePanel(
      theme: ExpandableThemeData(
          hasIcon: false,
          iconColor: Theme.of(context).iconTheme.color,
          alignment: Alignment.center,
          headerAlignment: ExpandablePanelHeaderAlignment.center,
          bodyAlignment: ExpandablePanelBodyAlignment.center,
          inkWellBorderRadius: BorderRadius.circular(10)),
      header: ListTile(
        onTap: () {
          ontap();
        },
        contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        leading: CircleAvatar(
            radius: 20,
            backgroundColor: Colors.grey.shade200,
            backgroundImage: NetworkImage(
              typeImage!,
            )),
        title: MultiLangText(
          text: typeTitle,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: const Icon(
          Icons.arrow_forward_ios,
          size: 15,
        ),
      ),
      expanded: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Theme.of(context).primaryColor.withOpacity(0.2),
        ),
        child: Column(
          children: [
            ListTile(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              leading: CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.grey.shade200,
                  backgroundImage: NetworkImage(
                    imageOne!,
                  )),
              title: Text(
                titleOne!,
                style: const TextStyle(
                  fontSize: 14,
                ),
              ),
              trailing: const Icon(
                Icons.arrow_forward_ios,
                size: 15,
              ),
            ),
            ListTile(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              leading: CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.grey.shade200,
                  backgroundImage: NetworkImage(
                    imageTwo!,
                  )),
              title: Text(
                titleTwo!,
                style: const TextStyle(
                  fontSize: 14,
                ),
              ),
              trailing: const Icon(
                Icons.arrow_forward_ios,
                size: 15,
              ),
            ),
          ],
        ),
      ),
      collapsed: const SizedBox(),
    );
  }
}
