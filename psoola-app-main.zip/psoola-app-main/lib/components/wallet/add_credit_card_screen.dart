import 'package:flutter/material.dart';
import 'package:flutter_credit_card/flutter_credit_card.dart';

class MySample extends StatefulWidget {
  const MySample({super.key});

  @override
  State<StatefulWidget> createState() {
    return MySampleState();
  }
}

class MySampleState extends State<MySample> {
  String cardNumber = '';
  String expiryDate = '';
  String cardHolderName = '';
  String cvvCode = '';
  bool isCvvFocused = false;
  bool useGlassMorphism = false;
  bool useBackgroundImage = false;

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: const Text('زیادکردنی کرێدیت کارت'),
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            const SizedBox(
              height: 30,
            ),
            CreditCardWidget(
              cardNumber: cardNumber,
              expiryDate: expiryDate,
              cardHolderName: cardHolderName,
              cvvCode: cvvCode,
              showBackView: isCvvFocused,
              obscureCardNumber: true,
              obscureCardCvv: true,
              isHolderNameVisible: true,
              cardBgColor: Theme.of(context).colorScheme.secondary,
              backgroundImage: useBackgroundImage ? 'assets/card_bg.png' : null,
              isSwipeGestureEnabled: true,
              onCreditCardWidgetChange: (CreditCardBrand creditCardBrand) {
                // setState(() {});
              },
              customCardTypeIcons: <CustomCardTypeIcon>[
                CustomCardTypeIcon(
                  cardType: CardType.mastercard,
                  cardImage: Image.asset(
                    'assets/mastercard.png',
                    height: 48,
                    width: 48,
                  ),
                ),
              ],
            ),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(children: <Widget>[
                  CreditCardForm(
                    formKey: formKey,
                    obscureCvv: true,
                    obscureNumber: true,
                    cardNumber: cardNumber,
                    cvvCode: cvvCode,
                    isHolderNameVisible: true,
                    isCardNumberVisible: true,
                    isExpiryDateVisible: true,
                    cardHolderName: cardHolderName,
                    expiryDate: expiryDate,

                    // themeColor: Theme.of(context).colorScheme.secondary,
                    // cardNumberDecoration: InputDecoration(
                    //     labelText: 'ژمارەی کارت',
                    //     labelStyle: const TextStyle(fontFamily: 'bahij'),
                    //     hintStyle: const TextStyle(fontFamily: 'bahij'),
                    //     hintText: 'XXXX XXXX XXXX XXXX',
                    //     border: OutlineInputBorder(
                    //       borderRadius: BorderRadius.circular(10),
                    //     ),
                    //     focusedBorder: OutlineInputBorder(
                    //       borderRadius: BorderRadius.circular(10),
                    //       borderSide: BorderSide(
                    //         color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                    //         width: 2,
                    //       ),
                    //     )),
                    // expiryDateDecoration: InputDecoration(
                    //     //copy with theme

                    //     labelText: 'بەرواری بەسەرچوون',
                    //     hintText: 'XX/XX',
                    //     labelStyle: const TextStyle(fontFamily: 'bahij'),
                    //     hintStyle: const TextStyle(fontFamily: 'bahij'),
                    //     border: OutlineInputBorder(
                    //       borderRadius: BorderRadius.circular(10),
                    //     ),
                    //     focusedBorder: OutlineInputBorder(
                    //       borderRadius: BorderRadius.circular(10),
                    //       borderSide: BorderSide(
                    //         color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                    //         width: 2,
                    //       ),
                    //     )),
                    // cvvCodeDecoration: InputDecoration(
                    //     labelText: 'CVV',
                    //     hintText: 'XXX',
                    //     labelStyle: const TextStyle(fontFamily: 'bahij'),
                    //     hintStyle: const TextStyle(fontFamily: 'bahij'),
                    //     border: OutlineInputBorder(
                    //       borderRadius: BorderRadius.circular(10),
                    //     ),
                    //     focusedBorder: OutlineInputBorder(
                    //       borderRadius: BorderRadius.circular(10),
                    //       borderSide: BorderSide(
                    //         color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                    //         width: 2,
                    //       ),
                    //     )),
                    // cardHolderDecoration: InputDecoration(
                    //     labelText: 'ناوی بەکارھێنەر',
                    //     labelStyle: const TextStyle(fontFamily: 'bahij'),
                    //     hintStyle: const TextStyle(fontFamily: 'bahij'),
                    //     border: OutlineInputBorder(
                    //       borderRadius: BorderRadius.circular(10),
                    //     ),
                    //     focusedBorder: OutlineInputBorder(
                    //       borderRadius: BorderRadius.circular(10),
                    //       borderSide: BorderSide(
                    //         color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                    //         width: 2,
                    //       ),
                    //     )),
                    onCreditCardModelChange: onCreditCardModelChange,
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        if (formKey.currentState!.validate()) {
                          formKey.currentState!.save();
                        }
                      },
                      child: const Text('پاشەکەوتکردن'),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void onCreditCardModelChange(CreditCardModel? creditCardModel) {
    setState(() {
      cardNumber = creditCardModel!.cardNumber;
      expiryDate = creditCardModel.expiryDate;
      cardHolderName = creditCardModel.cardHolderName;
      cvvCode = creditCardModel.cvvCode;
      isCvvFocused = creditCardModel.isCvvFocused;
    });
  }
}
