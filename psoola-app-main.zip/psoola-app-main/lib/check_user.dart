import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psoola/checker%20app/home.dart';
import 'package:psoola/controllers/auth_controller.dart';
import 'package:psoola/customer/customer_nav.dart';
import 'package:psoola/ticket%20provider%20app/ticket_provider_nav.dart';

import 'auth/complete_profile.dart';
import 'models/user_model.dart';

class CheckUser extends StatelessWidget {
  final AuthState authState = Get.find<AuthState>();

  CheckUser({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (authState.user.value.state == UserState.LOADING) {
        return const Scaffold(
          body: Center(
            child: CircularProgressIndicator(),
          ),
        );
      } else if (authState.user.value.state == UserState.LOGEDIN) {
        if (authState.user.value.userType == "CUSTOMER") {
          if (authState.user.value.phonenumber == null) {
            return const CompleteProfile();
          }
          return const CustomerNav();
        } else if (authState.user.value.userType == "PROVIDER") {
          return const TicketProviderNav();
        } else if (authState.user.value.userType == "CHECKER") {
          return CheckerHomePage();
        } else {
          return const Center(
            child: Text('Not implemented'),
          );
        }
      } else {
        return const CustomerNav();
      }
    });
  }
}
