import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:psoola/models/event_model.dart';

FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;

class FirebaseDynamicLinkService {
  createDynamicLink(bool short, EventModel eventModel) async {
    final DynamicLinkParameters parameters = DynamicLinkParameters(
      uriPrefix: 'Write your uriPrefix here',
      link: Uri.parse('Link you want to parse'),
      androidParameters: const AndroidParameters(
        packageName: 'your package name',
        minimumVersion: 125,
      ),
    );

    Uri url;
  }

  static Future<void> initDynamicLink(BuildContext context) async {
    FirebaseDynamicLinks.instance.onLink;

    final PendingDynamicLinkData? data =
        await FirebaseDynamicLinks.instance.getInitialLink();

    final Uri deepLink = data!.link;
    var isStory = deepLink.pathSegments.contains('eventModel');
    String? id = deepLink.queryParameters['id'];
  }
}
