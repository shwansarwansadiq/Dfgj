import 'district_model.dart';
import 'neighborhood_model.dart';
import 'province_model.dart';

class LocationModel {
  late ProvinceModel province;
  late DistrictModel district;
  late NeighborhoodModel neighborhood;

  LocationModel.fromJson(Map<String, dynamic> json) {
    district = DistrictModel.fromJson(json['district']);
    province = ProvinceModel.fromJson(json['province']);
    neighborhood = NeighborhoodModel.fromJson(json['neighborhood']);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['province'] = province.toJson();
    data['district'] = district.toJson();
    data['neighborhood'] = neighborhood.toJson();
    return data;
  }
}
