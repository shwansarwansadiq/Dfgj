import '../text_lang_model.dart';

class DistrictModel {
  late TextLangModel name;
  late String id;

  DistrictModel.fromJson(Map<String, dynamic> json) {
    name = TextLangModel.fromJson(json['name']);
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name.toJson();
    data['id'] = id;
    return data;
  }
}
