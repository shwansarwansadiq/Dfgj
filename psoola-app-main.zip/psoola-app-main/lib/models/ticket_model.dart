import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:psoola/models/text_lang_model.dart';

import 'event_model.dart';

class TicketModel {
  late EventModel event;
  late String id;
  late Timestamp createdAt;
  TextLangModel? category;
  late int price;
  String? seatId;
  late DateTime eventDate;
  DateTime? selectedEventTime;
  late String placeId;
  late String hallId;
  String? seatName;
  int? addedSeats = 0;

  TicketModel.fromJson(Map<String, dynamic> jsonData) {
    event = EventModel.fromJson(jsonData['event']);
    id = jsonData['id'];
    seatName = jsonData['seat_name'];
    createdAt = jsonData['createdAt'];
    seatId = jsonData['seatId'];
    hallId = jsonData['hallId'];
    price = jsonData['price'];
    placeId = jsonData['placeId'];
    addedSeats = jsonData['added_seats'] ?? 0;
    selectedEventTime = jsonData['selectedEventTime'] != null ? (jsonData['selectedEventTime'] as Timestamp).toDate() : null;
    eventDate = event.startTime;
    if (jsonData['category'] != null) {
      category = TextLangModel.fromJson(jsonData['category']);
    }
  }
}
