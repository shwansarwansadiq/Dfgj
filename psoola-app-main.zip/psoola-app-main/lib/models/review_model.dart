import 'package:cloud_firestore/cloud_firestore.dart';

class SingleReviewModel {
  String? comment;
  String? image;
  late dynamic star;
  late String name;
  late String id;
  late String userId;
  late Timestamp created;

  SingleReviewModel.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    id = json['id'];
    userId = json['userId'];
    comment = json['comment'];
    image = json['image'];
    star = json['star'];
    created = json['created'];
  }

  toMap() {
    return {
      'name': name,
      'userId': userId,
      'comment': comment,
      'image': image,
      'id': id,
      'star': star,
    };
  }
}

class TotalReviewModel {
  late int star1;
  late int star2;
  late int star3;
  late int star4;
  late int star5;
  late dynamic star1Percent;
  late dynamic star2Percent;
  late dynamic star3Percent;
  late dynamic star4Percent;
  late dynamic star5Percent;
  late int totalReview;
  late dynamic averageRating;

  TotalReviewModel.fromJson(Map<String, dynamic> json) {
    star1 = json['star1'];
    star2 = json['star2'];
    star3 = json['star3'];
    star4 = json['star4'];
    star5 = json['star5'];
     totalReview = json['totalReview'];
    star1Percent = totalReview > 0 ? (star1 / totalReview) * 100 : 0;
    star2Percent = totalReview > 0 ? (star2 / totalReview) * 100 : 0;
    star3Percent = totalReview > 0 ? (star3 / totalReview) * 100 : 0;
    star4Percent = totalReview > 0 ? (star4 / totalReview) * 100 : 0;
    star5Percent = totalReview > 0 ? (star5 / totalReview) * 100 : 0;
   
    averageRating = json['averageRating'];
  }
}
