import 'package:psoola/models/event_type_model.dart';

import 'genre_model.dart';
import 'text_lang_model.dart';

class ShowModel {
  late String id;
  late TextLangModel title;
  late TextLangModel description;
  late String poster;
  late String cover;
  late int duration;
  String? director;
  List<GenreModel>? genres;
  late EventType type;
  String? videoUrl;

  ShowModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    title = TextLangModel.fromJson(jsonData['title']);
    description = TextLangModel.fromJson(jsonData['description']);
    poster = jsonData['poster'];
    cover = jsonData['cover'];
    director = jsonData['director'];

    duration = jsonData['duration'];
    if (jsonData['genres'] != null) {
      genres = jsonData['genres'].map<GenreModel>((genre) {
        return GenreModel.fromJson(genre);
      }).toList();
    }

    type = eventTypeFromString(jsonData['type']);
    videoUrl = jsonData['videoUrl'];

    director = jsonData['director'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['title'] = title.toJson();
    data['description'] = description.toJson();
    data['poster'] = poster;
    data['cover'] = cover;
    data['duration'] = duration;
    data['genres'] = genres;
    data['type'] = eventTypeToString(type);
    data['videoUrl'] = videoUrl;
    return data;
  }
}

class CastModel {
  late String name;
  late String image;
  late String role;

  CastModel.fromJson(Map<String, dynamic> jsonData) {
    name = jsonData['name'];
    image = jsonData['image'];
    role = jsonData['role'];
  }
}
