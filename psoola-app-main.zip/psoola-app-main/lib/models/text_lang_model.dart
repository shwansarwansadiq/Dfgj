class TextLangModel {
  late String textKr;
  late String textAr;
  late String textEn;

  TextLangModel.fromJson(Map<String, dynamic> jsonData) {
    textKr = jsonData['textKr'];
    textAr = jsonData['textAr'];
    textEn = jsonData['textEn'];
  }

  TextLangModel({
    required this.textKr,
    required this.textAr,
    required this.textEn,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['textKr'] = textKr;
    data['textAr'] = textAr;
    data['textEn'] = textEn;
    return data;
  }
}
