import 'text_lang_model.dart';

class PaymentMethodModel {
  late String id;
  late TextLangModel title;
  late String imageUrl;
  late PaymentType type;

  PaymentMethodModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = TextLangModel.fromJson(json['title']);
    imageUrl = json['imageUrl'];
    type = paymentTypeFromString(json['type']);
  }

  PaymentMethodModel({
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.type,
  });
}

// ignore: constant_identifier_names
enum PaymentType { FASTPAY, ZAINCASH, ASIA, KOREK, FIB }

paymentTypeToString(PaymentType paymentType) {
  switch (paymentType) {
    case PaymentType.ASIA:
      return 'ASIA';
    case PaymentType.KOREK:
      return 'KOREK';
    case PaymentType.FASTPAY:
      return 'FASTPAY';
    case PaymentType.ZAINCASH:
      return 'ZAINCASH';
    case PaymentType.FIB:
      return 'FIB';
    default:
      return 'FASTPAY';
  }
}

paymentTypeFromString(String paymentType) {
  switch (paymentType) {
    case 'ASIA':
      return PaymentType.ASIA;

    case 'KOREK':
      return PaymentType.KOREK;
    case 'FASTPAY':
      return PaymentType.FASTPAY;
    case 'ZAINCASH':
      return PaymentType.ZAINCASH;
    case 'FIB':
      return PaymentType.FIB;
    default:
      return PaymentType.FASTPAY;
  }
}
