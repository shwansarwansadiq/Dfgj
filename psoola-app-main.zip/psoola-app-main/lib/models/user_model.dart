// ignore_for_file: constant_identifier_names

import 'location/province_model.dart';

class UserModel {
  UserState state = UserState.LOGEDIN;
  String? name;
  String? email;
  String? phonenumber;
  ProvinceModel? province;
  String? userType;
  int balance = 0;
  late String role;
  UserModel.fromJson(Map<String, dynamic> jsonData) {
    role = jsonData['role'] ?? 'CUSTOMER';
    state = jsonData['state'];
    name = jsonData['fullName'];
    email = jsonData['email'];
    phonenumber = jsonData['phone'];
    //province = ProvinceModel.fromJson(jsonData['province']);
    userType = jsonData['userType'];
    balance = jsonData['balance'] ?? 0;
  }
}

enum UserState {
  LOADING,
  LOGEDIN,
  LOGEDOUT,
}

enum UserType {
  CUSTOMER,
  TICKETPROVIDER,
  CHECKER,
}

enum AuthType { SIGNIN, SIGNUP }

String userTypeToString(UserType userType) {
  switch (userType) {
    case UserType.CUSTOMER:
      return 'CUSTOMER';
    case UserType.TICKETPROVIDER:
      return 'PROVIDER';
    case UserType.CHECKER:
      return 'CHECKER';

    default:
      return 'none';
  }
}

// userType to String
extension UserTypeExtension on UserType {
  String get value {
    switch (this) {
      case UserType.CUSTOMER:
        return 'CUSTOMER';
      case UserType.TICKETPROVIDER:
        return 'PROVIDER';

      case UserType.CHECKER:
        return 'CHECKER';
      default:
        return 'CUSTOMER';
    }
  }
}

// String to userType
extension StringExtension on String {
  UserType get userType {
    switch (this) {
      case 'CUSTOMER':
        return UserType.CUSTOMER;
      case 'PROVIDER':
        return UserType.TICKETPROVIDER;

      case 'CHECKER':
        return UserType.CHECKER;
      default:
        return UserType.CUSTOMER;
    }
  }
}

UserType userTypeFromString(String userType) {
  switch (userType) {
    case 'CUSTOMER':
      return UserType.CUSTOMER;
    case 'PROVIDER':
      return UserType.TICKETPROVIDER;

    case 'CHECKER':
      return UserType.CHECKER;

    default:
      return UserType.CUSTOMER;
  }
}

String userTypeToCollectionName(UserType userType) {
  switch (userType) {
    case UserType.CUSTOMER:
      return 'customers';
    case UserType.TICKETPROVIDER:
      return 'ticket_providers';

    case UserType.CHECKER:
      return 'ticket_checker';

    default:
      return 'non';
  }
}
