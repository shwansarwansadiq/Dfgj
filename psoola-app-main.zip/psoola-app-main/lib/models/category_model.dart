import 'package:psoola/models/event_type_model.dart';
import 'package:psoola/models/text_lang_model.dart';
import 'package:psoola/utils/app_icons.dart';

class CategoryModel {
  late String id;
  late TextLangModel title;
  late String icon;
  late EventType eventType;

  CategoryModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    title = TextLangModel.fromJson(jsonData['title']);
    icon = jsonData['icon'];
    eventType = eventTypeFromString(jsonData['eventType']);
  }
}

List<CategoryModel> categoriesList() {
  List<CategoryModel> categories = [];
  categories.add(CategoryModel.fromJson({
    "id": "1",
    "title": {"textKr": "فلم", "textEn": "MOVIE", "textAr": "أفلام"},
    "icon": AppIcons.popcorn,
    "eventType": "MOVIE"
  }));

  categories.add(CategoryModel.fromJson({
    "id": "2",
    "title": {
      "textKr": "لایڤ میوزیک",
      "textEn": "Live Music",
      "textAr": "موسيقى حيه"
    },
    "icon": AppIcons.liveMusic,
    "eventType": "LIVEMUSIC"
  }));

  categories.add(CategoryModel.fromJson({
    "id": "3",
    "title": {"textKr": "کۆنسێرت", "textEn": "Concert", "textAr": "كونسرت"},
    "icon": AppIcons.concert,
    "eventType": "CONCERT"
  }));

  categories.add(CategoryModel.fromJson({
    "id": "4",
    "title": {"textKr": "شانۆگەری", "textEn": "Theater", "textAr": "مسرح"},
    "icon": AppIcons.theatre,
    "eventType": "THEATER"
  }));

  categories.add(CategoryModel.fromJson({
    "id": "5",
    "title": {"textKr": "بۆنە", "textEn": "Event", "textAr": "حدث"},
    "icon": AppIcons.popcorn,
    "eventType": "EVENT"
  }));
  return categories;
}
