class AboutUsModel {
  late String descriptionKrd;
  late String descriptionEn;
  late String descriptionAr;

  late String addressKrd;
  late String addressEn;
  late String addressAr;

  late String phone;
  late String whatsapp;
  late String telegram;
  late String viber;

  late String email;

  late String facebook;
  late String instagram;
  late String twitter;
  late String youtube;
  late String linkedin;

  AboutUsModel.fromJson(Map<String, dynamic> json) {
    final description = json['description'];
    descriptionAr = description['descriptionAr'] ?? '';
    descriptionEn = description['descriptionEn'] ?? '';
    descriptionKrd = description['descriptionKrd'] ?? '';

    final phones = json['phones'];
    phone = phones['phone'] ?? '';
    whatsapp = phones['whatsapp'] ?? '';
    telegram = phones['telegram'] ?? '';
    viber = phones['viber'] ?? '';

    if (json['social'] != null) {
      final social = json['social'];
      facebook = social['facebook'] ?? '';
      instagram = social['instagram'] ?? '';
      twitter = social['twitter'] ?? '';
      youtube = social['youtube'] ?? '';
      linkedin = social['linkedin'] ?? '';
      email = social['email'] ?? '';
    } else {
      facebook = '';
      instagram = '';
      twitter = '';
      youtube = '';
      linkedin = '';
      email = '';
    }

    if (json['address'] != null) {
      final address = json['address'];
      addressAr = address['addressAr'] ?? '';
      addressEn = address['addressEn'] ?? '';
      addressKrd = address['addressKrd'] ?? '';
    } else {
      addressAr = '';
      addressEn = '';
      addressKrd = '';
    }

    email = json['email'] ?? '';
  }
}

class StaffModel {
  late String id;
  late String nameKrd;
  late String nameEn;
  late String nameAr;
  late String imageUrl;
  late String titleKrd;
  late String titleEn;
  late String titleAr;

  StaffModel.fromJson(Map<String, dynamic> json) {
    id = json['id'] ?? '';
    nameKrd = json['nameKrd'] ?? '';
    nameEn = json['nameEn'] ?? '';
    nameAr = json['nameAr'] ?? '';
    imageUrl = json['imageUrl'] ?? '';
    titleKrd = json['titleKrd'] ?? '';
    titleEn = json['titleEn'] ?? '';
    titleAr = json['titleAr'] ?? '';
  }
}
