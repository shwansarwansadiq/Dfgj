import 'package:psoola/models/text_lang_model.dart';

import '../components/seat/model/seat_model.dart';
import '../components/seat/utils/seat_state.dart';

class HallModel {
  String? id;
  late TextLangModel title;
  late String placeId;
  Map<String, int>? seatsPrice;
  Map<String, bool>? reservedSeats;
  int? defaultPrice;

  HallModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = TextLangModel.fromJson(json['title']);
    seatsPrice = json['seats_price'] != null
        ? Map<String, int>.from(json['seats_price'])
        : null;
    defaultPrice = json['default_price'];
    placeId = json['place_id'];
    reservedSeats = json['reserved_seats'] != null
        ? Map<String, bool>.from(json['reserved_seats'])
        : null;
  }

  toJson() {
    return {
      'id': id,
      'place_id': placeId,
      'title': title.toJson(),
    };
  }
}

class SingleSeatModel {
  late SeatNumber number;
  late SeatState seatState;

  SingleSeatModel.fromJson(Map<String, dynamic> json) {
    number = SeatNumber.fromJson({'rowI': json['rowI'], 'colI': json['colI']});
    seatState = seatStateFromString(json['seatState']);
  }
}

class SeatPriceModel {
  String? id;
  dynamic defaultPrice;
  String? currency;
  late List<SeatNumber> seatPrices;

  SeatPriceModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    defaultPrice = json['defaultPrice'];
    currency = json['currency'];
    seatPrices = json['seatPrices'].isEmpty
        ? []
        : json['seatPrices']
            .map<SeatNumber>((e) => SeatNumber.fromJson({...e as Map}))
            .toList();
  }
}
