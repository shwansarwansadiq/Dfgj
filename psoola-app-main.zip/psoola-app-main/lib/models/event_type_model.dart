// ignore_for_file: constant_identifier_names

enum EventType { MOVIE, THEATER, LIVEMUSIC, CONCERT, EVENT }

EventType eventTypeFromString(String type) {
  switch (type) {
    case 'MOVIE':
      return EventType.MOVIE;
    case 'THEATER':
      return EventType.THEATER;
    case 'LIVEMUSIC':
      return EventType.LIVEMUSIC;
    case 'CONCERT':
      return EventType.CONCERT;
    case 'EVENT':
      return EventType.EVENT;
    default:
      return EventType.MOVIE;
  }
}

// String from ShowsType
String eventTypeToString(EventType type) {
  switch (type) {
    case EventType.MOVIE:
      return 'MOVIE';
    case EventType.THEATER:
      return 'THEATER';
    case EventType.LIVEMUSIC:
      return 'LIVEMUSIC';
    case EventType.CONCERT:
      return 'CONCERT';
    case EventType.EVENT:
      return 'EVENT';
    default:
      return 'MOVIE';
  }
}

List<EventType> showsTypes = [
  EventType.MOVIE,
  EventType.THEATER,
  EventType.LIVEMUSIC,
  EventType.CONCERT,
  EventType.EVENT
];
