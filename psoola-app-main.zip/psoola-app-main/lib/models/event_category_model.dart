import 'package:cloud_firestore/cloud_firestore.dart';

class EventCategoryModel {
  late String name;
  late int price;
  late Timestamp time;

  EventCategoryModel(
      {required this.name, required this.price, required this.time});

  EventCategoryModel.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    price = json['price'];
    time = json['time'];
  }

  EventCategoryModel.fromTicketModel(Map<String, dynamic> json) {
    name = json['name'];
    price = json['price'];
    time = Timestamp.fromMillisecondsSinceEpoch(json['time']);
  }

  toJson() {
    return {
      'name': name,
      'price': price,
      'time': time.millisecondsSinceEpoch,
    };
  }
}
