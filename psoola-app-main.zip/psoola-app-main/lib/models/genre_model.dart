import 'text_lang_model.dart';

class GenreModel {
  late String id;
  late TextLangModel title;

  GenreModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    title = TextLangModel.fromJson(jsonData['title']);
  }
}
