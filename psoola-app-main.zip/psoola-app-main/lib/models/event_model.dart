import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:psoola/models/location/province_model.dart';
import 'package:psoola/models/place_model.dart';
import 'package:psoola/models/review_model.dart';
import 'package:psoola/models/event_type_model.dart';

import 'show_model.dart';

class EventModel {
  late String id;
  late ShowModel show;
  late EventType showsType;
  late List<PlaceModel> places;
  late List<ProvinceModel> provinces;
  late DateTime startTime;
  late DateTime endTime;
  bool? isInSwiper = false;
  bool? isActive = false;
  late TotalReviewModel totalReview;

  EventModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    places = (jsonData['places'] as List<dynamic>)
        .map((e) => PlaceModel.fromJson(e))
        .toList();
    provinces = (jsonData['provinces'] as List<dynamic>)
        .map<ProvinceModel>((e) => ProvinceModel.fromJson(e))
        .toList();
    show = ShowModel.fromJson(jsonData['show']);
    if (jsonData['start_time'] != null) {
      startTime = (jsonData['start_time'] as Timestamp).toDate();
    }
    if (jsonData['end_time'] != null) {
      endTime = (jsonData['end_time'] as Timestamp).toDate();
    }

    showsType = eventTypeFromString(jsonData['show_type']);

    if (jsonData['review'] != null) {
      totalReview = TotalReviewModel.fromJson(jsonData['review']);
    } else {
      totalReview = TotalReviewModel.fromJson({
        'star1': 0,
        'star2': 0,
        'star3': 0,
        'star4': 0,
        'star5': 0,
        'totalReview': 0,
        'averageRating': 0,
      });
    }
  }
}

class EventTimeModel {
  late DateTime datetime;
  late String id;

  EventTimeModel.fromJson(Map<String, dynamic> jsonData) {
    datetime = (jsonData['time'] as Timestamp).toDate();
    id = jsonData['id'];
  }

  toJson() {
    return {
      'time': datetime,
      'id': id,
    };
  }
}

class PlacesIdWithSelectedSeatId {
  late String placeId;
  String? seatDesignId;
  String? seatDesignName;

  PlacesIdWithSelectedSeatId.fromJson(Map<String, dynamic> jsonData) {
    placeId = jsonData['placeId'];
    seatDesignId = jsonData['seatDesignId'];
    seatDesignName = jsonData['seatDesignName'];
  }

  toJson() {
    return {
      'placeId': placeId,
      'seatDesignId': seatDesignId,
      'seatDesignName': seatDesignName,
    };
  }
}
