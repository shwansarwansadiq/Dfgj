import 'package:cloud_firestore/cloud_firestore.dart';

import 'location/location_model.dart';
import 'text_lang_model.dart';

class PlaceModel {
  late TextLangModel title;
  late String id;
  TextLangModel? description;
  String? poster;
  String? cover;
  late LocationModel location;
  late String logo;
  GeoPoint geoPoint = const GeoPoint(0, 0);

  PlaceModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    title = TextLangModel.fromJson(jsonData['title']);

    description = jsonData['description'] != null
        ? TextLangModel.fromJson(jsonData['description'])
        : null;
    cover = jsonData['cover'];
    location = LocationModel.fromJson(jsonData['location']);
    poster = jsonData['poster'];
    logo = jsonData['logo'];
    geoPoint = jsonData['geoPoint'] ?? const GeoPoint(0, 0);
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['title'] = title.toJson();
    data['description'] = description!.toJson();
    data['cover'] = cover;
    data['poster'] = poster;
    data['logo'] = logo;
    data['location'] = location.toJson();
    return data;
  }
}
