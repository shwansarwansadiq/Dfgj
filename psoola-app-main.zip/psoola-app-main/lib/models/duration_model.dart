class DurationModel {
  late String text;
  late int value;

  DurationModel.fromJson( Map<String, dynamic> json) {
    text = json['text'];
    value = json['value'];
  }
}
