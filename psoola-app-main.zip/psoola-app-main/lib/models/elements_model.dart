class ElementModel {
  late String id;
  late String iconUrl;
  late String name;
  double x = 0.1;
  double y = 0.1;
  double itemRatio = 0.1;

  ElementModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    iconUrl = json['iconUrl'];
    name = json['name'];
    x = json['x'] ?? 0.1;
    y = json['y'] ?? 0.1;
    itemRatio = json['itemRatio'] ?? 0.1;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['iconUrl'] = iconUrl;
    data['name'] = name;
    data['x'] = x;
    data['y'] = y;
    data['itemRatio'] = itemRatio;
    return data;
  }
}
