import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';

import '../api/user_api.dart';
import '../models/user_model.dart';

class AuthState extends GetxController {
  final user = UserModel.fromJson({"state": UserState.LOADING}).obs;
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  late String _fullName;
  late String _phonenumber;
  String? _city;

  String? _userName;

  set setUserName(String? value) {
    _userName = value;
  }

  get getUserName => _userName;

  XFile? _userImage;
  UserType? _userType;
  late ConfirmationResult confirmationResult;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  late String _smsVerificationCode;

  static final StreamController<String> _streamController =
      StreamController<String>.broadcast();
  Stream<String> authStream = _streamController.stream;

  UserType? get getUserType => _userType;
  set setUserType(UserType userType) {
    _userType = userType;
  }

  String get getFullName => _fullName;

  XFile? get getUserImage => _userImage;

  String get getPhoneNumber => _phonenumber;

  set setUserImage(XFile? setUserImage) {
    _userImage = setUserImage;
  }

  set setFullName(String setFullName) {
    _fullName = setFullName;
  }

  String? get getCity => _city;
  set setCity(String? value) {
    _city = value;
    update();
  }

  String get phonenumber => _phonenumber;
  set setPhoneNumber(String value) {
    _phonenumber = value;
  }

  logout() async {
    await _auth.signOut();
    user.value = UserModel.fromJson(
        {'id': '', 'phone': '', 'state': UserState.LOGEDOUT});
  }

  @override
  void onInit() {
    listen();
    super.onInit();
  }

  listen() {
    FirebaseAuth.instance.userChanges().listen((User? firebaseUser) {
      if (firebaseUser == null) {
        user.value = UserModel.fromJson(
            {'id': '', 'phone': '', 'state': UserState.LOGEDOUT});
      } else {
        Get.find<UserServiceProvider>().getUser().then(
          (value) {
            if (value != null) {
              user.value = value;
            } else {
              user.value = UserModel.fromJson(
                  {'id': '', 'phone': '', 'state': UserState.LOGEDOUT});
            }
          },
        );
      }
    });
  }

  updateUser(UserModel user) {
    this.user.value = user;
  }

  UserModel getUser() {
    return user.value;
  }

  Future<bool> verifyOtp(smsCode) async {
    if (!kIsWeb) {
      final AuthCredential credential = PhoneAuthProvider.credential(
        verificationId: _smsVerificationCode,
        smsCode: smsCode,
      );
      return await _auth.signInWithCredential(credential).then((value) {
        _streamController.add('code_verify');
        // EasyLoading.dismiss();
        return true;
      }).catchError((e) {
        // EasyLoading.dismiss();
        _streamController.add('failed_code');
        return false;
      });
    } else {
      UserCredential userCredential = await confirmationResult.confirm(smsCode);
      if (userCredential.user != null) {
        _streamController.add('code_verify');
        return true;
      } else {
        _streamController.add('failed_code');
        return false;
      }
    }
  }

  Future verifyPhoneNumber(BuildContext context) async {
    return await _auth
        .verifyPhoneNumber(
            phoneNumber: _phonenumber,
            timeout: const Duration(seconds: 120),
            verificationCompleted: (authCredential) =>
                _verificationComplete(authCredential, context),
            verificationFailed: (authException) =>
                _verificationFailed(authException, context),
            codeAutoRetrievalTimeout: (verificationId) =>
                _codeAutoRetrievalTimeout(verificationId),
            // called when the SMS code is sent
            codeSent: (verificationId, [code]) =>
                _smsCodeSent(verificationId, [code]))
        .catchError((onError) {
      // _streamController.add('error');
    });
  }

  _verificationComplete(AuthCredential authCredential, BuildContext context) {
    _auth.signInWithCredential(authCredential).then((authResult) async {
      // final snackBar = SnackBar(content: Text("Success!!! UUID is: " + authResult.user.uid));
      // Scaffold.of(context).showSnackBar(snackBar);
      await authResult.user!.getIdToken();
      _streamController.add('code_verify');
    });
  }

  _verificationFailed(
      FirebaseAuthException authException, BuildContext context) {
    // final snackBar = SnackBar(content: Text("Exception!! message:" + authException.message.toString()));
    // Scaffold.of(context).showSnackBar(snackBar);

    _streamController.add(authException.message.toString());
  }

  _codeAutoRetrievalTimeout(String verificationId) {
    // set the verification code so that we can use it to log the user in
    _streamController.add('time_out');
    _smsVerificationCode = verificationId;
  }

  _smsCodeSent(String verificationId, List<int?> code) {
    // set the verification code so that we can use it to log the user in
    // print(verificationId);
    // print(code);
    // print('sms send');

    _streamController.add('sms_code_send');

    _smsVerificationCode = verificationId;
  }

  Future<UserCredential> signInWithGoogle() async {
    final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
    final GoogleSignInAuthentication? googleAuth =
        await googleUser?.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth?.accessToken,
      idToken: googleAuth?.idToken,
    );
    return await _firebaseAuth.signInWithCredential(credential);
  }

  String generateNonce([int length = 32]) {
    const charset =
        '0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._';
    final random = Random.secure();
    return List.generate(length, (_) => charset[random.nextInt(charset.length)])
        .join();
  }

  /// Returns the sha256 hash of [input] in hex notation.
  String sha256ofString(String input) {
    final bytes = utf8.encode(input);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  Future<UserCredential> signInWithApple() async {
    final rawNonce = generateNonce();
    final nonce = sha256ofString(rawNonce);
    final appleCredential = await SignInWithApple.getAppleIDCredential(
      scopes: [
        AppleIDAuthorizationScopes.email,
        AppleIDAuthorizationScopes.fullName,
      ],
      nonce: nonce,
    );
    final oauthCredential = OAuthProvider("apple.com").credential(
      idToken: appleCredential.identityToken,
      rawNonce: rawNonce,
    );
    return await FirebaseAuth.instance.signInWithCredential(oauthCredential);
  }

  Future userLogOut() async {
    if (user != null) {
      await _firebaseAuth.signOut();
    } else {
      debugPrint('Not signed in');
    }
  }
}
