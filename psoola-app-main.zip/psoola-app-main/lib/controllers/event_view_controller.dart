import 'package:get/get.dart';

class UpdateView extends GetxController {
  bool isCard = true;

  updateView(isCard) {
    this.isCard = isCard;
    update();
  }
}
